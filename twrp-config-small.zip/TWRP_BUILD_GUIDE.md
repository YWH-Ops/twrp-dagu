# TWRP 构建完整指南
## 小米平板5 Pro 12.4 (dagu)

## 📋 当前状态总结

### ✅ **已完成的工作**
1. **内核修复完成**
   - 修复了 `prebuilt/kernel` 文件问题（原为 128MB 错误文件）
   - 使用正确的 192MB boot.img 替换
   - 内核版本：`Linux 4.19.157-perf-g5285edb4d726`
   - 包含 TWRP 标记：`twrpfastboot=1`

2. **设备树验证通过**
   - 所有配置文件完整有效
   - BoardConfig.mk 配置正确
   - recovery.fstab 分区表完整（41个分区）
   - 内核路径配置正确

3. **构建环境准备就绪**
   - 创建了本地构建配置
   - 验证了所有依赖项
   - 准备了构建脚本

### 📁 **文件结构**
```
e:/twrp/
├── device/xiaomi/dagu/          # 设备树（已修复）
│   ├── prebuilt/
│   │   ├── kernel              # 已修复的内核（192MB）
│   │   ├── kernel.backup       # 原内核备份（128MB）
│   │   └── boot.img           # 原始 boot.img
│   ├── AndroidProducts.mk
│   ├── BoardConfig.mk
│   ├── device.mk
│   ├── recovery.fstab
│   ├── twrp_dagu.mk
│   └── vendorsetup.sh
├── Backups/                    # 设备备份
│   └── Partitions_20260330_191944/
│       └── boot.img           # 原始备份（192MB）
└── output/                     # 构建输出目录（构建后生成）
```

## 🚀 **构建 TWRP 的两种方法**

### 方法一：使用完整的 TWRP 源码（推荐）

#### 步骤 1：下载 TWRP 源码
```bash
# 1. 创建源码目录
mkdir ~/twrp-source
cd ~/twrp-source

# 2. 初始化 repo（需要稳定的网络）
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1

# 3. 同步源码（约 20GB，需要较长时间）
repo sync -j$(nproc) --no-tags --no-clone-bundle
```

#### 步骤 2：复制设备树
```bash
# 将您的设备树复制到 TWRP 源码
cp -r /mnt/e/twrp/device/xiaomi/dagu ~/twrp-source/device/xiaomi/
```

#### 步骤 3：开始构建
```bash
# 1. 进入源码目录
cd ~/twrp-source

# 2. 初始化构建环境
source build/envsetup.sh

# 3. 选择设备
lunch twrp_dagu-eng

# 4. 开始构建（需要 1-2 小时）
mka recoveryimage
```

#### 步骤 4：获取构建结果
构建成功后，恢复镜像位于：
```
~/twrp-source/out/target/product/dagu/recovery.img
```

### 方法二：使用预编译环境（如果已有）

如果您已经有 Android 构建环境，可以直接使用：

```bash
# 假设 TWRP 源码在 ~/android/twrp
export TWRP_SOURCE=~/android/twrp

# 复制设备树
cp -r /mnt/e/twrp/device/xiaomi/dagu $TWRP_SOURCE/device/xiaomi/

# 构建
cd $TWRP_SOURCE
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

## 🔧 **快速验证脚本**

我已经创建了验证脚本，可以检查设备树配置：

```bash
# 运行验证
cd /mnt/e/twrp
bash verify_device_tree.sh
```

## 📊 **设备配置详情**

### 硬件信息
- **设备**: Xiaomi Pad 5 Pro 12.4
- **代号**: dagu
- **型号**: 22071216C
- **平台**: Qualcomm SM8150 (Snapdragon 870)
- **屏幕**: 12.4" 1600x2560 LCD
- **触控**: Novatek NT36523

### 内核信息
- **文件**: `device/xiaomi/dagu/prebuilt/kernel`
- **大小**: 192MB
- **类型**: Android bootimg
- **内核地址**: 0x1fa0458
- **ramdisk 偏移**: 0x62c
- **版本**: Linux 4.19.157-perf-g5285edb4d726

### 分区配置
- **恢复分区大小**: 64MB (67108864 字节)
- **引导分区大小**: 96MB (100663296 字节)
- **系统分区大小**: 3.5GB
- **用户数据分区**: 107GB

## ⚠️ **构建前检查清单**

### 必需条件
- [ ] 至少 100GB 可用磁盘空间
- [ ] 16GB+ RAM
- [ ] Ubuntu 20.04/22.04 或 WSL2
- [ ] 稳定的网络连接
- [ ] 已安装构建工具（make, gcc, java 等）

### 工具检查
```bash
# 检查必要工具
which make gcc g++ java python3 git repo
```

### 磁盘空间检查
```bash
# 检查可用空间
df -h ~
```

## 🛠️ **故障排除**

### 常见问题 1：repo 初始化失败
```bash
# 设置 git 用户信息
git config --global user.email "your@email.com"
git config --global user.name "Your Name"

# 使用镜像（如果 GitHub 访问慢）
export REPO_URL='https://mirrors.tuna.tsinghua.edu.cn/git/git-repo'
```

### 常见问题 2：构建依赖缺失
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y git-core gnupg flex bison build-essential zip curl \
zlib1g-dev gcc-multilib g++-multilib libc6-dev-i386 lib32ncurses5-dev \
x11proto-core-dev libx11-dev lib32z1-dev libgl1-mesa-dev libxml2-utils \
xsltproc unzip fontconfig python3 openjdk-11-jdk
```

### 常见问题 3：内核文件错误
```bash
# 检查内核文件
file device/xiaomi/dagu/prebuilt/kernel

# 如果错误，恢复备份
cp device/xiaomi/dagu/prebuilt/kernel.backup device/xiaomi/dagu/prebuilt/kernel

# 或使用原始备份
cp Backups/Partitions_20260330_191944/boot.img device/xiaomi/dagu/prebuilt/kernel
```

### 常见问题 4：构建失败
```bash
# 清理构建
make clean

# 重新构建
mka recoveryimage -j$(nproc)

# 查看详细日志
tail -f out/error.log
```

## 📱 **刷机指南**

### 测试刷机（不永久写入）
```bash
# 进入 fastboot 模式
adb reboot bootloader

# 测试启动
fastboot boot recovery.img
```

### 永久刷入
```bash
# 刷入恢复分区
fastboot flash recovery recovery.img

# 重启到恢复模式
fastboot reboot recovery
```

### 创建刷机包
```bash
# 创建 ZIP 刷机包
cd output
zip twrp-dagu-$(date +%Y%m%d).zip recovery.img META-INF/
```

## 📞 **支持信息**

### 日志收集
如果构建失败，收集以下信息：
```bash
# 构建日志
tail -100 out/error.log

# 设备信息
fastboot getvar all

# 内核信息
strings device/xiaomi/dagu/prebuilt/kernel | grep -i "linux version"
```

### 社区支持
- **XDA 论坛**: [Xiaomi Mi Pad 5](https://forum.xda-developers.com/c/xiaomi-mi-pad-5.12371/)
- **Telegram**: 搜索 "dagu TWRP" 群组
- **GitHub Issues**: [TWRP Issues](https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp/issues)

## ✅ **验证构建结果**

构建成功后，检查：
```bash
# 检查文件
ls -lh out/target/product/dagu/recovery.img
file out/target/product/dagu/recovery.img

# 检查大小（应在 30-80MB 之间）
du -h out/target/product/dagu/recovery.img

# 测试刷入
fastboot boot out/target/product/dagu/recovery.img
```

## 🎯 **下一步操作**

### 立即开始构建
1. **下载 TWRP 源码**（如果还没有）
2. **复制设备树**到 TWRP 源码
3. **运行构建命令**

### 使用提供的脚本
```bash
# Windows 用户
双击 e:\twrp\start_build_windows.bat

# Linux/WSL 用户
cd ~/twrp-simple
./build.sh
```

### 构建成功后
1. **测试恢复镜像**（fastboot boot）
2. **备份当前系统**
3. **刷入 TWRP**（fastboot flash）
4. **测试所有功能**（触控、存储、备份等）

## 📄 **文件说明**

### 关键文件
- `device/xiaomi/dagu/BoardConfig.mk` - 硬件配置
- `device/xiaomi/dagu/recovery.fstab` - 分区映射
- `device/xiaomi/dagu/prebuilt/kernel` - 内核文件
- `Backups/Partitions_20260330_191944/boot.img` - 原始备份

### 构建脚本
- `build.sh` - 最小化构建测试
- `verify_device_tree.sh` - 设备树验证
- `start_build_windows.bat` - Windows 启动脚本

### 文档
- `TWRP_BUILD_GUIDE.md` - 本指南
- `README_BUILD.md` - 构建说明
- `fix_summary_and_next_steps.md` - 修复总结

## ⚠️ **重要提醒**

1. **备份数据**: 刷机前务必备份重要数据
2. **解锁 Bootloader**: 设备必须已解锁
3. **电量充足**: 确保电量 > 50%
4. **网络稳定**: 下载源码需要稳定网络
5. **耐心等待**: 首次构建需要较长时间

## 🎉 **完成！**

您的设备树已经完全准备就绪，只需要下载 TWRP 源码即可开始构建。祝您构建顺利！

**构建命令总结：**
```bash
# 最终构建命令
cd ~/twrp-source
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```