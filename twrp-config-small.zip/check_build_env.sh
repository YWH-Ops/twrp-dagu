#!/bin/bash

# 检查构建环境脚本

cd ~/twrp-minimal || { echo "错误: 无法进入 ~/twrp-minimal 目录"; exit 1; }

echo "=== 检查构建环境 ==="
echo "当前目录: $(pwd)"
echo ""
echo "目录内容:"
ls -la
echo ""

echo "检查 build/ 目录:"
if [ -d build ]; then
    ls -la build/
else
    echo "build/ 目录不存在，正在创建..."
    mkdir -p build
fi
echo ""

echo "检查 envsetup.sh:"
if [ -f build/envsetup.sh ]; then
    echo "envsetup.sh 存在"
    head -10 build/envsetup.sh
else
    echo "envsetup.sh 不存在，正在创建..."
    cat > build/envsetup.sh << 'END'
#!/bin/bash
echo "最小化构建环境"
export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
echo "环境已设置"
END
    chmod +x build/envsetup.sh
    echo "已创建 build/envsetup.sh"
fi
echo ""

echo "检查设备树:"
if [ -d device/xiaomi/dagu ]; then
    echo "设备树存在: device/xiaomi/dagu"
    echo "内核文件:"
    ls -lh device/xiaomi/dagu/prebuilt/kernel 2>/dev/null || echo "内核文件不存在"
else
    echo "错误: 设备树不存在"
fi
echo ""

echo "检查 TWRP 源码:"
if [ -L bootable/recovery ] || [ -d bootable/recovery ]; then
    echo "TWRP 源码存在: bootable/recovery"
    if [ -L bootable/recovery ]; then
        echo "类型: 符号链接 -> $(readlink bootable/recovery)"
    fi
else
    echo "错误: TWRP 源码不存在"
fi
echo ""

echo "环境检查完成"
echo ""
echo "下一步:"
echo "1. 运行: source build/envsetup.sh"
echo "2. 运行构建脚本"