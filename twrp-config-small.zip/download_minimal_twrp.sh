#!/bin/bash

# 最小化 TWRP 源码下载脚本
# 只下载必要的组件来构建 TWRP

set -e

echo "================================================"
echo "    最小化 TWRP 源码下载"
echo "================================================"
echo "只下载构建 TWRP 所需的最小组件"
echo ""

# 创建目录
SOURCE_DIR="$HOME/twrp-minimal"
echo "创建目录: $SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"

echo "当前目录: $(pwd)"
echo ""

# 1. 下载必要的仓库
echo "1. 下载构建系统..."
if [ ! -d "build/make" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_build build/make
    echo "✓ 下载完成: build/make"
else
    echo "✓ 已存在: build/make"
fi

echo ""
echo "2. 下载系统核心..."
if [ ! -d "system/core" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_system_core system/core
    echo "✓ 下载完成: system/core"
else
    echo "✓ 已存在: system/core"
fi

echo ""
echo "3. 下载硬件抽象层..."
if [ ! -d "hardware/interfaces" ]; then
    mkdir -p hardware
    git clone --depth=1 https://github.com/TeamWin/android_hardware_interfaces hardware/interfaces
    echo "✓ 下载完成: hardware/interfaces"
else
    echo "✓ 已存在: hardware/interfaces"
fi

echo ""
echo "4. 下载框架..."
if [ ! -d "frameworks/base" ]; then
    mkdir -p frameworks
    git clone --depth=1 https://github.com/TeamWin/android_frameworks_base frameworks/base
    echo "✓ 下载完成: frameworks/base"
else
    echo "✓ 已存在: frameworks/base"
fi

echo ""
echo "5. 下载外部库..."
if [ ! -d "external" ]; then
    mkdir -p external
    # 下载一些必要的外部库
    git clone --depth=1 https://github.com/TeamWin/android_external_selinux external/selinux
    git clone --depth=1 https://github.com/TeamWin/android_external_libpng external/libpng
    git clone --depth=1 https://github.com/TeamWin/android_external_libjpeg-turbo external/libjpeg-turbo
    git clone --depth=1 https://github.com/TeamWin/android_external_freetype external/freetype
    echo "✓ 下载完成: 外部库"
else
    echo "✓ 已存在: external/"
fi

echo ""
echo "6. 复制设备树..."
DEVICE_TREE="device/xiaomi/dagu"
if [ ! -d "$DEVICE_TREE" ]; then
    mkdir -p device/xiaomi
    # 从当前目录复制设备树
    if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
        cp -r /mnt/e/twrp/device/xiaomi/dagu "$DEVICE_TREE"
        echo "✓ 复制设备树完成"
    else
        echo "⚠ 警告: 找不到设备树 /mnt/e/twrp/device/xiaomi/dagu"
    fi
else
    echo "✓ 设备树已存在"
fi

echo ""
echo "7. 创建必要的符号链接..."
# 创建 bootable/recovery 符号链接到现有的源码
if [ ! -L "bootable/recovery" ] && [ -d "/mnt/e/twrp/android_bootable_recovery" ]; then
    mkdir -p bootable
    ln -sf /mnt/e/twrp/android_bootable_recovery bootable/recovery
    echo "✓ 创建符号链接: bootable/recovery -> /mnt/e/twrp/android_bootable_recovery"
else
    echo "✓ bootable/recovery 已设置"
fi

echo ""
echo "8. 创建构建环境脚本..."
cat > build/envsetup.sh << 'EOF'
#!/bin/bash

# 最小化构建环境设置

export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out

# 设置构建目标
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export TARGET_BUILD_TYPE=release
export TARGET_BUILD_APPS=

# 设置 TWRP 特定变量
export RECOVERY_VARIANT=twrp
export TW_THEME=portrait_hdpi
export TW_DEVICE_VERSION=1.0
export TW_DEFAULT_LANGUAGE=zh_CN

# 构建函数
function lunch() {
    local product=$1
    if [ -z "$product" ]; then
        product="twrp_dagu-eng"
    fi
    
    echo "============================================"
    echo "  TARGET_PRODUCT=twrp_dagu"
    echo "  TARGET_BUILD_VARIANT=eng"
    echo "  ANDROID_BUILD_TOP=$ANDROID_BUILD_TOP"
    echo "============================================"
    
    # 检查设备树
    if [ ! -d "device/xiaomi/dagu" ]; then
        echo "错误: 设备树未找到"
        return 1
    fi
    
    echo "✓ 设备树检查通过"
    return 0
}

function mka() {
    echo "最小化构建系统 - 使用 make 代替 mka"
    make "$@"
}

echo "最小化构建环境已设置"
echo "运行: lunch twrp_dagu-eng"
echo "运行: make recoveryimage"
EOF

chmod +x build/envsetup.sh
echo "✓ 创建 build/envsetup.sh"

echo ""
echo "9. 创建简化的构建脚本..."
cat > build_twrp_minimal.sh << 'EOF'
#!/bin/bash

# 最小化 TWRP 构建脚本

set -e

echo "========================================"
echo "  TWRP 最小化构建脚本"
echo "========================================"

# 设置环境
source build/envsetup.sh
lunch twrp_dagu-eng

echo ""
echo "开始构建 TWRP..."
echo "这可能需要一些时间..."

# 创建输出目录
mkdir -p out/target/product/dagu

# 简化的构建命令
echo "构建命令: make -j$(nproc) recoveryimage"
make -j$(nproc) recoveryimage 2>&1 | tee build.log

# 检查结果
if [ -f "out/target/product/dagu/recovery.img" ]; then
    echo ""
    echo "========================================"
    echo "  TWRP 构建成功!"
    echo "========================================"
    echo "恢复镜像: out/target/product/dagu/recovery.img"
    echo "大小: $(ls -lh out/target/product/dagu/recovery.img | awk '{print \$5}')"
    
    # 复制到 Windows
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp out/target/product/dagu/recovery.img "$WINDOWS_DIR/"
    echo "已复制到: $WINDOWS_DIR/recovery.img"
else
    echo ""
    echo "========================================"
    echo "  TWRP 构建失败"
    echo "========================================"
    echo "查看日志: tail -100 build.log"
    exit 1
fi
EOF

chmod +x build_twrp_minimal.sh
echo "✓ 创建 build_twrp_minimal.sh"

echo ""
echo "================================================"
echo "    最小化 TWRP 源码下载完成!"
echo "================================================"
echo ""
echo "目录: $SOURCE_DIR"
echo "已下载:"
echo "  - build/make (构建系统)"
echo "  - system/core (系统核心)"
echo "  - hardware/interfaces (硬件抽象层)"
echo "  - frameworks/base (框架)"
echo "  - external/ (外部库)"
echo "  - device/xiaomi/dagu (设备树)"
echo "  - bootable/recovery (符号链接到现有 TWRP 源码)"
echo ""
echo "下一步:"
echo "  cd $SOURCE_DIR"
echo "  source build/envsetup.sh"
echo "  lunch twrp_dagu-eng"
echo "  ./build_twrp_minimal.sh"
echo ""
echo "或直接运行:"
echo "  cd $SOURCE_DIR && ./build_twrp_minimal.sh"
echo ""
echo "注意: 这是最小化构建，可能需要额外依赖"
echo "如果构建失败，请查看 build.log 获取详细信息"