# TWRP 构建工具包 - 小米平板5 Pro 12.4 (dagu)

## 🚀 快速开始

### 对于 Windows 用户
1. **确保已安装 WSL2 和 Ubuntu**
2. **运行构建脚本**：
   ```powershell
   cd e:\twrp
   .\build_windows.ps1
   ```
3. **按照菜单提示操作**

### 对于 Linux/macOS 用户
1. **设置执行权限**：
   ```bash
   chmod +x quick_start.sh verify_build.py
   ```
2. **运行构建脚本**：
   ```bash
   ./quick_start.sh all
   ```

## 📁 文件结构

```
twrp/
├── build_twrp.bat              # Windows 构建脚本
├── build_windows.ps1           # Windows PowerShell 构建脚本
├── quick_start.sh              # Linux/macOS 构建脚本
├── verify_build.py             # 构建验证脚本
├── Makefile                    # Makefile 构建配置
├── 构建指南.md                  # 详细构建指南
├── INSTALL.md                  # 安装指南
├── device/xiaomi/dagu/         # 设备树文件
│   ├── AndroidProducts.mk      # 产品定义
│   ├── BoardConfig.mk          # 硬件配置
│   ├── device.mk               # 设备属性
│   ├── recovery.fstab          # 分区映射表
│   ├── twrp_dagu.mk           # TWRP 产品配置
│   ├── vendorsetup.sh         # 构建集成
│   ├── prebuilt/              # 预编译文件
│   │   ├── boot.img           # 引导镜像
│   │   └── kernel             # 内核文件
│   └── README.md              # 设备文档
├── Backups/                   # 设备分区备份
└── output/                    # 构建输出目录（构建后生成）
```

## 🔧 构建步骤

### 1. 环境准备
- **操作系统**: Ubuntu 20.04/22.04 或 WSL2
- **内存**: 16GB+ RAM
- **存储**: 200GB+ 可用空间
- **依赖**: 完整的 Android 构建环境

### 2. 下载 TWRP 源码
```bash
# 自动下载（通过脚本）
./quick_start.sh download

# 或手动下载
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1
repo sync -j$(nproc)
```

### 3. 准备设备树
```bash
# 自动准备（通过脚本）
./quick_start.sh prepare

# 或手动复制
cp -r device/xiaomi/dagu ~/twrp-build/device/xiaomi/
```

### 4. 构建 recovery
```bash
# 自动构建（通过脚本）
./quick_start.sh build

# 或手动构建
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

### 5. 验证构建
```bash
# 验证构建结果
python3 verify_build.py

# 或检查输出文件
ls -lh output/
```

## 📱 刷入设备

### 方法一：Fastboot（推荐）
```bash
adb reboot bootloader
fastboot flash recovery output/recovery.img
fastboot reboot recovery
```

### 方法二：刷机包
1. 复制 `output/twrp-*.zip` 到设备存储
2. 启动到现有恢复模式
3. 选择 "Install" → 选择刷机包
4. 滑动确认刷入
5. 重启到恢复模式

### 方法三：临时启动（测试）
```bash
fastboot boot output/recovery.img
```

## 🛠️ 工具说明

### `build_windows.ps1` - Windows 构建脚本
- 交互式菜单界面
- 自动检查环境
- WSL2 集成构建
- 创建刷机包

### `quick_start.sh` - Linux/macOS 构建脚本
- 完整的构建流程
- 错误检查和日志
- 自动下载 TWRP 源码
- 创建刷机包

### `verify_build.py` - 验证脚本
- 检查设备树完整性
- 验证 recovery.img 格式
- 检查构建日志
- 生成验证报告

### `Makefile` - Makefile 构建
- 传统构建方式
- 支持多目标
- 清理和验证功能

## ⚠️ 注意事项

### 构建前检查
1. **依赖检查**：运行 `./quick_start.sh check`
2. **磁盘空间**：确保至少 100GB 可用空间
3. **网络连接**：TWRP 源码约 20GB

### 刷机前准备
1. **解锁 bootloader**：必要步骤
2. **备份数据**：刷机会清除数据
3. **充电充足**：确保电量 > 50%

### 常见问题

#### 构建失败
```bash
# 1. 清理构建
make clean

# 2. 重新同步源码
repo sync --force-sync

# 3. 减少并行任务
make recoveryimage -j4
```

#### 设备未识别
```bash
# 检查连接
adb devices
fastboot devices

# 重新安装驱动
# Windows: 安装小米 USB 驱动
# Linux: 添加 udev 规则
```

#### 触控不工作
- 检查触控驱动配置
- 尝试不同版本的 TWRP
- 使用鼠标或键盘操作

## 🔍 验证构建

### 自动验证
```bash
python3 verify_build.py
```

### 手动检查
1. **文件大小**：recovery.img 应在 64-128MB 之间
2. **文件类型**：应为 Android boot image
3. **刷机包**：应包含必要文件
4. **构建日志**：无严重错误

### 验证报告
构建验证报告位于：
```
output/verification_report.txt
```

## 📞 技术支持

### 获取帮助
1. **查看文档**：阅读 `构建指南.md` 和 `INSTALL.md`
2. **检查日志**：查看 `build.log`
3. **验证构建**：运行 `verify_build.py`
4. **社区支持**：XDA 论坛和 Telegram 群组

### 报告问题
请提供以下信息：
- 设备型号和 Android 版本
- 错误信息和日志
- 构建环境信息
- 已尝试的解决方案

## 📄 许可证

本项目基于 Apache License 2.0 许可证分发。

## 🙏 致谢

- Team Win Recovery Project (TWRP)
- Xiaomi for device firmware
- The Android Open Source Project
- All contributors and testers

---
**构建状态**: ✅ 设备树就绪  
**测试状态**: ⚠️ 需要实际设备测试  
**维护状态**: 🔧 活跃维护中  

**提示**: 首次构建可能需要 1-2 小时，请耐心等待。确保网络稳定，构建过程中不要中断。

**输出位置**: `output/` 目录包含所有构建结果。

**刷机包命名**: `twrp-版本-日期-设备.zip`，如 `twrp-3.7.0-20260331-dagu.zip`