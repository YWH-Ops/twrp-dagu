@echo off
REM TWRP 构建批处理脚本
REM 用于构建小米平板5 Pro 12.4 (dagu) 的 TWRP

echo ================================================
echo      TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)
echo ================================================
echo.

echo 1. 检查环境...
echo.

REM 检查是否在正确的目录
if not exist "build\envsetup.sh" (
    echo 错误: 请在 TWRP 源码根目录运行此脚本
    echo 当前目录: %cd%
    pause
    exit /b 1
)

echo ✓ 在 TWRP 源码目录
echo.

REM 检查设备树
set DEVICE_DIR=device\xiaomi\dagu
if not exist "%DEVICE_DIR%" (
    echo 错误: 设备树目录不存在: %DEVICE_DIR%
    pause
    exit /b 1
)

echo ✓ 设备树目录存在: %DEVICE_DIR%
echo.

REM 检查内核文件
set KERNEL_FILE=%DEVICE_DIR%\prebuilt\kernel
if not exist "%KERNEL_FILE%" (
    echo 错误: 内核文件不存在: %KERNEL_FILE%
    pause
    exit /b 1
)

echo ✓ 内核文件存在: %KERNEL_FILE%
echo 内核文件信息:
dir "%KERNEL_FILE%"
echo.

REM 检查 WSL 中的文件类型
echo 检查内核文件类型:
wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel"
echo.

echo 2. 构建步骤说明...
echo.
echo 请按照以下步骤构建 TWRP:
echo.
echo 步骤 1: 初始化环境
echo   call build\envsetup.sh
echo.
echo 步骤 2: 选择设备
echo   lunch twrp_dagu-eng
echo.
echo 步骤 3: 开始构建
echo   mka recoveryimage
echo.
echo 注意: 构建需要较长时间，请确保:
echo   - 至少有 16GB 内存
echo   - 至少有 100GB 磁盘空间
echo   - 稳定的网络连接
echo.

echo 3. 快速构建命令:
echo.
echo 您可以直接运行以下命令:
echo   call build\envsetup.sh ^& lunch twrp_dagu-eng ^& mka recoveryimage
echo.

echo 4. 构建完成后检查:
echo.
set OUTPUT_DIR=out\target\product\dagu
set RECOVERY_IMG=%OUTPUT_DIR%\recovery.img

if exist "%RECOVERY_IMG%" (
    echo ✓ TWRP 构建成功!
    echo 恢复镜像位置: %RECOVERY_IMG%
    dir "%RECOVERY_IMG%"
    echo.
    
    echo 测试命令:
    echo   fastboot flash recovery %RECOVERY_IMG%
    echo   fastboot boot %RECOVERY_IMG%
) else (
    echo TWRP 镜像不存在，需要先构建
    echo.
    echo 构建命令:
    echo   call build\envsetup.sh
    echo   lunch twrp_dagu-eng
    echo   mka recoveryimage
)

echo.
echo 5. 内核文件验证:
echo.
echo 当前使用的内核文件信息:
wsl ls -lh "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel"
echo.
wsl strings "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" | wsl grep -i "linux version" | wsl head -3
echo.

echo 6. 设备树配置:
echo.
echo 内核路径配置:
findstr "TARGET_PREBUILT_KERNEL" "%DEVICE_DIR%\BoardConfig.mk"
echo.
echo 内核参数:
findstr "BOARD_KERNEL_" "%DEVICE_DIR%\BoardConfig.mk"
echo.

echo 7. 问题排查:
echo.
echo 如果构建失败，请检查:
echo   1. 内核文件是否正确 (应该是 Android bootimg 格式)
echo   2. 设备树配置是否正确
echo   3. 构建环境是否完整
echo   4. 磁盘空间是否足够
echo.
echo 查看构建日志:
echo   type "%OUTPUT_DIR%\build.log" | more
echo.

echo ================================================
echo     脚本完成!
echo ================================================
echo.
echo 重要提示:
echo - 确保使用正确的内核文件 (192MB 的 boot.img)
echo - 原 128MB 的 kernel 文件已备份为 kernel.backup
echo - 如需恢复原文件: copy kernel.backup kernel
echo.
pause