#!/bin/bash

# TWRP 云构建 - 一键推送脚本
# GitHub 用户名: b15185591889

set -e

echo "========================================"
echo "🚀 TWRP 云构建 - 一键推送脚本"
echo "========================================"
echo ""

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${BLUE}>>>${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

# 配置信息
GITHUB_USERNAME="b15185591889"
REPO_NAME="twrp-dagu"
BRANCH="main"
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo "GitHub 配置:"
echo "  用户名: $GITHUB_USERNAME"
echo "  仓库名: $REPO_NAME"
echo "  分支: $BRANCH"
echo "  远程地址: $REMOTE_URL"
echo ""

# 步骤1: 检查是否已创建仓库
print_step "步骤1: 检查 GitHub 仓库"
echo ""
echo "请先在浏览器中创建 GitHub 仓库:"
echo ""
echo "访问: https://github.com/new"
echo ""
echo "填写以下信息:"
echo "  - Repository name: $REPO_NAME"
echo "  - Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
echo "  - Visibility: Public (公开)"
echo "  - 不要勾选: Initialize this repository with a README"
echo "  - 不要添加 .gitignore 或 license"
echo ""
read -p "仓库创建完成后按 Enter 继续..."

# 步骤2: 检查 Git 配置
print_step "步骤2: 检查 Git 配置"
echo ""

CURRENT_NAME=$(git config --global user.name 2>/dev/null || echo "")
CURRENT_EMAIL=$(git config --global user.email 2>/dev/null || echo "")

if [ -z "$CURRENT_NAME" ] || [ -z "$CURRENT_EMAIL" ]; then
    print_warning "Git 配置未设置，正在配置..."
    git config --global user.name "TWRP Builder"
    git config --global user.email "builder@example.com"
    print_success "Git 配置完成"
else
    echo "当前 Git 用户: $CURRENT_NAME"
    echo "当前 Git 邮箱: $CURRENT_EMAIL"
fi

echo ""

# 步骤3: 检查当前目录
print_step "步骤3: 检查当前目录"
if [ "$(pwd)" != "/mnt/e/twrp" ]; then
    print_warning "不在正确的目录中，切换到 /mnt/e/twrp"
    cd /mnt/e/twrp 2>/dev/null || {
        print_error "无法切换到 /mnt/e/twrp 目录"
        exit 1
    }
fi
print_success "当前目录: $(pwd)"

echo ""

# 步骤4: 检查 Git 仓库
print_step "步骤4: 检查 Git 仓库"
if [ ! -d ".git" ]; then
    print_warning "Git 仓库未初始化，正在初始化..."
    git init
    print_success "Git 仓库初始化完成"
else
    print_success "Git 仓库已存在"
fi

echo ""

# 步骤5: 添加文件
print_step "步骤5: 添加文件到 Git"
echo "正在添加文件..."
git add -f .
if [ $? -eq 0 ]; then
    print_success "文件添加完成"
else
    print_error "文件添加失败"
    exit 1
fi

echo ""

# 步骤6: 提交更改
print_step "步骤6: 提交更改"
echo "正在提交更改..."
git commit -m "TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南"

if [ $? -eq 0 ]; then
    print_success "提交完成"
else
    print_warning "提交可能失败，尝试强制提交..."
    git commit --allow-empty -m "TWRP 云构建配置"
    if [ $? -eq 0 ]; then
        print_success "强制提交完成"
    else
        print_error "提交失败"
        exit 1
    fi
fi

echo ""

# 步骤7: 配置远程仓库
print_step "步骤7: 配置远程仓库"

# 移除现有的 origin（如果有）
if git remote | grep -q origin; then
    print_warning "已存在远程仓库 origin，重新设置..."
    git remote remove origin
fi

# 添加新的远程仓库
git remote add origin "$REMOTE_URL"
if [ $? -eq 0 ]; then
    print_success "远程仓库已添加: $REMOTE_URL"
else
    print_error "添加远程仓库失败"
    exit 1
fi

echo ""

# 步骤8: 重命名分支
print_step "步骤8: 重命名分支"
CURRENT_BRANCH=$(git branch --show-current 2>/dev/null || echo "master")
if [ "$CURRENT_BRANCH" != "$BRANCH" ]; then
    git branch -M "$BRANCH"
    print_success "分支重命名为: $BRANCH"
else
    print_success "当前分支已经是: $BRANCH"
fi

echo ""

# 步骤9: 推送代码
print_step "步骤9: 推送代码到 GitHub"
echo "正在推送到: $REMOTE_URL"
echo "分支: $BRANCH"
echo ""
echo "这可能需要一些时间，请耐心等待..."
echo ""

# 尝试推送
if git push -u origin "$BRANCH"; then
    echo ""
    print_success "✅ 代码推送成功！"
    echo ""
else
    echo ""
    print_error "❌ 推送失败"
    echo ""
    echo "可能的原因:"
    echo "1. GitHub 仓库未创建"
    echo "2. 网络连接问题"
    echo "3. 权限问题"
    echo ""
    echo "请确保:"
    echo "1. 已创建仓库: https://github.com/new"
    echo "2. 仓库名称为: $REPO_NAME"
    echo "3. 仓库是 Public (公开)"
    echo ""
    echo "手动创建仓库命令:"
    echo "  gh repo create $REPO_NAME --public --description \"TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)\""
    echo ""
    exit 1
fi

# 步骤10: 完成
print_step "步骤10: 完成设置"
echo ""
echo "========================================"
print_success "🎉 GitHub 仓库设置完成！"
echo "========================================"
echo ""
echo "✅ 代码已推送到: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "✅ Git 配置完成"
echo "✅ 文件已提交"
echo "✅ 远程仓库已配置"
echo "✅ 代码已推送"
echo ""

# 步骤11: 显示下一步操作
print_step "步骤11: 立即开始构建 TWRP"
echo ""
echo "请按照以下步骤启动构建:"
echo ""
echo "1. 打开浏览器访问:"
echo "   https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "2. 点击顶部 'Actions' 标签"
echo ""
echo "3. 点击 'I understand my workflows, go ahead and enable them'"
echo ""
echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
echo ""
echo "5. 点击 'Run workflow'"
echo ""
echo "6. 配置参数:"
echo "   - use_china_mirror: true (推荐)"
echo "   - build_type: minimal (首次测试)"
echo "   - upload_artifact: true"
echo ""
echo "7. 点击 'Run workflow' 开始构建"
echo ""
echo "8. 等待构建完成 (约1-2小时)"
echo ""
echo "9. 下载 recovery.img 并测试"
echo ""
echo "========================================"
echo "重要链接"
echo "========================================"
echo "🔗 仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "🔗 Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "🔗 Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases"
echo ""
echo "========================================"
echo "构建监控"
echo "========================================"
echo "构建过程中可以:"
echo "1. 查看实时日志"
echo "2. 监控各个步骤"
echo "3. 下载构建产物"
echo "4. 查看错误信息"
echo ""
echo "========================================"
echo "保存配置信息"
echo "========================================"
cat > github_info_$GITHUB_USERNAME.txt << EOF
GitHub 仓库信息
================

用户名: $GITHUB_USERNAME
仓库名: $REPO_NAME
分支: $BRANCH
远程地址: $REMOTE_URL

仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME
Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions
Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases

推送时间: $(date)

下一步操作:
1. 访问仓库页面
2. 启用 GitHub Actions
3. 运行 Cloud TWRP Builder
4. 等待构建完成
5. 下载并测试 recovery.img

构建参数建议:
- use_china_mirror: true
- build_type: minimal
- upload_artifact: true

文档:
- 云构建指南.md
- GITHUB_ACTIONS_GUIDE.md
- 云构建快速开始.md

祝您构建成功！
EOF

print_success "配置信息已保存到: github_info_$GITHUB_USERNAME.txt"
echo ""
print_success "🎯 现在可以开始构建 TWRP 了！祝您成功！🚀"