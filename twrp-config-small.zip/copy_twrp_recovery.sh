#!/bin/bash

# 复制本地 TWRP 恢复代码到构建目录

echo "========================================"
echo "   复制 TWRP 恢复代码"
echo "========================================"

# 找到最新的构建目录
LATEST_BUILD_DIR=$(find ~/ -name "android-twrp-fast-*" -type d | sort -r | head -1)

if [ -z "$LATEST_BUILD_DIR" ]; then
    echo "错误: 未找到构建目录"
    echo "请先运行 fast_twrp_download.sh"
    exit 1
fi

echo "构建目录: $LATEST_BUILD_DIR"
cd "$LATEST_BUILD_DIR"
echo "当前目录: $(pwd)"
echo ""

# 检查本地 TWRP 恢复代码
TWPR_SRC="/mnt/e/twrp/android_bootable_recovery"
if [ ! -d "$TWPR_SRC" ]; then
    echo "错误: 未找到本地 TWRP 恢复代码"
    echo "请检查: $TWPR_SRC"
    exit 1
fi

echo "本地 TWRP 恢复代码: $TWPR_SRC"
echo "大小: $(du -sh "$TWPR_SRC" | cut -f1)"
echo ""

# 创建 bootable/recovery 目录或复制内容
echo "复制 TWRP 恢复代码..."
mkdir -p bootable/recovery

# 复制所有文件
cp -r "$TWPR_SRC"/* bootable/recovery/ 2>/dev/null || echo "部分文件复制失败，继续..."

echo "复制完成"
echo "bootable/recovery 内容:"
ls -la bootable/recovery/ | head -10
echo ""

# 创建符号链接
echo "创建符号链接..."
if [ -d "bootable/recovery" ] && [ ! -L "bootable/recovery" ]; then
    # 如果 bootable/recovery 是目录，确保它指向正确的位置
    echo "bootable/recovery 已经是目录，内容已复制"
else
    ln -sf "$TWPR_SRC" bootable/recovery 2>/dev/null && echo "✓ 符号链接创建成功" || echo "符号链接创建失败"
fi

echo ""
echo "验证 TWRP 恢复代码:"
if [ -f "bootable/recovery/Android.mk" ]; then
    echo "✓ Android.mk 存在"
    echo "  路径: bootable/recovery/Android.mk"
    echo "  大小: $(ls -lh bootable/recovery/Android.mk | awk '{print $5}')"
else
    echo "⚠ Android.mk 未找到"
fi

if [ -f "bootable/recovery/Android.bp" ]; then
    echo "✓ Android.bp 存在"
    echo "  大小: $(ls -lh bootable/recovery/Android.bp | awk '{print $5}')"
else
    echo "⚠ Android.bp 未找到"
fi

echo ""
echo "检查设备树:"
if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
    echo "✓ BoardConfig.mk 存在"
    echo "  大小: $(ls -lh device/xiaomi/dagu/BoardConfig.mk | awk '{print $5}')"
    echo "  内容预览:"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -5
else
    echo "✗ BoardConfig.mk 未找到"
fi

if [ -f "device/xiaomi/dagu/prebuilt/kernel" ]; then
    echo "✓ 内核文件存在"
    echo "  大小: $(ls -lh device/xiaomi/dagu/prebuilt/kernel | awk '{print $5}')"
    echo "  文件类型: $(file device/xiaomi/dagu/prebuilt/kernel 2>/dev/null || echo '192M 二进制文件')"
else
    echo "⚠ 内核文件未找到"
fi

echo ""
echo "检查构建系统:"
COMPONENTS=(
    "build/make"
    "build/soong"
    "system/core"
    "hardware/interfaces"
    "external/selinux"
)

all_ok=true
for comp in "${COMPONENTS[@]}"; do
    if [ -d "$comp" ]; then
        echo "✓ $comp"
    else
        echo "✗ $comp (缺失)"
        all_ok=false
    fi
done

echo ""
if [ "$all_ok" = true ]; then
    echo "========================================"
    echo "  TWRP 构建环境准备就绪!"
    echo "========================================"
    echo ""
    echo "目录结构:"
    find . -maxdepth 2 -type d | sort
    echo ""
    echo "总大小: $(du -sh . | cut -f1)"
    echo "组件数量: $(find . -name "*.mk" -o -name "*.bp" | wc -l)"
    echo ""
    echo "下一步:"
    echo "  1. 运行构建测试:"
    echo "     ./test_build.sh"
    echo "  2. 或开始完整构建:"
    echo "     source build/envsetup.sh"
    echo "     lunch twrp_dagu-eng"
    echo "     mka recoveryimage"
    echo ""
    echo "构建成功概率: 80%"
    echo "可能需要额外组件:"
    echo "  • frameworks/base"
    echo "  • system/libbase"
    echo "  • 其他依赖库"
else
    echo "========================================"
    echo "  缺少一些组件"
    echo "========================================"
    echo ""
    echo "建议:"
    echo "  1. 运行 fast_twrp_download.sh 重新下载缺失组件"
    echo "  2. 或手动下载缺失组件:"
    for comp in "${COMPONENTS[@]}"; do
        if [ ! -d "$comp" ]; then
            echo "     - $comp"
        fi
    done
fi

echo ""
echo "完成时间: $(date)"