@echo off
chcp 65001 >nul
title TWRP 镜像文件分析工具
color 0A

echo ================================================
echo     镜像文件分析工具 - TWRP 设备树
echo ================================================
echo.

set PREBUILT_PATH=e:\twrp\device\xiaomi\dagu\prebuilt
set BACKUP_PATH=e:\twrp\Backups\Partitions_20260330_191944
set OUTPUT_PATH=e:\twrp\analysis_results

if not exist "%OUTPUT_PATH%" mkdir "%OUTPUT_PATH%"

:menu
cls
echo 请选择分析选项:
echo.
echo  1. 分析预编译文件 (kernel, boot.img)
echo  2. 分析备份分区镜像
echo  3. 解包 boot.img
echo  4. 提取内核信息
echo  5. 查看所有镜像文件信息
echo  6. 生成完整报告
echo  7. 退出
echo.

set /p choice=请选择 (1-7): 

if "%choice%"=="1" goto analyze_prebuilt
if "%choice%"=="2" goto analyze_backup
if "%choice%"=="3" goto unpack_boot
if "%choice%"=="4" goto kernel_info
if "%choice%"=="5" goto list_images
if "%choice%"=="6" goto generate_report
if "%choice%"=="7" goto exit
echo 无效选项
timeout /t 2 >nul
goto menu

:analyze_prebuilt
cls
echo 分析预编译文件...
echo.

echo [1] 检查 boot.img...
if exist "%PREBUILT_PATH%\boot.img" (
    echo  文件存在: boot.img
    for /f "tokens=3" %%i in ('dir "%PREBUILT_PATH%\boot.img" ^| find "boot.img"') do set size=%%i
    echo  大小: %size%
    
    echo  文件类型分析:
    wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img"
    
    echo.
    echo  是否解包分析? (y/N)
    set /p unpack=选择: 
    if /i "%unpack%"=="y" (
        goto unpack_boot
    )
) else (
    echo  错误: boot.img 不存在
)

echo.
echo [2] 检查 kernel 文件...
if exist "%PREBUILT_PATH%\kernel" (
    echo  文件存在: kernel
    for /f "tokens=3" %%i in ('dir "%PREBUILT_PATH%\kernel" ^| find "kernel"') do set size=%%i
    echo  大小: %size%
    
    echo  文件类型分析:
    wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel"
    
    echo.
    echo  检查内核信息:
    wsl strings "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" ^| grep -i "linux version" ^| head -5
    
) else (
    echo  错误: kernel 文件不存在
)

echo.
pause
goto menu

:analyze_backup
cls
echo 分析备份分区镜像...
echo.

if not exist "%BACKUP_PATH%" (
    echo 错误: 备份目录不存在
    echo 路径: %BACKUP_PATH%
    pause
    goto menu
)

echo 备份目录内容:
dir "%BACKUP_PATH%\*.img"

echo.
echo 分析镜像文件类型...
for %%f in ("%BACKUP_PATH%\*.img") do (
    echo.
    echo 分析: %%~nxf
    echo 大小: %%~zf 字节
    wsl file "/mnt/e/twrp/Backups/Partitions_20260330_191944/%%~nxf"
)

echo.
pause
goto menu

:unpack_boot
cls
echo 解包 boot.img...
echo.

set UNPACK_DIR=%OUTPUT_PATH%\boot_analysis
if not exist "%UNPACK_DIR%" mkdir "%UNPACK_DIR%"

echo 正在解包 boot.img...
wsl mkdir -p "/mnt/e/twrp/analysis_results/boot_analysis"
wsl unpackbootimg -i "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img" -o "/mnt/e/twrp/analysis_results/boot_analysis"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo 解包成功! 输出文件:
    dir "%UNPACK_DIR%"
    
    echo.
    echo 解包结果信息:
    type "%UNPACK_DIR%\boot.img-info.txt" 2>nul || echo 信息文件不存在
    
) else (
    echo.
    echo 解包失败，可能需要安装工具:
    echo wsl sudo apt install android-sdk-libsparse-utils
)

echo.
pause
goto menu

:kernel_info
cls
echo 提取内核信息...
echo.

if not exist "%PREBUILT_PATH%\kernel" (
    echo 错误: kernel 文件不存在
    pause
    goto menu
)

echo 检查内核文件类型:
wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel"

echo.
echo 提取内核版本信息:
wsl strings "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" | grep -i "linux version" | head -10

echo.
echo 检查内核魔数:
wsl hexdump -n 16 "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" | head -5

echo.
echo 如果是压缩内核，尝试解压分析:
set TEMP_KERNEL=%OUTPUT_PATH%\kernel_decompressed
wsl gzip -dc "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" > "/mnt/e/twrp/analysis_results/kernel_decompressed" 2>&1

if %ERRORLEVEL% EQU 0 (
    echo 解压成功，分析解压后的文件:
    wsl file "/mnt/e/twrp/analysis_results/kernel_decompressed"
    echo.
    wsl strings "/mnt/e/twrp/analysis_results/kernel_decompressed" | grep -i "version magic" | head -5
) else (
    echo 可能不是 gzip 压缩格式
)

echo.
pause
goto menu

:list_images
cls
echo 所有镜像文件信息:
echo.

echo 预编译目录 (%PREBUILT_PATH%):
if exist "%PREBUILT_PATH%" (
    dir "%PREBUILT_PATH%\*.img" "%PREBUILT_PATH%\kernel"
) else (
    echo 目录不存在
)

echo.
echo 备份目录 (%BACKUP_PATH%):
if exist "%BACKUP_PATH%" (
    dir "%BACKUP_PATH%\*.img"
    
    echo.
    echo 关键分区镜像:
    echo   boot.img     - 引导分区
    echo   system.img   - 系统分区
    echo   vendor.img   - 供应商分区
    echo   dtbo.img     - 设备树 overlay
    echo   vbmeta.img   - 验证启动元数据
    echo   persist.img  - 持久数据
) else (
    echo 目录不存在
)

echo.
echo 文件类型统计:
setlocal enabledelayedexpansion
set sparse_count=0
set ext4_count=0
set bootimg_count=0
set total_count=0

for %%f in ("%BACKUP_PATH%\*.img") do (
    set /a total_count+=1
    wsl file "/mnt/e/twrp/Backups/Partitions_20260330_191944/%%~nxf" | find "Android sparse image" >nul
    if !errorlevel! equ 0 set /a sparse_count+=1
    
    wsl file "/mnt/e/twrp/Backups/Partitions_20260330_191944/%%~nxf" | find "ext4 filesystem data" >nul
    if !errorlevel! equ 0 set /a ext4_count+=1
    
    wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img" | find "Android bootimg" >nul
    if !errorlevel! equ 0 set /a bootimg_count+=1
)

echo 总镜像文件: !total_count! 个
echo sparse 镜像: !sparse_count! 个
echo ext4 文件系统: !ext4_count! 个
echo Android bootimg: !bootimg_count! 个

echo.
pause
goto menu

:generate_report
cls
echo 生成分析报告...
echo.

set REPORT_FILE=%OUTPUT_PATH%\image_analysis_report_%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%.txt

echo 镜像文件分析报告 > "%REPORT_FILE%"
echo ======================== >> "%REPORT_FILE%"
echo 生成时间: %date% %time% >> "%REPORT_FILE%"
echo 设备: 小米平板5 Pro 12.4 (dagu) >> "%REPORT_FILE%"
echo. >> "%REPORT_FILE%"

echo [预编译文件] >> "%REPORT_FILE%"
if exist "%PREBUILT_PATH%\boot.img" (
    for /f "tokens=3" %%i in ('dir "%PREBUILT_PATH%\boot.img" ^| find "boot.img"') do set boot_size=%%i
    echo boot.img: !boot_size! >> "%REPORT_FILE%"
    wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img" >> "%REPORT_FILE%"
) else (
    echo boot.img: 未找到 >> "%REPORT_FILE%"
)

if exist "%PREBUILT_PATH%\kernel" (
    for /f "tokens=3" %%i in ('dir "%PREBUILT_PATH%\kernel" ^| find "kernel"') do set kernel_size=%%i
    echo kernel: !kernel_size! >> "%REPORT_FILE%"
    wsl file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" >> "%REPORT_FILE%"
) else (
    echo kernel: 未找到 >> "%REPORT_FILE%"
)

echo. >> "%REPORT_FILE%"
echo [备份分区镜像] >> "%REPORT_FILE%"
if exist "%BACKUP_PATH%" (
    for %%f in ("%BACKUP_PATH%\*.img") do (
        echo %%~nxf: %%~zf 字节 >> "%REPORT_FILE%"
        wsl file "/mnt/e/twrp/Backups/Partitions_20260330_191944/%%~nxf" >> "%REPORT_FILE%"
    )
) else (
    echo 备份目录不存在 >> "%REPORT_FILE%"
)

echo. >> "%REPORT_FILE%"
echo [分析总结] >> "%REPORT_FILE%"
echo 1. 检查 boot.img 和 kernel 文件是否都是有效的 Android bootimg >> "%REPORT_FILE%"
echo 2. 确保 TWRP 构建使用正确的内核文件 >> "%REPORT_FILE%"
echo 3. 备份分区包含完整的系统镜像，可用于恢复 >> "%REPORT_FILE%"
echo 4. 使用 simg2img 转换 sparse 镜像以访问文件系统 >> "%REPORT_FILE%"

echo. >> "%REPORT_FILE%"
echo [建议命令] >> "%REPORT_FILE%"
echo # 解包 boot.img >> "%REPORT_FILE%"
echo wsl unpackbootimg -i /mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img -o /mnt/e/twrp/boot_analysis >> "%REPORT_FILE%"
echo. >> "%REPORT_FILE%"
echo # 提取内核信息 >> "%REPORT_FILE%"
echo wsl strings /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel ^| grep -i "linux version" >> "%REPORT_FILE%"
echo. >> "%REPORT_FILE%"
echo # 转换 sparse 镜像 >> "%REPORT_FILE%"
echo wsl simg2img /mnt/e/twrp/Backups/Partitions_20260330_191944/system.img /mnt/e/twrp/system_raw.img >> "%REPORT_FILE%"

echo 报告已生成: %REPORT_FILE%
echo.
type "%REPORT_FILE%"

echo.
pause
goto menu

:exit
echo 退出分析工具
pause
exit /b 0