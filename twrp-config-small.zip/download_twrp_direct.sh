#!/bin/bash

# 直接下载 TWRP 源码脚本
# 使用 repo 工具下载完整的 TWRP 源码树

set -e

echo "========================================"
echo "    TWRP 源码直接下载"
echo "========================================"
echo "下载目录: ~/twrp-source"
echo "分支: twrp-12.1"
echo "大小: 约 20GB"
echo "时间: 取决于网速"
echo "========================================"
echo ""

# 检查磁盘空间
echo "1. 检查磁盘空间..."
AVAILABLE_SPACE=$(df -h ~ | awk 'NR==2 {print $4}' | sed 's/G//')
echo "可用空间: ${AVAILABLE_SPACE}G"
if [ ${AVAILABLE_SPACE%.*} -lt 50 ]; then
    echo "警告: 可用空间不足 50GB"
    read -p "继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "下载取消"
        exit 1
    fi
fi

# 检查必要工具
echo ""
echo "2. 检查必要工具..."
for tool in git curl python3; do
    if command -v $tool >/dev/null 2>&1; then
        echo "  ✓ $tool 已安装"
    else
        echo "  ✗ $tool 未安装"
        echo "请先安装: sudo apt install $tool"
        exit 1
    fi
done

# 检查 repo 工具
if ! command -v repo >/dev/null 2>&1; then
    echo ""
    echo "安装 repo 工具..."
    mkdir -p ~/bin
    curl https://storage.googleapis.com/git-repo-downloads/repo > ~/bin/repo
    chmod a+x ~/bin/repo
    export PATH="$HOME/bin:$PATH"
    echo "✓ repo 工具已安装"
fi

# 创建目录
echo ""
echo "3. 创建目录..."
SOURCE_DIR="$HOME/twrp-source"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"
echo "工作目录: $(pwd)"

# 初始化 repo
echo ""
echo "4. 初始化 TWRP manifest..."
echo "使用镜像源加速下载..."
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1
if [ $? -ne 0 ]; then
    echo "初始化失败，尝试使用浅克隆..."
    repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1 --repo-url=https://gerrit-googlesource.proxy.ustclug.org/git-repo
fi

echo "✓ repo 初始化完成"

# 开始同步
echo ""
echo "5. 开始同步源码..."
echo "========================================"
echo "重要: 开始下载约 20GB 数据"
echo "这需要一些时间，请耐心等待..."
echo "进度会显示在下方"
echo "========================================"
echo ""

NUM_CPUS=$(nproc)
echo "使用 $NUM_CPUS 个并行任务下载"
echo "开始时间: $(date)"
echo ""

# 同步源码
repo sync -j$NUM_CPUS --no-tags --no-clone-bundle --current-branch

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================"
    echo "     源码同步完成!"
    echo "========================================"
    echo "完成时间: $(date)"
    echo "目录: $SOURCE_DIR"
    echo "大小: $(du -sh . | cut -f1)"
    
    # 复制设备树
    echo ""
    echo "6. 复制设备树..."
    if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
        mkdir -p device/xiaomi
        cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
        echo "✓ 设备树复制完成: device/xiaomi/dagu"
    else
        echo "⚠ 警告: 找不到设备树 /mnt/e/twrp/device/xiaomi/dagu"
    fi
    
    echo ""
    echo "7. 创建构建脚本..."
    cat > build_twrp.sh << 'EOF'
#!/bin/bash

# TWRP 构建脚本

set -e

echo "========================================"
echo "  开始构建 TWRP"
echo "========================================"

# 设置环境
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

echo ""
echo "开始构建 recovery..."
echo "这可能需要较长时间（30分钟到2小时）..."
echo "开始时间: $(date)"
echo ""

# 构建
mka recoveryimage

echo ""
echo "构建完成时间: $(date)"
echo ""

# 检查结果
if [ -f "out/target/product/dagu/recovery.img" ]; then
    echo "========================================"
    echo "  TWRP 构建成功!"
    echo "========================================"
    echo "恢复镜像: out/target/product/dagu/recovery.img"
    echo "大小: $(ls -lh out/target/product/dagu/recovery.img | awk '{print $5}')"
    
    # 复制到 Windows
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp out/target/product/dagu/recovery.img "$WINDOWS_DIR/"
    echo ""
    echo "已复制到 Windows:"
    echo "  $WINDOWS_DIR/recovery.img"
else
    echo "========================================"
    echo "  TWRP 构建失败"
    echo "========================================"
    echo "请检查构建日志"
    exit 1
fi
EOF
    
    chmod +x build_twrp.sh
    echo "✓ 构建脚本创建完成"
    
    echo ""
    echo "========================================"
    echo "     下载和准备完成!"
    echo "========================================"
    echo "下一步:"
    echo "  cd $SOURCE_DIR"
    echo "  ./build_twrp.sh"
    echo ""
    echo "或手动构建:"
    echo "  cd $SOURCE_DIR"
    echo "  source build/envsetup.sh"
    echo "  lunch twrp_dagu-eng"
    echo "  mka recoveryimage"
    
else
    echo ""
    echo "========================================"
    echo "     源码同步失败"
    echo "========================================"
    echo "请检查网络连接后重试"
    exit 1
fi