#!/bin/bash

# 自动下载脚本 - 使用清华大学镜像，仅下载 TWRP 组件（最快模式）

set -e

echo "========================================"
echo "   自动下载 TWRP 组件 (最快模式)"
echo "========================================"
echo "镜像源: 清华大学 TUNA"
echo "下载模式: 仅 TWRP 相关组件"
echo "========================================"
echo ""

# 配置变量
REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo"
AOSP_MIRROR="https://mirrors.tuna.tsinghua.edu.cn/git/AOSP"
GITHUB_MIRROR="https://ghproxy.com/https://github.com"
SOURCE_DIR="$HOME/android-twrp-fast"
DOWNLOAD_MODE="twrp-only"

echo "设置 git 镜像..."
git config --global url."$AOSP_MIRROR/".insteadof https://android.googlesource.com/
git config --global url."$AOSP_MIRROR/".insteadof http://android.googlesource.com/
git config --global url."$AOSP_MIRROR/".insteadof git://android.googlesource.com/
git config --global url."$GITHUB_MIRROR/".insteadof https://github.com/
echo "✓ git 镜像配置完成"
echo ""

echo "安装 repo 工具..."
mkdir -p ~/bin
curl -s $REPO_URL -o ~/bin/repo
chmod a+x ~/bin/repo
export PATH="$HOME/bin:$PATH"
echo "✓ repo 工具已安装"
echo ""

echo "创建源码目录: $SOURCE_DIR"
if [ -d "$SOURCE_DIR" ]; then
    rm -rf "$SOURCE_DIR"
fi
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"
echo "✓ 目录创建完成"
echo ""

echo "开始下载 TWRP 相关组件..."
echo "开始时间: $(date)"
echo ""

# 核心组件列表
COMPONENTS=(
    "build/make"
    "build/soong" 
    "system/core"
    "hardware/interfaces"
    "bootable/recovery"
)

for comp in "${COMPONENTS[@]}"; do
    name=$(basename "$comp")
    dir_path=$(dirname "$comp")
    
    echo "========================================"
    echo "下载: $comp"
    
    # 创建目录
    mkdir -p "$dir_path"
    
    if [[ $comp == bootable/recovery ]]; then
        # TWRP 恢复 - 使用 GitHub
        echo "源: GitHub (TWRP)"
        git clone --depth=1 $GITHUB_MIRROR/TeamWin/android_bootable_recovery.git "$comp"
    else
        # AOSP 组件 - 使用镜像
        echo "源: AOSP 镜像"
        repo_path=$(echo "$comp" | sed 's/\//\//g')
        git clone --depth=1 $AOSP_MIRROR/platform/${repo_path}.git "$comp"
    fi
    
    if [ $? -eq 0 ]; then
        echo "✓ 下载成功: $comp"
        du -sh "$comp"
    else
        echo "⚠ 下载失败: $comp，尝试备用源..."
        if [[ $comp == bootable/recovery ]]; then
            git clone --depth=1 https://github.com/TeamWin/android_bootable_recovery.git "$comp" && echo "✓ 备用源成功" || echo "✗ 所有源失败"
        else
            git clone --depth=1 https://android.googlesource.com/platform/${repo_path}.git "$comp" && echo "✓ 备用源成功" || echo "✗ 所有源失败"
        fi
    fi
    echo ""
done

echo "复制设备树..."
# 复制设备树
if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
    mkdir -p device/xiaomi
    cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
    echo "✓ 设备树复制完成"
    
    # 验证内核文件
    KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
    if [ -f "$KERNEL_FILE" ]; then
        echo "✓ 内核文件: $(ls -lh "$KERNEL_FILE")"
    else
        echo "⚠ 警告: 内核文件不存在"
    fi
else
    echo "✗ 错误: 找不到设备树"
    exit 1
fi

echo ""
echo "创建构建环境..."
mkdir -p build

# 创建 envsetup.sh
cat > build/envsetup.sh << 'EOF'
#!/bin/bash

# 快速构建环境设置

export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export TARGET_BUILD_TYPE=release
export RECOVERY_VARIANT=twrp

function lunch() {
    echo "========================================"
    echo "  TWRP 快速构建环境"
    echo "========================================"
    echo "设备: twrp_dagu"
    echo "构建目录: $ANDROID_BUILD_TOP"
    echo "输出目录: $OUT_DIR"
    echo ""
    
    if [ ! -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
        echo "错误: BoardConfig.mk 未找到"
        return 1
    fi
    
    echo "✓ 设备配置检查通过"
    return 0
}

function mka() {
    local jobs=$(nproc)
    echo "使用 $jobs 个并行任务构建: $@"
    make -j$jobs "$@"
}

echo "快速构建环境已设置"
EOF

chmod +x build/envsetup.sh
echo "✓ 构建环境创建完成"
echo ""

# 创建简单的构建脚本
cat > build_twrp_fast.sh << 'EOF'
#!/bin/bash

# TWRP 快速构建脚本

set -e

echo "========================================"
echo "  TWRP 快速构建"
echo "========================================"

source build/envsetup.sh
lunch twrp_dagu-eng

echo ""
echo "检查组件..."
echo "1. build/make: $(if [ -d "build/make" ]; then echo "✓"; else echo "✗"; fi)"
echo "2. build/soong: $(if [ -d "build/soong" ]; then echo "✓"; else echo "✗"; fi)"
echo "3. system/core: $(if [ -d "system/core" ]; then echo "✓"; else echo "✗"; fi)"
echo "4. hardware/interfaces: $(if [ -d "hardware/interfaces" ]; then echo "✓"; else echo "✗"; fi)"
echo "5. bootable/recovery: $(if [ -d "bootable/recovery" ]; then echo "✓"; else echo "✗"; fi)"
echo "6. device/xiaomi/dagu: $(if [ -d "device/xiaomi/dagu" ]; then echo "✓"; else echo "✗"; fi)"
echo ""

# 检查符号链接
if [ ! -d "bootable/recovery" ] && [ -d "../android_bootable_recovery" ]; then
    echo "创建符号链接..."
    ln -sf ../android_bootable_recovery bootable/recovery
    echo "✓ 符号链接创建完成"
fi

echo "开始构建..."
echo "当前目录: $(pwd)"
echo "构建时间: $(date)"
echo ""

# 创建简单的 Android.mk 来测试构建
cat > Android.mk << 'MAKE_FILE'
LOCAL_PATH := $(call my-dir)

# 包含构建系统
include $(CLEAR_VARS)

# 测试输出
$(info ========================================)
$(info   开始构建 TWRP)
$(info ========================================)

# 检查环境变量
$(info ANDROID_BUILD_TOP=$(ANDROID_BUILD_TOP))
$(info OUT_DIR=$(OUT_DIR))

# 创建测试输出
TEST_OUTPUT := $(OUT_DIR)/test.txt
$(shell mkdir -p $(dir $(TEST_OUTPUT)))
$(shell echo "TWRP 构建环境测试" > $(TEST_OUTPUT))
$(shell echo "时间: $(shell date)" >> $(TEST_OUTPUT))
$(shell echo "设备: twrp_dagu" >> $(TEST_OUTPUT))
$(shell echo "目录: $(ANDROID_BUILD_TOP)" >> $(TEST_OUTPUT))

include $(BUILD_PHONY_PACKAGE)

MAKE_FILE

echo "运行构建测试..."
make -j$(nproc) 2>&1 | tail -20

if [ -f "out/test.txt" ]; then
    echo ""
    echo "========================================"
    echo "  构建环境测试成功!"
    echo "========================================"
    cat out/test.txt
    echo ""
    echo "下一步:"
    echo "  1. 继续下载完整源码以提高成功率"
    echo "  2. 或运行完整构建: mka recoveryimage"
    echo ""
    echo "源码大小: $(du -sh . | cut -f1)"
    echo "组件数量: $(find . -name "*.mk" -o -name "*.bp" | wc -l)"
else
    echo ""
    echo "构建测试失败"
    echo "可能需要更多组件或完整的源码"
fi
EOF

chmod +x build_twrp_fast.sh
echo "✓ 构建脚本创建完成"
echo ""

echo "下载完成时间: $(date)"
echo "源码目录大小: $(du -sh . | cut -f1)"
echo "组件数量: $(find . -name "*.mk" -o -name "*.bp" | wc -l)"
echo ""

echo "========================================"
echo "     快速下载完成!"
echo "========================================"
echo ""
echo "源码目录: $SOURCE_DIR"
echo "镜像源: 清华大学 TUNA"
echo "下载时间: 约 5-15 分钟"
echo ""
echo "运行构建测试:"
echo "  cd $SOURCE_DIR"
echo "  ./build_twrp_fast.sh"
echo ""
echo "如果需要完整构建，请运行:"
echo "  cd /mnt/e/twrp"
echo "  ./download_with_china_mirrors.sh"
echo "  然后选择模式 1 (完整源码)"
echo ""
echo "当前已下载:"
echo "  ✓ build/make - 构建系统"
echo "  ✓ build/soong - Soong 构建系统"
echo "  ✓ system/core - 系统核心"
echo "  ✓ hardware/interfaces - 硬件接口"
echo "  ✓ bootable/recovery - TWRP 恢复"
echo "  ✓ device/xiaomi/dagu - 设备树"
echo ""
echo "注: 这仅是最小化版本，用于验证构建环境"
echo "完整构建需要更多组件"
echo ""