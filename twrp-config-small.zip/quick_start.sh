#!/bin/bash

# TWRP 快速开始脚本 - 小米平板5 Pro 12.4 (dagu)
# 版本: 1.0
# 日期: 2026-03-31

set -e  # 出错时退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 设备信息
DEVICE="dagu"
VENDOR="xiaomi"
TWRP_VERSION="3.7.0"

# 目录路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEVICE_TREE="$SCRIPT_DIR/device/$VENDOR/$DEVICE"
OUTPUT_DIR="$SCRIPT_DIR/output"

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_info "检查系统依赖..."
    
    local missing_deps=()
    
    # 检查基本命令
    for cmd in git curl unzip java javac python3 make; do
        if ! command -v $cmd &> /dev/null; then
            missing_deps+=($cmd)
        fi
    done
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        log_error "缺少以下依赖: ${missing_deps[*]}"
        log_info "在 Ubuntu/Debian 上安装:"
        echo "sudo apt update && sudo apt install -y git curl unzip openjdk-11-jdk python3 make"
        return 1
    fi
    
    # 检查 Java 版本
    local java_version=$(java -version 2>&1 | head -n 1 | cut -d '"' -f 2 | cut -d '.' -f 1)
    if [ "$java_version" != "11" ]; then
        log_warning "推荐使用 Java 11，当前版本: $java_version"
        log_info "设置 Java 11:"
        echo "sudo update-alternatives --config java"
    fi
    
    # 检查磁盘空间
    local available_space=$(df -BG "$SCRIPT_DIR" | awk 'NR==2 {print $4}' | tr -d 'G')
    if [ "$available_space" -lt 100 ]; then
        log_warning "可用磁盘空间不足 (${available_space}G)，推荐至少 100G"
    fi
    
    log_success "依赖检查完成"
}

# 检查设备树
check_device_tree() {
    log_info "检查设备树文件..."
    
    local required_files=(
        "AndroidProducts.mk"
        "BoardConfig.mk"
        "device.mk"
        "recovery.fstab"
        "twrp_dagu.mk"
        "vendorsetup.sh"
    )
    
    for file in "${required_files[@]}"; do
        if [ -f "$DEVICE_TREE/$file" ]; then
            log_info "  ✓ $file"
        else
            log_error "  ✗ $file 未找到"
            return 1
        fi
    done
    
    # 检查预编译文件
    if [ -f "$DEVICE_TREE/prebuilt/kernel" ]; then
        local kernel_size=$(stat -c %s "$DEVICE_TREE/prebuilt/kernel" 2>/dev/null || stat -f %z "$DEVICE_TREE/prebuilt/kernel")
        log_info "  ✓ prebuilt/kernel ($((kernel_size/1024/1024))MB)"
    else
        log_warning "  ! prebuilt/kernel 未找到，可能需要手动提取"
    fi
    
    log_success "设备树检查完成"
}

# 下载 TWRP 源码
download_twrp_source() {
    log_info "下载 TWRP 源码..."
    
    local twrp_dir="$SCRIPT_DIR/twrp-source"
    
    if [ -d "$twrp_dir/.repo" ]; then
        log_info "TWRP 源码已存在，跳过下载"
        return 0
    fi
    
    mkdir -p "$twrp_dir"
    cd "$twrp_dir"
    
    log_info "初始化 repo..."
    repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1
    
    log_info "同步源码 (这可能需要一些时间)..."
    repo sync -j$(nproc) --no-clone-bundle --no-tags --current-branch
    
    if [ $? -eq 0 ]; then
        log_success "TWRP 源码下载完成"
    else
        log_error "TWRP 源码下载失败"
        return 1
    fi
}

# 准备设备树
prepare_device_tree() {
    log_info "准备设备树..."
    
    local twrp_dir="$SCRIPT_DIR/twrp-source"
    local target_dir="$twrp_dir/device/$VENDOR/$DEVICE"
    
    if [ -d "$target_dir" ]; then
        log_info "设备树已存在，备份原文件..."
        mv "$target_dir" "${target_dir}_backup_$(date +%Y%m%d_%H%M%S)"
    fi
    
    mkdir -p "$(dirname "$target_dir")"
    
    log_info "复制设备树文件..."
    cp -r "$DEVICE_TREE" "$target_dir"
    
    if [ $? -eq 0 ]; then
        log_success "设备树准备完成"
    else
        log_error "设备树复制失败"
        return 1
    fi
}

# 设置构建环境
setup_build_env() {
    log_info "设置构建环境..."
    
    local twrp_dir="$SCRIPT_DIR/twrp-source"
    
    if [ ! -f "$twrp_dir/build/envsetup.sh" ]; then
        log_error "TWRP 源码未找到，请先运行下载步骤"
        return 1
    fi
    
    cd "$twrp_dir"
    
    log_info "初始化构建环境..."
    source build/envsetup.sh
    
    log_info "选择设备: twrp_${DEVICE}-eng"
    lunch "twrp_${DEVICE}-eng"
    
    if [ $? -eq 0 ]; then
        log_success "构建环境设置完成"
    else
        log_error "构建环境设置失败"
        return 1
    fi
}

# 构建 recovery
build_recovery() {
    log_info "开始构建 recovery..."
    
    local twrp_dir="$SCRIPT_DIR/twrp-source"
    local build_log="$OUTPUT_DIR/build.log"
    
    cd "$twrp_dir"
    
    log_info "构建日志: $build_log"
    echo "=== TWRP 构建日志 ===" > "$build_log"
    echo "开始时间: $(date)" >> "$build_log"
    echo "设备: $DEVICE" >> "$build_log"
    echo "版本: $TWRP_VERSION" >> "$build_log"
    echo "" >> "$build_log"
    
    log_info "使用 make 构建 (这可能需要 30-60 分钟)..."
    echo "开始构建: $(date)" >> "$build_log"
    
    # 开始构建
    if command -v mka &> /dev/null; then
        mka recoveryimage 2>&1 | tee -a "$build_log"
    else
        make recoveryimage -j$(nproc) 2>&1 | tee -a "$build_log"
    fi
    
    local build_result=$?
    
    echo "" >> "$build_log"
    echo "构建结束: $(date)" >> "$build_log"
    echo "退出码: $build_result" >> "$build_log"
    
    if [ $build_result -eq 0 ]; then
        log_success "构建成功完成"
        
        # 检查输出文件
        local recovery_img="$twrp_dir/out/target/product/$DEVICE/recovery.img"
        if [ -f "$recovery_img" ]; then
            local img_size=$(stat -c %s "$recovery_img" 2>/dev/null || stat -f %z "$recovery_img")
            log_success "recovery.img 生成成功: $((img_size/1024/1024))MB"
            
            # 复制到输出目录
            mkdir -p "$OUTPUT_DIR"
            cp "$recovery_img" "$OUTPUT_DIR/"
            cp "$build_log" "$OUTPUT_DIR/"
            
            log_info "输出文件已复制到: $OUTPUT_DIR"
        else
            log_error "未找到 recovery.img"
            return 1
        fi
    else
        log_error "构建失败，请查看日志: $build_log"
        return 1
    fi
}

# 创建刷机包
create_flashable_package() {
    log_info "创建刷机包..."
    
    local build_date=$(date +%Y%m%d)
    local package_name="twrp-${TWRP_VERSION}-${build_date}-${DEVICE}.zip"
    local package_dir="$OUTPUT_DIR/flashable"
    local recovery_img="$OUTPUT_DIR/recovery.img"
    
    if [ ! -f "$recovery_img" ]; then
        log_error "未找到 recovery.img，请先构建"
        return 1
    fi
    
    # 创建刷机包目录
    rm -rf "$package_dir"
    mkdir -p "$package_dir/META-INF/com/google/android"
    
    # 创建 update-binary
    cat > "$package_dir/META-INF/com/google/android/update-binary" << 'EOF'
#!/sbin/sh

OUTFD=$2
ZIP=$3

ui_print() {
    echo "ui_print $1" > /proc/self/fd/$OUTFD
    echo "ui_print" > /proc/self/fd/$OUTFD
}

ui_print " "
ui_print "========================================"
ui_print "  TWRP Recovery for Xiaomi Pad 5 Pro 12.4"
ui_print "  Device: dagu"
ui_print "========================================"
ui_print " "

mount /system

ui_print "Flashing recovery..."
dd if=/tmp/recovery.img of=/dev/block/bootdevice/by-name/recovery bs=1048576

ui_print "Cleaning up..."
umount /system

ui_print " "
ui_print "Flash complete!"
ui_print " "
EOF

    chmod 755 "$package_dir/META-INF/com/google/android/update-binary"
    
    # 创建 updater-script
    cat > "$package_dir/META-INF/com/google/android/updater-script" << 'EOF'
ui_print("TWRP Recovery for dagu");
assert(getprop("ro.product.device") == "dagu" || getprop("ro.build.product") == "dagu");
ui_print("Mounting system...");
mount("ext4", "EMMC", "/dev/block/bootdevice/by-name/system", "/system");
package_extract_file("recovery.img", "/tmp/recovery.img");
ui_print("Flashing recovery...");
run_program("/sbin/dd", "if=/tmp/recovery.img", "of=/dev/block/bootdevice/by-name/recovery");
ui_print("Unmounting system...");
unmount("/system");
ui_print("Done!");
EOF

    # 复制 recovery.img
    cp "$recovery_img" "$package_dir/"
    
    # 创建 README
    cat > "$package_dir/README.txt" << EOF
TWRP Recovery for Xiaomi Pad 5 Pro 12.4 (dagu)

Device: Xiaomi Pad 5 Pro 12.4
Codename: dagu
Model: 22071216C
Platform: Qualcomm SM8150 (Snapdragon 870)
Android Version: 13
TWRP Version: ${TWRP_VERSION}
Build Date: $(date)

Installation Instructions:
1. Copy this zip to device storage
2. Boot to existing recovery
3. Select "Install" -> "Install ZIP"
4. Select this file and flash
5. Reboot to recovery

Or via fastboot:
fastboot flash recovery recovery.img
fastboot reboot recovery

Notes:
- Unlocked bootloader required
- Backup important data before flashing
- Only for Xiaomi Pad 5 Pro 12.4 (dagu)

EOF

    # 打包
    cd "$package_dir"
    zip -r "../$package_name" . > /dev/null
    cd ..
    
    # 清理
    rm -rf "$package_dir"
    
    if [ -f "$OUTPUT_DIR/$package_name" ]; then
        local package_size=$(stat -c %s "$OUTPUT_DIR/$package_name" 2>/dev/null || stat -f %z "$OUTPUT_DIR/$package_name")
        log_success "刷机包创建成功: $package_name ($((package_size/1024/1024))MB)"
    else
        log_error "刷机包创建失败"
        return 1
    fi
}

# 显示帮助信息
show_help() {
    echo -e "${BLUE}TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)${NC}"
    echo
    echo "用法: $0 [选项]"
    echo
    echo "选项:"
    echo "  all              完整构建流程 (默认)"
    echo "  check            检查依赖和设备树"
    echo "  download         下载 TWRP 源码"
    echo "  prepare          准备设备树"
    echo "  build            构建 recovery"
    echo "  package          创建刷机包"
    echo "  clean            清理构建"
    echo "  help             显示此帮助信息"
    echo
    echo "示例:"
    echo "  $0 all          完整构建"
    echo "  $0 check        检查环境"
    echo "  $0 build        仅构建"
    echo
}

# 清理构建
clean_build() {
    log_info "清理构建..."
    
    local twrp_dir="$SCRIPT_DIR/twrp-source"
    
    if [ -d "$twrp_dir/out" ]; then
        rm -rf "$twrp_dir/out"
        log_success "清理构建输出"
    fi
    
    if [ -d "$OUTPUT_DIR" ]; then
        rm -rf "$OUTPUT_DIR"
        log_success "清理输出目录"
    fi
    
    log_success "清理完成"
}

# 主函数
main() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}  TWRP 构建脚本 - 小米平板5 Pro 12.4${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo
    
    # 创建输出目录
    mkdir -p "$OUTPUT_DIR"
    
    case "${1:-all}" in
        check)
            check_dependencies
            check_device_tree
            ;;
        download)
            download_twrp_source
            ;;
        prepare)
            prepare_device_tree
            ;;
        build)
            check_dependencies
            check_device_tree
            setup_build_env
            build_recovery
            ;;
        package)
            create_flashable_package
            ;;
        clean)
            clean_build
            ;;
        all)
            check_dependencies
            check_device_tree
            download_twrp_source
            prepare_device_tree
            setup_build_env
            build_recovery
            create_flashable_package
            ;;
        help|--help|-h)
            show_help
            exit 0
            ;;
        *)
            log_error "未知选项: $1"
            show_help
            exit 1
            ;;
    esac
    
    echo
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  操作完成！${NC}"
    echo -e "${GREEN}========================================${NC}"
    
    if [ -d "$OUTPUT_DIR" ]; then
        echo
        echo -e "${BLUE}输出文件:${NC}"
        ls -lh "$OUTPUT_DIR" | grep -v "^total"
    fi
}

# 运行主函数
main "$@"