#!/bin/bash

# 提取内核脚本
# 用于从 boot.img 中提取真正的内核

set -e

echo "================================================"
echo "     内核提取工具 - 小米平板5 Pro 12.4 (dagu)"
echo "================================================"
echo ""

# 检查工具
if ! command -v dd &> /dev/null; then
    echo "错误: 需要 dd 命令"
    exit 1
fi

# 设置路径
PROJECT_ROOT="/mnt/e/twrp"
PREBUILT_DIR="$PROJECT_ROOT/device/xiaomi/dagu/prebuilt"
BACKUP_DIR="$PROJECT_ROOT/Backups/Partitions_20260330_191944"
OUTPUT_DIR="$PROJECT_ROOT/kernel_extracted"

mkdir -p "$OUTPUT_DIR"

echo "1. 分析 boot.img 结构..."
echo ""

# 检查 prebuilt/boot.img
if [ -f "$PREBUILT_DIR/boot.img" ]; then
    echo "prebuilt/boot.img 信息:"
    ls -lh "$PREBUILT_DIR/boot.img"
    file "$PREBUILT_DIR/boot.img"
    
    # 提取内核偏移量
    echo -e "\n提取内核偏移量..."
    KERNEL_OFFSET_HEX=$(hexdump -C "$PREBUILT_DIR/boot.img" | grep -m1 "ANDROID!" | awk '{print $10$11$12$13}')
    KERNEL_OFFSET=$((0x${KERNEL_OFFSET_HEX}))
    echo "内核偏移量: 0x${KERNEL_OFFSET_HEX} (十进制: $KERNEL_OFFSET)"
    
    # 提取内核大小
    KERNEL_SIZE_HEX=$(hexdump -C "$PREBUILT_DIR/boot.img" | grep -m1 "ANDROID!" | awk '{print $14$15$16$17}')
    KERNEL_SIZE=$((0x${KERNEL_SIZE_HEX}))
    echo "内核大小: 0x${KERNEL_SIZE_HEX} (十进制: $KERNEL_SIZE 字节, $((KERNEL_SIZE/1024/1024)) MB)"
    
    # 提取内核
    echo -e "\n提取内核到: $OUTPUT_DIR/kernel_from_prebuilt.img"
    dd if="$PREBUILT_DIR/boot.img" of="$OUTPUT_DIR/kernel_from_prebuilt.img" bs=1 skip=$KERNEL_OFFSET count=$KERNEL_SIZE 2>/dev/null
    
    # 检查提取的内核
    echo "提取的内核信息:"
    file "$OUTPUT_DIR/kernel_from_prebuilt.img"
    
    # 检查是否是压缩的内核
    if file "$OUTPUT_DIR/kernel_from_prebuilt.img" | grep -q "gzip compressed data"; then
        echo "检测到 gzip 压缩内核，尝试解压..."
        mv "$OUTPUT_DIR/kernel_from_prebuilt.img" "$OUTPUT_DIR/kernel_from_prebuilt.img.gz"
        gunzip -c "$OUTPUT_DIR/kernel_from_prebuilt.img.gz" > "$OUTPUT_DIR/kernel_from_prebuilt_decompressed.img" 2>/dev/null
        echo "解压后的内核:"
        file "$OUTPUT_DIR/kernel_from_prebuilt_decompressed.img"
        
        # 检查内核版本
        echo -e "\n内核版本信息:"
        strings "$OUTPUT_DIR/kernel_from_prebuilt_decompressed.img" | grep -i "linux version" | head -3
    else
        echo -e "\n内核版本信息:"
        strings "$OUTPUT_DIR/kernel_from_prebuilt.img" | grep -i "linux version" | head -3
    fi
else
    echo "错误: $PREBUILT_DIR/boot.img 不存在"
fi

echo -e "\n2. 分析备份的 boot.img..."
echo ""

# 检查备份的 boot.img
if [ -f "$BACKUP_DIR/boot.img" ]; then
    echo "backup/boot.img 信息:"
    ls -lh "$BACKUP_DIR/boot.img"
    file "$BACKUP_DIR/boot.img"
    
    # 检查 TWRP 标记
    echo -e "\n检查 TWRP 标记:"
    hexdump -C "$BACKUP_DIR/boot.img" | grep -i "twrp" | head -5
    
    # 提取备份内核
    echo -e "\n提取内核偏移量..."
    KERNEL_OFFSET_HEX=$(hexdump -C "$BACKUP_DIR/boot.img" | grep -m1 "ANDROID!" | awk '{print $10$11$12$13}')
    KERNEL_OFFSET=$((0x${KERNEL_OFFSET_HEX}))
    echo "内核偏移量: 0x${KERNEL_OFFSET_HEX} (十进制: $KERNEL_OFFSET)"
    
    # 提取内核大小
    KERNEL_SIZE_HEX=$(hexdump -C "$BACKUP_DIR/boot.img" | grep -m1 "ANDROID!" | awk '{print $14$15$16$17}')
    KERNEL_SIZE=$((0x${KERNEL_SIZE_HEX}))
    echo "内核大小: 0x${KERNEL_SIZE_HEX} (十进制: $KERNEL_SIZE 字节, $((KERNEL_SIZE/1024/1024)) MB)"
    
    # 提取内核
    echo -e "\n提取内核到: $OUTPUT_DIR/kernel_from_backup.img"
    dd if="$BACKUP_DIR/boot.img" of="$OUTPUT_DIR/kernel_from_backup.img" bs=1 skip=$KERNEL_OFFSET count=$KERNEL_SIZE 2>/dev/null
    
    # 检查提取的内核
    echo "提取的内核信息:"
    file "$OUTPUT_DIR/kernel_from_backup.img"
    
    # 检查内核版本
    echo -e "\n内核版本信息:"
    strings "$OUTPUT_DIR/kernel_from_backup.img" | grep -i "linux version" | head -3
else
    echo "错误: $BACKUP_DIR/boot.img 不存在"
fi

echo -e "\n3. 比较两个内核..."
echo ""

if [ -f "$OUTPUT_DIR/kernel_from_prebuilt.img" ] && [ -f "$OUTPUT_DIR/kernel_from_backup.img" ]; then
    echo "文件大小比较:"
    ls -lh "$OUTPUT_DIR/kernel_from_prebuilt.img" "$OUTPUT_DIR/kernel_from_backup.img"
    
    echo -e "\n文件类型比较:"
    file "$OUTPUT_DIR/kernel_from_prebuilt.img" "$OUTPUT_DIR/kernel_from_backup.img"
    
    echo -e "\nMD5 哈希比较:"
    md5sum "$OUTPUT_DIR/kernel_from_prebuilt.img" 2>/dev/null || md5 "$OUTPUT_DIR/kernel_from_prebuilt.img"
    md5sum "$OUTPUT_DIR/kernel_from_backup.img" 2>/dev/null || md5 "$OUTPUT_DIR/kernel_from_backup.img"
    
    # 简单的字节比较
    SIZE1=$(stat -c%s "$OUTPUT_DIR/kernel_from_prebuilt.img" 2>/dev/null || stat -f%z "$OUTPUT_DIR/kernel_from_prebuilt.img")
    SIZE2=$(stat -c%s "$OUTPUT_DIR/kernel_from_backup.img" 2>/dev/null || stat -f%z "$OUTPUT_DIR/kernel_from_backup.img")
    
    if [ "$SIZE1" -eq "$SIZE2" ]; then
        echo -e "\n两个内核文件大小相同"
        # 检查前 1MB 是否相同
        cmp -n 1048576 "$OUTPUT_DIR/kernel_from_prebuilt.img" "$OUTPUT_DIR/kernel_from_backup.img" >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            echo "前 1MB 内容相同"
        else
            echo "前 1MB 内容不同"
        fi
    else
        echo -e "\n两个内核文件大小不同: $((SIZE1/1024))KB vs $((SIZE2/1024))KB"
    fi
fi

echo -e "\n4. 为 TWRP 构建准备内核..."
echo ""

# 选择要使用的内核
if [ -f "$OUTPUT_DIR/kernel_from_backup.img" ]; then
    echo "推荐使用备份中的内核（原始设备内核）"
    KERNEL_SOURCE="$OUTPUT_DIR/kernel_from_backup.img"
elif [ -f "$OUTPUT_DIR/kernel_from_prebuilt.img" ]; then
    echo "使用预编译中的内核"
    KERNEL_SOURCE="$OUTPUT_DIR/kernel_from_prebuilt.img"
else
    echo "错误: 没有找到可用的内核文件"
    exit 1
fi

# 复制到 prebuilt 目录
echo "复制内核到设备树: $PREBUILT_DIR/kernel_real"
cp "$KERNEL_SOURCE" "$PREBUILT_DIR/kernel_real"

echo -e "\n新内核信息:"
ls -lh "$PREBUILT_DIR/kernel_real"
file "$PREBUILT_DIR/kernel_real"

echo -e "\n5. 更新设备树配置建议..."
echo ""

cat << EOF
建议修改 device/xiaomi/dagu/BoardConfig.mk:

# 当前配置
TARGET_PREBUILT_KERNEL := \$(DEVICE_PATH)/prebuilt/kernel

# 建议修改为
TARGET_PREBUILT_KERNEL := \$(DEVICE_PATH)/prebuilt/kernel_real

或者使用原始 boot.img:
# TARGET_PREBUILT_KERNEL := \$(DEVICE_PATH)/prebuilt/boot.img

注意: kernel_real 是从备份 boot.img 中提取的原始内核，
而原来的 kernel 文件实际上是完整的 boot.img 格式。
EOF

echo -e "\n6. 清理临时文件..."
echo "保留提取的内核文件在: $OUTPUT_DIR/"
echo "可以删除以下临时文件:"
ls "$OUTPUT_DIR/"*.gz 2>/dev/null || true

echo -e "\n================================================"
echo "     内核提取完成!"
echo "================================================"
echo ""
echo "下一步操作:"
echo "1. 更新 BoardConfig.mk 中的 TARGET_PREBUILT_KERNEL"
echo "2. 清理 prebuilt/kernel（如果需要）"
echo "3. 重命名 kernel_real 为 kernel"
echo "4. 开始构建 TWRP"
echo ""
echo "文件位置:"
echo "- 原始备份: $BACKUP_DIR/boot.img"
echo "- 预编译文件: $PREBUILT_DIR/"
echo "- 提取的内核: $OUTPUT_DIR/"
echo "- 新内核: $PREBUILT_DIR/kernel_real"