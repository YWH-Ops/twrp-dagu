# 内核分析总结与修复方案

## 📊 分析结果

### 1. 文件状态
| 文件 | 大小 | 实际类型 | 问题 |
|------|------|----------|------|
| `prebuilt/kernel` | 128MB | Android bootimg | 错误：这是完整的 boot.img，不是纯内核 |
| `prebuilt/boot.img` | 128MB | Android bootimg | 正常：标准引导镜像 |
| `Backups/boot.img` | 192MB | Android bootimg | 正常：包含 TWRP 标记的原始设备引导镜像 |

### 2. 内核信息
- **内核版本**: `Linux version 4.19.157-perf-g5285edb4d726`
- **构建时间**: `Tue Dec 20 22:14:35 CST 2022`
- **编译器**: `clang version 10.0.7 for Android NDK`
- **平台**: ARM64 (从文件头判断)

### 3. 关键发现
1. `prebuilt/kernel` 文件被错误地命名为 "kernel"，但实际上是完整的 boot.img
2. 备份的 `boot.img` 包含 TWRP 标记 `twrpfastboot=1`
3. 两个 boot.img 大小不同（128MB vs 192MB），可能包含不同的 ramdisk
4. 真正的内核需要从 boot.img 中提取

## 🛠️ 修复步骤

### 步骤 1: 提取真正的内核
由于工具安装问题，我们使用手动方法：

```bash
# 方法 1: 直接使用备份的 boot.img 作为内核（简单方案）
cp /mnt/e/twrp/Backups/Partitions_20260330_191944/boot.img /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel_fixed

# 方法 2: 从备份 boot.img 提取内核（推荐）
# 需要先安装 android-sdk-libsparse-utils
sudo apt update
sudo apt install -y android-sdk-libsparse-utils
```

### 步骤 2: 更新设备树配置
修改 `device/xiaomi/dagu/BoardConfig.mk`:

```makefile
# 原配置（有问题）
# TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/kernel

# 新配置（使用修复后的内核）
TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/kernel_fixed

# 或者直接使用备份的 boot.img
# TARGET_PREBUILT_KERNEL := /mnt/e/twrp/Backups/Partitions_20260330_191944/boot.img
```

### 步骤 3: 验证修复
```bash
# 检查新内核文件
ls -lh /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel_fixed
file /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel_fixed

# 检查内核版本
strings /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel_fixed | grep -i "linux version" | head -3
```

## 🔧 立即执行的修复命令

### 方案 A: 使用备份的 boot.img 作为内核（推荐）
```bash
# 1. 备份原来的 kernel 文件
mv /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel.backup

# 2. 使用备份的 boot.img 作为内核
cp /mnt/e/twrp/Backups/Partitions_20260330_191944/boot.img /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel

# 3. 验证
echo "新内核大小:"
ls -lh /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel

echo "内核类型:"
file /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel
```

### 方案 B: 使用原始 prebuilt/boot.img
```bash
# 1. 备份原来的 kernel 文件
mv /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel.backup

# 2. 使用 prebuilt/boot.img 作为内核
cp /mnt/e/twrp/device/xiaomi/dagu/prebuilt/boot.img /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel

# 3. 验证
echo "新内核大小:"
ls -lh /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel

echo "内核类型:"
file /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel
```

## 📝 设备树配置建议

### 当前配置检查
检查 `device/xiaomi/dagu/BoardConfig.mk` 中的内核相关配置：

```makefile
# 内核配置 - 从dagu的boot.img中提取
BOARD_KERNEL_CMDLINE := console=ttyMSM0,115200n8 earlycon=msm_geni_serial,0xa90000 androidboot.hardware=qcom androidboot.console=ttyMSM0 androidboot.memcg=1 lpm_levels.sleep_disabled=1 video=vfb:640x400,bpp=32,memsize=3072000 msm_rtb.filter=0x237 service_locator.enable=1 swiotlb=2048 loop.max_part=7 androidboot.usbcontroller=a600000.dwc3 kpti=off
BOARD_KERNEL_BASE := 0x00000000
BOARD_KERNEL_PAGESIZE := 4096
BOARD_KERNEL_TAGS_OFFSET := 0x00000100
BOARD_RAMDISK_OFFSET := 0x01000000
BOARD_DTB_OFFSET := 0x01f00000
BOARD_KERNEL_IMAGE_NAME := Image.gz-dtb
TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/kernel
```

### 需要确认的参数
1. **BOARD_KERNEL_BASE**: `0x00000000`（看起来正确）
2. **BOARD_KERNEL_PAGESIZE**: `4096`（标准值）
3. **BOARD_RAMDISK_OFFSET**: `0x01000000`（16MB，需要验证）
4. **BOARD_DTB_OFFSET**: `0x01f00000`（31MB，需要验证）

## 🚀 构建 TWRP 的准备工作

### 1. 确保内核文件正确
```bash
# 检查内核文件是否存在且有效
if [ -f "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel" ]; then
    echo "内核文件存在"
    file "/mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel"
else
    echo "错误: 内核文件不存在"
fi
```

### 2. 验证其他必要文件
```bash
# 检查设备树文件
ls -la /mnt/e/twrp/device/xiaomi/dagu/
```

### 3. 创建构建脚本
```bash
#!/bin/bash
# build_twrp.sh

# 设置环境
cd ~/twrp-build
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

# 开始构建
mka recoveryimage

# 检查输出
if [ -f "out/target/product/dagu/recovery.img" ]; then
    echo "构建成功!"
    ls -lh out/target/product/dagu/recovery.img
else
    echo "构建失败"
fi
```

## ⚠️ 注意事项

### 1. 内核兼容性
- 确保内核版本与设备 Android 版本匹配
- 备份的 boot.img 来自实际设备，兼容性最好

### 2. 文件权限
- 确保所有文件有正确的读写权限
- 构建过程可能需要特定权限

### 3. 存储空间
- TWRP 构建需要大量磁盘空间（至少 100GB）
- 确保有足够的空间

### 4. 网络连接
- 首次构建需要下载源码（约 20GB）
- 确保网络稳定

## 📞 故障排除

### 如果构建失败：
1. **检查内核文件**：
   ```bash
   file /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel
   strings /mnt/e/twrp/device/xiaomi/dagu/prebuilt/kernel | grep -i "linux version"
   ```

2. **检查设备树配置**：
   ```bash
   grep -n "TARGET_PREBUILT_KERNEL" /mnt/e/twrp/device/xiaomi/dagu/BoardConfig.mk
   ```

3. **查看构建日志**：
   ```bash
   tail -f out/error.log
   ```

### 如果恢复无法启动：
1. **检查内核地址**：确认 `BOARD_KERNEL_BASE` 正确
2. **检查 ramdisk**：确认 `BOARD_RAMDISK_OFFSET` 正确
3. **使用 fastboot 测试**：
   ```bash
   fastboot boot out/target/product/dagu/recovery.img
   ```

## ✅ 验证步骤

1. **内核验证**：
   ```bash
   # 检查内核文件
   file device/xiaomi/dagu/prebuilt/kernel
   ```

2. **配置验证**：
   ```bash
   # 检查 BoardConfig.mk
   grep -i "kernel" device/xiaomi/dagu/BoardConfig.mk
   ```

3. **构建测试**：
   ```bash
   # 尝试构建
   source build/envsetup.sh
   lunch twrp_dagu-eng
   mka bootimage  # 先测试引导镜像
   ```

## 📋 总结

### 问题根源
`prebuilt/kernel` 文件被错误地命名为 "kernel"，但实际上是完整的 boot.img 格式。

### 解决方案
1. 使用备份的 `boot.img` 作为内核源（推荐）
2. 或使用原始的 `prebuilt/boot.img`
3. 更新 `BoardConfig.mk` 配置

### 推荐操作
```bash
# 1. 备份原文件
cp device/xiaomi/dagu/prebuilt/kernel device/xiaomi/dagu/prebuilt/kernel.backup

# 2. 使用备份的 boot.img
cp Backups/Partitions_20260330_191944/boot.img device/xiaomi/dagu/prebuilt/kernel

# 3. 开始构建
cd ~/twrp-build
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

**完成这些步骤后，您应该可以成功构建 TWRP！**