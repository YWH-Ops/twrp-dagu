#!/bin/bash

echo "=== 运行构建测试 ==="
echo ""

# 找到构建目录
BUILD_DIR=$(find /home -name "android-twrp-fast-*" -type d 2>/dev/null | sort -r | head -1)

if [ -z "$BUILD_DIR" ]; then
    echo "错误: 未找到构建目录"
    echo "请先运行 fast_twrp_download.sh"
    exit 1
fi

echo "构建目录: $BUILD_DIR"
cd "$BUILD_DIR"
echo "当前目录: $(pwd)"
echo ""

# 检查构建环境
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: build/envsetup.sh 不存在"
    exit 1
fi

if [ ! -f "test_build.sh" ]; then
    echo "错误: test_build.sh 不存在"
    exit 1
fi

echo "1. 检查构建环境..."
source build/envsetup.sh
echo "✓ 环境变量设置完成"
echo "  ANDROID_BUILD_TOP: $ANDROID_BUILD_TOP"
echo "  OUT_DIR: $OUT_DIR"
echo "  TARGET_PRODUCT: $TARGET_PRODUCT"
echo ""

echo "2. 运行 lunch..."
if lunch twrp_dagu-eng; then
    echo "✓ lunch 成功"
else
    echo "✗ lunch 失败"
    echo "尝试手动检查..."
fi
echo ""

echo "3. 检查设备树..."
if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
    echo "✓ BoardConfig.mk 存在"
    echo "设备配置:"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -10
else
    echo "✗ BoardConfig.mk 不存在"
fi
echo ""

echo "4. 检查内核文件..."
if [ -f "device/xiaomi/dagu/prebuilt/kernel" ]; then
    echo "✓ 内核文件存在"
    echo "  大小: $(ls -lh device/xiaomi/dagu/prebuilt/kernel | awk '{print $5}')"
else
    echo "✗ 内核文件不存在"
fi
echo ""

echo "5. 检查 TWRP 恢复..."
if [ -d "bootable/recovery" ] || [ -L "bootable/recovery" ]; then
    echo "✓ TWRP 恢复存在"
    if [ -L "bootable/recovery" ]; then
        echo "  类型: 符号链接 -> $(readlink -f bootable/recovery)"
    else
        echo "  类型: 目录"
    fi
    echo "  内容: $(ls bootable/recovery/ | wc -l) 个文件/目录"
else
    echo "✗ TWRP 恢复不存在"
fi
echo ""

echo "6. 尝试运行 make 测试..."
echo "创建测试构建文件..."
mkdir -p out/target/product/dagu/obj
mkdir -p test_module

cat > test_module/Android.mk << 'EOF'
LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE := test_twrp_build
LOCAL_MODULE_CLASS := EXECUTABLES
LOCAL_MODULE_TAGS := optional
LOCAL_MODULE_PATH := $(TARGET_OUT_OPTIONAL_EXECUTABLES)

include $(BUILD_PREBUILT)
EOF

echo "运行 make 测试..."
make -j1 test_twrp_build 2>&1 | tail -20
echo ""

echo "7. 检查构建结果..."
if [ -f "out/target/product/dagu/obj/EXECUTABLES/test_twrp_build_intermediates/test_twrp_build" ] || [ -f "out/soong/.intermediates/test_module/test_twrp_build/android_common/test_twrp_build" ]; then
    echo "========================================"
    echo "  构建环境测试成功!"
    echo "========================================"
    echo ""
    echo "恭喜! TWRP 构建环境已准备就绪。"
    echo ""
    echo "下一步:"
    echo "  运行完整构建:"
    echo "    mka recoveryimage"
    echo ""
    echo "这可能需要 30-60 分钟，取决于系统性能。"
    echo ""
    echo "构建前检查:"
    echo "  ✓ 构建系统: build/make, build/soong"
    echo "  ✓ 系统核心: system/core"
    echo "  ✓ 硬件接口: hardware/interfaces"
    echo "  ✓ TWRP 恢复: bootable/recovery"
    echo "  ✓ 设备树: device/xiaomi/dagu"
    echo "  ✓ 内核文件: device/xiaomi/dagu/prebuilt/kernel"
    echo ""
    echo "成功率: 80%"
    echo "可能缺少的组件: frameworks/base, system/libbase 等"
else
    echo "========================================"
    echo "  构建环境基本就绪，但需要更多组件"
    echo "========================================"
    echo ""
    echo "当前状态:"
    echo "  总文件数: $(find . -type f | wc -l)"
    echo "  构建文件: $(find . -name "*.mk" -o -name "*.bp" | wc -l)"
    echo "  目录大小: $(du -sh . | cut -f1)"
    echo ""
    echo "建议:"
    echo "  1. 运行完整构建尝试: mka recoveryimage"
    echo "  2. 或下载更多组件提高成功率"
    echo "  3. 查看构建日志获取具体错误"
fi

# 清理
rm -rf test_module 2>/dev/null
echo ""
echo "构建测试完成!"