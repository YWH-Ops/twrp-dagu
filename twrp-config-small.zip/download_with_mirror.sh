#!/bin/bash

# 使用国内镜像下载 Android 源码树
# 使用清华大学镜像源

set -e

echo "========================================"
echo "   使用国内镜像下载 Android 源码"
echo "========================================"
echo "镜像源: 清华大学 TUNA"
echo "分支: twrp-12.1"
echo "大小: 约 20GB"
echo "时间: 取决于网络速度"
echo "========================================"
echo ""

# 检查磁盘空间
echo "1. 检查磁盘空间..."
AVAILABLE_SPACE=$(df -h ~ | awk 'NR==2 {print $4}' | sed 's/G//')
echo "可用空间: ${AVAILABLE_SPACE}G"
if [ ${AVAILABLE_SPACE%.*} -lt 50 ]; then
    echo "警告: 可用空间不足 50GB，建议清理空间"
    read -p "继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "下载取消"
        exit 1
    fi
fi

# 检查必要工具
echo ""
echo "2. 检查必要工具..."
for tool in git curl python3; do
    if command -v $tool >/dev/null 2>&1; then
        echo "  ✓ $tool 已安装"
    else
        echo "  ✗ $tool 未安装"
        echo "请先安装: sudo apt install $tool"
        exit 1
    fi
done

# 检查 repo 工具
echo ""
echo "3. 检查 repo 工具..."
if ! command -v repo >/dev/null 2>&1; then
    echo "安装 repo 工具..."
    mkdir -p ~/bin
    # 使用国内镜像下载 repo
    curl -s https://mirrors.tuna.tsinghua.edu.cn/git/git-repo -o ~/bin/repo
    chmod a+x ~/bin/repo
    export PATH="$HOME/bin:$PATH"
    echo "✓ repo 工具已安装"
else
    echo "✓ repo 工具已安装: $(which repo)"
fi

# 创建目录
echo ""
echo "4. 创建目录..."
SOURCE_DIR="$HOME/android-twrp-source"
echo "源码目录: $SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"
echo "当前目录: $(pwd)"

# 配置 git（使用镜像）
echo ""
echo "5. 配置 git 使用镜像源..."
git config --global url.https://mirrors.tuna.tsinghua.edu.cn/git/AOSP/.insteadof https://android.googlesource.com/
git config --global url.https://aosp.tuna.tsinghua.edu.cn/.insteadof https://android.googlesource.com/
echo "✓ git 镜像配置完成"

# 初始化 repo 使用镜像
echo ""
echo "6. 初始化 repo（使用清华镜像）..."
echo "注意: 如果提示找不到 manifest，请按 Ctrl+C 取消"
echo "然后尝试其他方法"
echo ""

# 先设置 REPO_URL 为国内镜像
export REPO_URL='https://mirrors.tuna.tsinghua.edu.cn/git/git-repo'

# 尝试初始化 TWRP manifest
echo "初始化 TWRP manifest..."
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1 --repo-url=https://mirrors.tuna.tsinghua.edu.cn/git/git-repo

if [ $? -ne 0 ]; then
    echo ""
    echo "⚠ TWRP manifest 初始化失败，尝试 AOSP 基础源码..."
    echo "先下载 AOSP 基础源码，再添加 TWRP"
    
    # 初始化 AOSP 基础源码
    repo init -u https://mirrors.tuna.tsinghua.edu.cn/git/AOSP/platform/manifest -b android-12.1.0_r27 --depth=1 --repo-url=https://mirrors.tuna.tsinghua.edu.cn/git/git-repo
    
    if [ $? -ne 0 ]; then
        echo ""
        echo "❌ 初始化失败，尝试替代方案..."
        echo "将使用简化的源码结构"
        
        # 创建简化的 manifest
        mkdir -p .repo
        cat > .repo/manifest.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<manifest>
  <remote name="tuna"
          fetch="https://mirrors.tuna.tsinghua.edu.cn/git/AOSP/" />
  <remote name="github"
          fetch="https://github.com/" />
  
  <default revision="android-12.1.0_r27"
           remote="tuna"
           sync-j="4" />
  
  <!-- 核心 Android 仓库 -->
  <project path="build/make" name="platform/build" groups="pdk" />
  <project path="build/soong" name="platform/build/soong" groups="pdk,tradefed" />
  <project path="system/core" name="platform/system/core" groups="pdk" />
  <project path="frameworks/base" name="platform/frameworks/base" groups="pdk-cw-fs,pdk-fs" />
  <project path="hardware/interfaces" name="platform/hardware/interfaces" groups="pdk" />
  <project path="external/selinux" name="platform/external/selinux" groups="pdk" />
  
  <!-- TWRP 相关仓库 -->
  <project path="bootable/recovery" name="android_bootable_recovery" remote="github" revision="twrp-12.1" />
  
</manifest>
EOF
        
        echo "✓ 创建简化 manifest"
    fi
fi

echo "✓ repo 初始化完成"

# 开始同步
echo ""
echo "7. 开始同步源码..."
echo "========================================"
echo "重要: 开始下载 Android 源码"
echo "这需要较长时间，请耐心等待..."
echo "进度会显示在下方"
echo "========================================"
echo ""

NUM_CPUS=$(nproc)
echo "使用 $NUM_CPUS 个并行任务"
echo "开始时间: $(date)"
echo ""

# 同步源码（使用浅克隆减少下载量）
repo sync -j$NUM_CPUS --no-tags --no-clone-bundle --current-branch --optimized-fetch --prune

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================"
    echo "     源码同步完成!"
    echo "========================================"
    echo "完成时间: $(date)"
    echo "目录: $SOURCE_DIR"
    echo "大小: $(du -sh . | cut -f1)"
    
    # 检查是否下载了 bootable/recovery
    if [ ! -d "bootable/recovery" ]; then
        echo ""
        echo "下载 TWRP 恢复源码..."
        if [ -d "/mnt/e/twrp/android_bootable_recovery" ]; then
            mkdir -p bootable
            ln -sf /mnt/e/twrp/android_bootable_recovery bootable/recovery
            echo "✓ 链接现有 TWRP 源码"
        else
            echo "克隆 TWRP 恢复源码..."
            git clone --depth=1 https://github.com/TeamWin/android_bootable_recovery.git bootable/recovery || \
            git clone --depth=1 https://mirror.ghproxy.com/https://github.com/TeamWin/android_bootable_recovery.git bootable/recovery
        fi
    fi
    
    # 复制设备树
    echo ""
    echo "8. 复制设备树..."
    if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
        mkdir -p device/xiaomi
        cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
        echo "✓ 设备树复制完成: device/xiaomi/dagu"
    else
        echo "⚠ 警告: 找不到设备树"
    fi
    
    echo ""
    echo "9. 创建构建脚本..."
    cat > build_twrp_mirror.sh << 'EOF'
#!/bin/bash

# TWRP 构建脚本（镜像版）

set -e

echo "========================================"
echo "  开始构建 TWRP（使用镜像源）"
echo "========================================"

# 检查环境
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 不在 Android 源码目录"
    exit 1
fi

# 设置环境
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

echo ""
echo "开始构建 recovery..."
echo "这可能需要较长时间（30分钟到2小时）..."
echo "开始时间: $(date)"
echo ""

# 构建
mka recoveryimage

echo ""
echo "构建完成时间: $(date)"
echo ""

# 检查结果
if [ -f "out/target/product/dagu/recovery.img" ]; then
    echo "========================================"
    echo "  TWRP 构建成功!"
    echo "========================================"
    echo "恢复镜像: out/target/product/dagu/recovery.img"
    echo "大小: $(ls -lh out/target/product/dagu/recovery.img | awk '{print $5}')"
    
    # 复制到 Windows
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp out/target/product/dagu/recovery.img "$WINDOWS_DIR/"
    echo ""
    echo "已复制到 Windows:"
    echo "  $WINDOWS_DIR/recovery.img"
else
    echo "========================================"
    echo "  TWRP 构建失败"
    echo "========================================"
    echo "请检查构建日志"
    exit 1
fi
EOF
    
    chmod +x build_twrp_mirror.sh
    echo "✓ 构建脚本创建完成"
    
    echo ""
    echo "========================================"
    echo "     下载和准备完成!"
    echo "========================================"
    echo "源码目录: $SOURCE_DIR"
    echo "已下载: Android 源码 + TWRP"
    echo ""
    echo "下一步:"
    echo "  cd $SOURCE_DIR"
    echo "  ./build_twrp_mirror.sh"
    echo ""
    echo "或手动构建:"
    echo "  cd $SOURCE_DIR"
    echo "  source build/envsetup.sh"
    echo "  lunch twrp_dagu-eng"
    echo "  mka recoveryimage"
    
else
    echo ""
    echo "========================================"
    echo "     源码同步失败"
    echo "========================================"
    echo "可能的原因:"
    echo "  1. 网络连接问题"
    echo "  2. 镜像源不可用"
    echo "  3. 磁盘空间不足"
    echo ""
    echo "尝试替代方案:"
    echo "  1. 使用 VPN 或代理"
    echo "  2. 尝试其他镜像源"
    echo "  3. 手动下载必要仓库"
    exit 1
fi