#!/bin/bash

echo "========================================"
echo "TWRP 云构建 - 快速设置"
echo "========================================"
echo ""

# 检查是否在交互式终端
if [ ! -t 0 ]; then
    echo "错误：请在交互式终端中运行此脚本"
    echo "Usage: bash quick_setup.sh"
    exit 1
fi

# 获取 GitHub 用户名
read -p "请输入您的 GitHub 用户名: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "错误：GitHub 用户名不能为空"
    exit 1
fi

echo ""
echo "GitHub 用户名: $GITHUB_USERNAME"
echo "仓库名称: twrp-dagu"
echo ""

# 步骤1：设置 Git
echo "步骤1: 设置 Git 配置..."
git config --global user.name "TWRP Builder"
git config --global user.email "$GITHUB_USERNAME@users.noreply.github.com"
echo "✓ Git 配置完成"
echo ""

# 步骤2：初始化仓库
echo "步骤2: 初始化 Git 仓库..."
if [ ! -d ".git" ]; then
    git init
    echo "✓ Git 仓库初始化完成"
else
    echo "✓ Git 仓库已存在"
fi
echo ""

# 步骤3：添加文件
echo "步骤3: 添加文件到 Git..."
git add .
echo "✓ 文件添加完成"
echo ""

# 步骤4：提交更改
echo "步骤4: 提交更改..."
git commit -m "添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南"
echo "✓ 提交完成"
echo ""

# 步骤5：显示下一步操作
echo "========================================"
echo "🎯 下一步操作"
echo "========================================"
echo ""
echo "1. 创建 GitHub 仓库:"
echo "   访问 https://github.com/new"
echo ""
echo "2. 填写以下信息:"
echo "   - Repository name: twrp-dagu"
echo "   - Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
echo "   - 选择 Public (公开)"
echo "   - 不要勾选: Initialize this repository with a README"
echo "   - 不要添加 .gitignore 或 license"
echo ""
echo "3. 创建完成后，运行以下命令推送代码:"
echo ""
echo "   git remote add origin https://github.com/$GITHUB_USERNAME/twrp-dagu.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "4. 启用 GitHub Actions:"
echo "   - 访问 https://github.com/$GITHUB_USERNAME/twrp-dagu"
echo "   - 点击顶部 'Actions' 标签"
echo "   - 点击 'I understand my workflows, go ahead and enable them'"
echo ""
echo "5. 启动构建:"
echo "   - 选择 'Cloud TWRP Builder with China Mirror'"
echo "   - 点击 'Run workflow'"
echo "   - 配置参数:"
echo "        use_china_mirror: true"
echo "        build_type: minimal"
echo "        upload_artifact: true"
echo "   - 点击 'Run workflow'"
echo ""
echo "========================================"
echo "💡 提示"
echo "========================================"
echo "- 构建时间: 约 1-2 小时"
echo "- 构建产物: recovery.img"
echo "- 构建日志: 实时查看"
echo "- 国内镜像: 已启用，加速下载"
echo ""
echo "========================================"
echo "📝 保存配置"
echo "========================================"
echo "您的 GitHub 信息已保存到配置文件:"
echo ""
cat > github_config.txt << EOF
GitHub 用户名: $GITHUB_USERNAME
仓库名称: twrp-dagu
分支: main
远程地址: https://github.com/$GITHUB_USERNAME/twrp-dagu.git

下一步操作:
1. 创建仓库: https://github.com/new
2. 推送代码: git push -u origin main
3. 启用 Actions: 访问仓库的 Actions 标签
4. 启动构建: 运行 Cloud TWRP Builder

构建完成后:
1. 下载 recovery.img
2. 进入 Fastboot: adb reboot bootloader
3. 刷入恢复: fastboot flash recovery recovery.img
4. 启动恢复: fastboot boot recovery.img

文档:
- 云构建指南.md
- GITHUB_ACTIONS_GUIDE.md
- 云构建快速开始.md
EOF

echo "github_config.txt"
echo ""
echo "查看配置: cat github_config.txt"
echo ""
echo "========================================"
echo "🚀 开始构建吧！"
echo "========================================"