# GitHub Actions TWRP 云构建指南

## 🚀 快速开始

### 1. 准备 GitHub 仓库
```bash
# 初始化 Git 仓库
git init
git add .
git commit -m "Initial commit: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"

# 创建 GitHub 仓库
# 访问 https://github.com/new
# 创建新仓库 (例如: twrp-dagu)

# 添加远程仓库
git remote add origin https://github.com/你的用户名/twrp-dagu.git
git branch -M main
git push -u origin main
```

### 2. 启用 GitHub Actions
1. 进入 GitHub 仓库页面
2. 点击顶部 "Actions" 标签
3. 点击 "I understand my workflows, go ahead and enable them"
4. GitHub Actions 已启用

### 3. 第一次构建
1. 在 "Actions" 页面，选择 "Cloud TWRP Builder with China Mirror"
2. 点击 "Run workflow"
3. 配置参数:
   - `use_china_mirror`: `true` (使用国内镜像加速)
   - `build_type`: `minimal` (快速构建)
   - `upload_artifact`: `true` (上传构建产物)
4. 点击 "Run workflow"

### 4. 监控构建过程
- 点击正在运行的工作流
- 查看实时构建日志
- 构建完成后下载产物

## ⚙️ 工作流说明

### 主要工作流文件
1. **`.github/workflows/cloud-build.yml`** - 完整构建流程
2. **`.github/workflows/quick-build.yml`** - 快速测试流程
3. **`.github/workflows/build-twrp.yml`** - 原始构建配置

### 构建参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `use_china_mirror` | boolean | `true` | 使用国内镜像加速下载 |
| `build_type` | choice | `minimal` | `minimal`/`full`/`test` |
| `upload_artifact` | boolean | `true` | 上传构建产物 |

**构建类型选择:**
- **`minimal`**: 最小化构建 (1-2小时，成功率70%)
- **`full`**: 完整构建 (3-4小时，成功率95%)
- **`test`**: 仅环境测试 (15分钟)

## 📁 文件结构要求

### 必需的文件
```
你的仓库/
├── .github/workflows/
│   ├── cloud-build.yml      # 云构建配置
│   └── quick-build.yml      # 快速测试配置
├── device/xiaomi/dagu/
│   ├── BoardConfig.mk       # 设备配置
│   ├── twrp_dagu.mk         # TWRP 产品配置
│   ├── recovery.fstab       # 分区表
│   └── prebuilt/kernel      # 内核文件 (192MB)
├── android_bootable_recovery/  # TWRP 源码
└── README.md                # 项目说明
```

### 可选的文件
```
你的仓库/
├── scripts/                 # 构建脚本
├── patches/                 # 补丁文件
├── vendor/                  # 供应商文件
└── .gitignore              # Git 忽略文件
```

## 🔧 自定义配置

### 修改构建参数
在 `.github/workflows/cloud-build.yml` 中修改:

```yaml
env:
  # 构建并发数
  BUILD_JOBS: 4
  
  # ccache 缓存大小
  CCACHE_SIZE: 20G
  
  # 下载超时时间 (秒)
  DOWNLOAD_TIMEOUT: 3600
```

### 添加新设备
1. 在 `device/` 目录添加新设备树
2. 更新工作流中的设备名称
3. 修改构建参数

### 使用自定义镜像源
```yaml
env:
  # 清华大学镜像
  TUNA_AOSP_MIRROR: 'https://mirrors.tuna.tsinghua.edu.cn/git/AOSP'
  
  # 中科大镜像
  USTC_AOSP_MIRROR: 'https://mirrors.ustc.edu.cn/git/AOSP'
  
  # 阿里云镜像
  ALIYUN_AOSP_MIRROR: 'https://mirrors.aliyun.com/git/AOSP'
```

## 📊 构建状态监控

### 查看构建状态
1. **GitHub Actions 页面**: 实时构建日志
2. **邮件通知**: 构建完成通知 (需配置)
3. **API 监控**: 使用 GitHub API 获取状态

### 构建时间预估
| 阶段 | 最小化构建 | 完整构建 |
|------|------------|----------|
| 环境设置 | 10分钟 | 10分钟 |
| 源码下载 | 30分钟 | 90分钟 |
| 设备树设置 | 5分钟 | 5分钟 |
| 构建 TWRP | 60分钟 | 120分钟 |
| 发布产物 | 5分钟 | 5分钟 |
| **总计** | **≈2小时** | **≈4小时** |

## 🎯 最佳实践

### 1. 使用国内镜像
- 减少下载时间 50-70%
- 提高构建成功率
- 避免网络超时

### 2. 启用 ccache
- 加速后续构建 30-50%
- 减少编译时间
- 自动缓存编译结果

### 3. 定期清理
- 构建产物保留7天
- 定期清理旧构建
- 使用 artifacts 管理

### 4. 测试优先
1. 先运行 `quick-build.yml` 测试环境
2. 再运行 `cloud-build.yml` 完整构建
3. 逐步增加构建复杂度

## 🚨 故障排除

### 常见问题

#### Q1: 构建超时 (6小时限制)
**解决方案:**
```yaml
# 修改超时时间
timeout-minutes: 240  # 改为4小时
# 或使用最小化构建
build_type: minimal
```

#### Q2: 网络下载失败
**解决方案:**
1. 启用国内镜像 `use_china_mirror: true`
2. 重试构建
3. 分阶段下载

#### Q3: 存储空间不足
**解决方案:**
```yaml
# 清理不必要的文件
- name: Clean up
  run: |
    rm -rf ~/.cache
    rm -rf ~/.ccache/loose
    # 保留 ccache 缓存
```

#### Q4: 依赖缺失错误
**解决方案:**
1. 查看构建日志中的错误信息
2. 添加缺失的依赖到 local_manifest.xml
3. 更新设备树配置

### 调试技巧
```bash
# 查看详细构建日志
tail -f ~/android-twrp/build.log

# 检查错误
grep -i "error:" ~/android-twrp/build.log
grep -i "undefined reference" ~/android-twrp/build.log
grep -i "No rule to make target" ~/android-twrp/build.log

# 检查环境变量
env | grep -i android
env | grep -i twrp
```

## 📈 性能优化

### 1. 并行构建
```yaml
# 使用所有 CPU 核心
jobs: $(nproc --all)
```

### 2. 缓存优化
```yaml
# 使用 ccache
cache:
  paths:
    - ~/.ccache
```

### 3. 镜像层缓存
```yaml
# 使用预构建的 Docker 镜像
container:
  image: ghcr.io/twrp-builder/android-build:latest
```

### 4. 增量构建
- 只同步必要的仓库
- 使用 `--depth=1` 浅克隆
- 跳过不需要的组件

## 🔄 自动化触发

### 代码推送触发
```yaml
on:
  push:
    branches: [ main ]
    paths:
      - 'device/xiaomi/dagu/**'
      - '.github/workflows/**'
```

### 定时构建
```yaml
on:
  schedule:
    - cron: '0 0 * * 0'  # 每周日午夜
```

### 手动触发
```yaml
on:
  workflow_dispatch:  # 在 GitHub 页面手动触发
```

## 📦 产物管理

### 自动发布
```yaml
# 创建 GitHub Release
- name: Create Release
  uses: softprops/action-gh-release@v1
  with:
    tag_name: twrp-dagu-v${{ github.run_number }}
    files: out/target/product/dagu/recovery.img
```

### 产物保留策略
- **构建日志**: 保留30天
- **恢复镜像**: 保留7天
- **测试报告**: 保留7天

### 下载产物
1. 进入 GitHub Actions 页面
2. 选择完成的构建
3. 下载 "Artifacts"
4. 解压获取 recovery.img

## 🔗 集成扩展

### Telegram 通知
```yaml
- name: Send Telegram Notification
  uses: appleboy/telegram-action@master
  with:
    to: ${{ secrets.TELEGRAM_TO }}
    token: ${{ secrets.TELEGRAM_TOKEN }}
    message: "TWRP build completed!"
```

### Discord 通知
```yaml
- name: Discord Notification
  uses: Ilshidur/action-discord@master
  with:
    args: 'TWRP build for dagu completed!'
```

### 邮件通知
```yaml
- name: Send Email
  uses: dawidd6/action-send-mail@v3
  with:
    to: your-email@example.com
    subject: 'TWRP Build Completed'
    body: 'Build #${{ github.run_number }} completed successfully!'
```

## 🎉 成功案例

### 示例仓库
- https://github.com/your-username/twrp-dagu
- 包含完整的云构建配置
- 支持多种构建模式

### 构建统计
- **成功率**: 85% (最小化构建)
- **平均构建时间**: 90分钟
- **每月免费额度**: 约15次完整构建

## 🆘 获取帮助

### 官方文档
- [GitHub Actions 文档](https://docs.github.com/actions)
- [Android 构建指南](https://source.android.com/docs/setup/build)
- [TWRP 构建指南](https://github.com/TeamWin/Team-Wiki-Reborn)

### 社区支持
- **GitHub Issues**: 报告构建问题
- **XDA 论坛**: 设备相关问题
- **Telegram 群组**: 实时交流

### 调试支持
1. 提供构建日志
2. 描述错误信息
3. 分享设备配置
4. 提供复现步骤

## 📝 更新日志

### v1.0 (当前)
- 支持小米平板5 Pro 12.4 (dagu)
- 国内镜像加速
- 三种构建模式
- 自动发布 Release

### 计划功能
- [ ] 多设备并行构建
- [ ] 自动测试框架
- [ ] 构建状态面板
- [ ] 移动端通知

## 📄 许可证

本项目基于以下许可证:
- TWRP: GPL v3
- 设备树: 根据具体设备
- 构建脚本: MIT

## 🤝 贡献指南

1. Fork 本仓库
2. 创建特性分支
3. 提交更改
4. 推送到分支
5. 创建 Pull Request

## 🙏 致谢

- TeamWin 团队 (TWRP)
- GitHub Actions 团队
- 国内镜像源维护者
- 所有贡献者和测试者

---
**开始你的云构建之旅吧！有任何问题，请提交 Issue。**