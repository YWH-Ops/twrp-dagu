#!/bin/bash

# 简化版 TWRP 构建脚本

set -e

echo "========================================"
echo "  TWRP 构建脚本 - 简化版"
echo "========================================"
echo ""

# 检查是否在 TWRP 源码目录
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 不在 TWRP 源码目录"
    echo "请先运行:"
    echo "  cd ~/twrp-build"
    echo "  或"
    echo "  cd /mnt/e/twrp 然后运行下载脚本"
    exit 1
fi

echo "1. 初始化环境..."
source build/envsetup.sh
echo "✓ 环境初始化完成"
echo ""

echo "2. 选择设备..."
lunch twrp_dagu-eng
echo "✓ 设备选择完成"
echo ""

echo "3. 检查内核文件..."
KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$KERNEL_FILE")"
else
    echo "✗ 错误: 内核文件不存在"
    echo "请检查 device/xiaomi/dagu/prebuilt/kernel"
    exit 1
fi
echo ""

echo "4. 开始构建 recovery..."
echo "这可能需要较长时间（30分钟到2小时）..."
echo "开始时间: $(date)"
echo ""
echo "构建日志将输出到屏幕，请耐心等待..."
echo ""

# 构建 recovery
mka recoveryimage

echo ""
echo "构建完成时间: $(date)"
echo ""

echo "5. 检查构建结果..."
OUTPUT_FILE="out/target/product/dagu/recovery.img"
if [ -f "$OUTPUT_FILE" ]; then
    echo "✓ TWRP 构建成功!"
    echo ""
    echo "恢复镜像信息:"
    echo "  位置: $OUTPUT_FILE"
    echo "  大小: $(ls -lh "$OUTPUT_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$OUTPUT_FILE")"
    
    # 复制到 Windows 目录
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp "$OUTPUT_FILE" "$WINDOWS_DIR/"
    echo ""
    echo "已复制到 Windows:"
    echo "  $WINDOWS_DIR/recovery.img"
    
    # 创建简单的刷机包
    echo ""
    echo "6. 创建刷机包..."
    cd "$WINDOWS_DIR"
    PACKAGE_NAME="twrp-dagu-$(date +%Y%m%d).zip"
    zip "$PACKAGE_NAME" recovery.img > /dev/null
    echo "刷机包: $PACKAGE_NAME"
    echo "大小: $(ls -lh "$PACKAGE_NAME" | awk '{print $5}')"
    
    echo ""
    echo "========================================"
    echo "  构建完成!"
    echo "========================================"
    echo ""
    echo "输出文件:"
    echo "  1. $OUTPUT_FILE"
    echo "  2. $WINDOWS_DIR/recovery.img"
    echo "  3. $WINDOWS_DIR/$PACKAGE_NAME"
    echo ""
    echo "使用说明:"
    echo "  测试: fastboot boot $WINDOWS_DIR/recovery.img"
    echo "  刷入: fastboot flash recovery $WINDOWS_DIR/recovery.img"
    echo "  刷机包: 在恢复模式中刷入"
    
else
    echo "✗ TWRP 构建失败"
    echo ""
    echo "可能的原因:"
    echo "  1. 内核文件不正确"
    echo "  2. 设备树配置错误"
    echo "  3. 构建环境问题"
    echo "  4. 磁盘空间不足"
    echo ""
    echo "检查日志:"
    echo "  tail -100 out/error.log 2>/dev/null || echo '无错误日志'"
    exit 1
fi