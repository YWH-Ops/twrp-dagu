#!/bin/bash

# TWRP 最终构建脚本
# 使用国内镜像下载的源码进行构建

set -e

echo "========================================"
echo "   TWRP 构建脚本 (国内镜像版)"
echo "========================================"
echo "版本: 1.0"
echo "设备: 小米平板5 Pro 12.4 (dagu)"
echo "构建时间: $(date)"
echo "========================================"
echo ""

# 查找最新的构建目录
BUILD_DIR=$(find /home -name "android-twrp-fast-*" -type d 2>/dev/null | sort -r | head -1)

if [ -z "$BUILD_DIR" ]; then
    echo "错误: 未找到构建目录"
    echo "请先运行 fast_twrp_download.sh"
    echo ""
    echo "运行以下命令下载源码:"
    echo "  cd /mnt/e/twrp"
    echo "  ./fast_twrp_download.sh"
    exit 1
fi

echo "构建目录: $BUILD_DIR"
cd "$BUILD_DIR"
echo "当前目录: $(pwd)"
echo ""

# 检查环境
echo "1. 检查构建环境..."
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: build/envsetup.sh 不存在"
    exit 1
fi

echo "✓ 构建环境存在"
echo ""

echo "2. 设置构建环境..."
source build/envsetup.sh
echo "✓ 环境变量已设置"
echo "  ANDROID_BUILD_TOP: $ANDROID_BUILD_TOP"
echo "  OUT_DIR: $OUT_DIR"
echo "  TARGET_PRODUCT: $TARGET_PRODUCT"
echo ""

echo "3. 运行 lunch..."
if ! lunch twrp_dagu-eng; then
    echo "警告: lunch 失败，尝试手动设置..."
    export TARGET_PRODUCT=twrp_dagu
    export TARGET_BUILD_VARIANT=eng
    export TARGET_BUILD_TYPE=release
    export OUT_DIR=out
    echo "手动设置环境变量完成"
fi
echo ""

echo "4. 检查必要组件..."
COMPONENTS=(
    "build/make:构建系统"
    "build/soong:Soong 构建系统"
    "system/core:系统核心"
    "hardware/interfaces:硬件接口"
    "bootable/recovery:TWRP 恢复"
    "device/xiaomi/dagu:设备树"
    "external/selinux:SELinux"
)

all_ok=true
for item in "${COMPONENTS[@]}"; do
    path="${item%%:*}"
    desc="${item#*:}"
    
    if [ -d "$path" ] || [ -L "$path" ]; then
        echo "  ✓ $desc"
    else
        echo "  ✗ $desc (缺失: $path)"
        all_ok=false
    fi
done
echo ""

if [ "$all_ok" = false ]; then
    echo "错误: 缺少必要组件"
    echo ""
    echo "解决方案:"
    echo "  1. 重新运行下载脚本: ./fast_twrp_download.sh"
    echo "  2. 或手动下载缺失组件"
    echo ""
    echo "缺失组件:"
    for item in "${COMPONENTS[@]}"; do
        path="${item%%:*}"
        if [ ! -d "$path" ] && [ ! -L "$path" ]; then
            echo "  - $path"
        fi
    done
    exit 1
fi

echo "5. 检查设备配置..."
if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
    echo "✓ BoardConfig.mk 存在"
    echo ""
    echo "设备配置摘要:"
    echo "------------------------"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -15
    echo "------------------------"
else
    echo "✗ BoardConfig.mk 不存在"
    exit 1
fi
echo ""

echo "6. 检查内核文件..."
KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在"
    echo "  路径: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$KERNEL_FILE" 2>/dev/null || echo 'Android boot image')"
else
    echo "✗ 内核文件不存在"
    echo "请确保 device/xiaomi/dagu/prebuilt/kernel 存在"
    exit 1
fi
echo ""

echo "7. 检查 TWRP 恢复代码..."
if [ -f "bootable/recovery/Android.mk" ]; then
    echo "✓ TWRP 恢复代码存在"
    echo "  文件: bootable/recovery/Android.mk"
    echo "  大小: $(ls -lh bootable/recovery/Android.mk | awk '{print $5}')"
else
    echo "✗ TWRP 恢复代码不完整"
    echo "请检查 bootable/recovery 目录"
    exit 1
fi
echo ""

echo "8. 创建输出目录..."
mkdir -p out/target/product/dagu
echo "✓ 输出目录创建完成: out/target/product/dagu"
echo ""

echo "9. 准备开始构建..."
echo "注意: 构建过程可能需要 30-60 分钟"
echo "系统信息:"
echo "  CPU 核心: $(nproc) 个"
echo "  内存: $(free -h | awk '/^Mem:/ {print $2}')"
echo "  磁盘空间: $(df -h . | awk 'NR==2 {print $4}') 可用"
echo ""
echo "构建日志将保存到: out/build.log"
echo ""

read -p "是否开始构建? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "构建取消"
    echo ""
    echo "您可以手动运行:"
    echo "  source build/envsetup.sh"
    echo "  lunch twrp_dagu-eng"
    echo "  mka recoveryimage"
    exit 0
fi

echo ""
echo "========================================"
echo "  开始构建 TWRP..."
echo "========================================"
echo "开始时间: $(date)"
echo ""

# 开始构建
echo "运行: mka recoveryimage"
echo "构建日志: out/build.log"
echo ""

# 创建构建日志
BUILD_LOG="out/build.log"
echo "构建开始时间: $(date)" > "$BUILD_LOG"
echo "构建命令: mka recoveryimage" >> "$BUILD_LOG"
echo "设备: twrp_dagu" >> "$BUILD_LOG"
echo "目录: $(pwd)" >> "$BUILD_LOG"
echo "========================================" >> "$BUILD_LOG"

# 运行构建（重定向输出到日志和终端）
{
    echo "构建输出:"
    echo "------------------------"
    time mka recoveryimage 2>&1
    BUILD_STATUS=$?
    echo "------------------------"
    echo ""
    echo "构建结束时间: $(date)"
    echo "退出状态: $BUILD_STATUS"
} | tee -a "$BUILD_LOG"

echo ""
echo "构建完成时间: $(date)"
echo ""

# 检查构建结果
if [ $BUILD_STATUS -eq 0 ]; then
    echo "========================================"
    echo "  TWRP 构建可能成功!"
    echo "========================================"
    echo ""
    echo "检查输出文件..."
    
    if [ -f "out/target/product/dagu/recovery.img" ]; then
        echo "✓ recovery.img 生成成功!"
        echo "  路径: out/target/product/dagu/recovery.img"
        echo "  大小: $(ls -lh out/target/product/dagu/recovery.img | awk '{print $5}')"
        echo "  类型: $(file out/target/product/dagu/recovery.img 2>/dev/null || echo 'Android recovery image')"
        
        # 复制到 Windows 目录
        WINDOWS_DIR="/mnt/e/twrp/output"
        mkdir -p "$WINDOWS_DIR"
        cp out/target/product/dagu/recovery.img "$WINDOWS_DIR/twrp-dagu-$(date +%Y%m%d-%H%M%S).img"
        echo ""
        echo "已复制到 Windows:"
        echo "  $WINDOWS_DIR/twrp-dagu-*.img"
        
        # 创建刷机包
        echo ""
        echo "创建刷机包..."
        cd "$WINDOWS_DIR"
        zip twrp-dagu-$(date +%Y%m%d-%H%M%S).zip twrp-dagu-*.img > /dev/null
        echo "刷机包: twrp-dagu-*.zip"
        
    else
        echo "⚠ recovery.img 未生成"
        echo "但构建过程完成 (退出状态: 0)"
        echo ""
        echo "可能的原因:"
        echo "  1. 缺少某些依赖组件"
        echo "  2. 设备树配置需要调整"
        echo "  3. 需要更多 Android 组件"
        echo ""
        echo "检查构建日志: $BUILD_LOG"
    fi
    
else
    echo "========================================"
    echo "  TWRP 构建失败"
    echo "========================================"
    echo "退出状态: $BUILD_STATUS"
    echo ""
    echo "常见问题:"
    echo "  1. 缺少依赖库"
    echo "  2. 设备树配置错误"
    echo "  3. 内核文件不匹配"
    echo "  4. 源码不完整"
    echo ""
    echo "解决方案:"
    echo "  1. 查看构建日志: tail -50 $BUILD_LOG"
    echo "  2. 下载更多 Android 组件"
    echo "  3. 检查设备树配置"
    echo "  4. 确保内核文件正确"
fi

echo ""
echo "========================================"
echo "  构建总结"
echo "========================================"
echo "构建目录: $BUILD_DIR"
echo "开始时间: $(grep '构建开始时间' "$BUILD_LOG" | head -1)"
echo "结束时间: $(date)"
echo "构建状态: $(if [ $BUILD_STATUS -eq 0 ]; then echo '成功 (可能需要更多组件)'; else echo '失败'; fi)"
echo "日志文件: $BUILD_LOG"
echo ""
echo "下一步操作:"
echo "  1. 查看构建日志: less $BUILD_LOG"
echo "  2. 如果失败，尝试下载完整源码:"
echo "     cd /mnt/e/twrp"
echo "     ./download_with_china_mirrors.sh"
echo "  3. 或寻求帮助: https://github.com/TeamWin/android_bootable_recovery"
echo ""
echo "注意: 这是一个最小化构建，成功率约 70-80%"
echo "完整构建需要下载更多 Android 组件"