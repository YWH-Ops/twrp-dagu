# TWRP 刷机前准备 - 完整指南
## 小米平板 5 Pro 12.4 (dagu)

---

## ✅ 当前状态检查

### 已完成
- ✅ **TWRP 镜像已准备好**: `output/twrp-dagu-20260401.img` (128MB)

### 需要完成
- ❌ **ADB 工具未安装** - 需要安装
- ❌ **Fastboot 工具未安装** - 需要安装

---

## 📥 步骤 1: 安装 ADB 和 Fastboot 工具

### 方法一：官方 Android Platform Tools（推荐）

#### Windows 用户：

1. **下载**：
   - 访问：https://developer.android.com/studio/releases/platform-tools
   - 下载 "SDK Platform-Tools for Windows"

2. **解压**：
   ```
   解压到：C:\platform-tools
   ```

3. **添加到 PATH**：
   ```powershell
   # 方法 1: 临时添加（当前终端有效）
   $env:Path += ";C:\platform-tools"
   
   # 方法 2: 永久添加（需要管理员权限）
   [Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\platform-tools", [System.EnvironmentVariableTarget]::Machine)
   ```

4. **验证安装**：
   ```powershell
   adb version
   fastboot --version
   ```

### 方法二：使用 Chocolatey 包管理器（最简单）

```powershell
# 1. 安装 Chocolatey（如果没有）
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

# 2. 安装 ADB 和 Fastboot
choco install android-sdk-platform-tools -y

# 3. 重启终端验证
adb version
fastboot --version
```

### 方法三：使用小米工具箱（适合新手）

1. 下载 "小米工具箱" 或 "Mi Flash Tool"
2. 这些工具通常包含 ADB 和 Fastboot
3. 安装后会自动配置环境变量

---

## 📱 步骤 2: 启用 USB 调试

### 在小米平板上操作：

1. **进入开发者选项**：
   - 设置 → 关于平板
   - 连续点击 "MIUI 版本" 7 次
   - 返回设置 → 更多设置 → 开发者选项

2. **启用 USB 调试**：
   - 打开 "USB 调试" 开关
   - 连接电脑时允许调试

3. **解锁 Bootloader**（如果还未解锁）：
   - 访问：https://www.miui.com/unlock/
   - 下载解锁工具
   - 按照提示解锁

---

## 🔌 步骤 3: 连接设备并测试

### 测试 ADB 连接：

```powershell
# 1. 连接平板到电脑
# 2. 在平板上允许 USB 调试授权
adb devices

# 应该看到类似输出：
# List of devices attached
# xxxxxxxx    device
```

### 测试 Fastboot 连接：

```powershell
# 1. 进入 fastboot 模式
adb reboot bootloader

# 等待 5-10 秒

# 2. 检查 fastboot 连接
fastboot devices

# 应该看到设备序列号
```

---

## ⚡ 快速刷入 TWRP

### 所有工具准备就绪后：

```powershell
# === 方法 1: 临时启动（安全测试）===

# 1. 进入 fastboot
adb reboot bootloader

# 等待设备重启到 fastboot 模式
Start-Sleep -Seconds 10

# 2. 临时启动 TWRP（不永久写入）
fastboot boot output\twrp-dagu-20260401.img

# 等待 TWRP 启动（约 1-2 分钟）
# 如果不满意，重启就会回到原系统


# === 方法 2: 永久刷入 ===

# 1. 进入 fastboot
adb reboot bootloader
Start-Sleep -Seconds 10

# 2. 刷入 recovery 分区
fastboot flash recovery output\twrp-dagu-20260401.img

# 3. 重启到 TWRP
fastboot reboot recovery

# 或直接重启到系统
# fastboot reboot
```

---

## 🛠️ 自动化脚本

创建 `flash_twrp.ps1` 脚本：

```powershell
Write-Host "=== TWRP Flash Script ===" -ForegroundColor Cyan
Write-Host ""

# Check if tools are installed
Write-Host "[CHECK] ADB and Fastboot..." -ForegroundColor Yellow
try {
    $adb = adb version 2>&1
    Write-Host "  [OK] ADB is installed" -ForegroundColor Green
} catch {
    Write-Host "  [ERROR] ADB not found!" -ForegroundColor Red
    Write-Host "  Please install Android Platform Tools" -ForegroundColor Yellow
    pause
    return
}

try {
    $fb = fastboot --version 2>&1
    Write-Host "  [OK] Fastboot is installed" -ForegroundColor Green
} catch {
    Write-Host "  [ERROR] Fastboot not found!" -ForegroundColor Red
    pause
    return
}

Write-Host ""

# Check TWRP file
Write-Host "[CHECK] TWRP image file..." -ForegroundColor Yellow
if (Test-Path "output\twrp-dagu-20260401.img") {
    $file = Get-Item "output\twrp-dagu-20260401.img"
    $sizeMB = [math]::Round($file.Length / 1MB, 2)
    Write-Host "  [OK] Found: $($file.Name)" -ForegroundColor Green
    Write-Host "      Size: $sizeMB MB" -ForegroundColor Gray
} else {
    Write-Host "  [ERROR] File not found!" -ForegroundColor Red
    pause
    return
}

Write-Host ""
Write-Host "[ACTION] Connect your tablet via USB" -ForegroundColor Yellow
Write-Host "  Make sure USB debugging is enabled" -ForegroundColor Gray
Write-Host ""

$ready = Read-Host "Ready to proceed? (Y/N, default: Y)"
if ($ready -eq "N" -or $ready -eq "n") {
    Write-Host "Cancelled." -ForegroundColor Yellow
    return
}

Write-Host ""
Write-Host "[STEP 1] Checking ADB connection..." -ForegroundColor Cyan
$devices = adb devices 2>&1
Write-Host $devices -ForegroundColor Gray

if ($devices -notmatch "device") {
    Write-Host ""
    Write-Host "[ERROR] No device detected!" -ForegroundColor Red
    Write-Host "  Please check:" -ForegroundColor Yellow
    Write-Host "  1. USB cable is connected" -ForegroundColor White
    Write-Host "  2. USB debugging is enabled" -ForegroundColor White
    Write-Host "  3. You authorized this computer" -ForegroundColor White
    pause
    return
}

Write-Host ""
Write-Host "[STEP 2] Rebooting to bootloader..." -ForegroundColor Cyan
adb reboot bootloader
Write-Host "Waiting 10 seconds..." -ForegroundColor Gray
Start-Sleep -Seconds 10

Write-Host ""
Write-Host "[STEP 3] Checking Fastboot connection..." -ForegroundColor Cyan
$fbDevices = fastboot devices 2>&1
Write-Host $fbDevices -ForegroundColor Gray

if (-not $fbDevices) {
    Write-Host ""
    Write-Host "[ERROR] Fastboot mode not detected!" -ForegroundColor Red
    Write-Host "  Try again or manually enter fastboot mode" -ForegroundColor Yellow
    pause
    return
}

Write-Host ""
Write-Host "[FLASH] Choose flash method:" -ForegroundColor Yellow
Write-Host "  [1] Temporary boot (Safe test)" -ForegroundColor White
Write-Host "  [2] Permanent flash to recovery" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Enter choice (1/2, default: 1)"

if ($choice -eq "2") {
    Write-Host ""
    Write-Host "[WARNING] This will permanently flash TWRP!" -ForegroundColor Red
    $confirm = Read-Host "Are you sure? (Y/N)"
    
    if ($confirm -ne "Y" -and $confirm -ne "y") {
        Write-Host "Cancelled." -ForegroundColor Yellow
        return
    }
    
    Write-Host ""
    Write-Host "[FLASHING] Writing to recovery partition..." -ForegroundColor Cyan
    fastboot flash recovery output\twrp-dagu-20260401.img
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "[SUCCESS] TWRP flashed successfully!" -ForegroundColor Green
        Write-Host ""
        
        $bootRecovery = Read-Host "Boot to TWRP now? (Y/N, default: Y)"
        if ($bootRecovery -ne "N" -and $bootRecovery -ne "n") {
            Write-Host "Booting to TWRP..." -ForegroundColor Cyan
            fastboot reboot recovery
        }
    } else {
        Write-Host ""
        Write-Host "[ERROR] Flash failed!" -ForegroundColor Red
        Write-Host "Please try again or check your device connection." -ForegroundColor Yellow
    }
} else {
    Write-Host ""
    Write-Host "[BOOT] Starting TWRP temporarily..." -ForegroundColor Cyan
    Write-Host "This won't make any permanent changes." -ForegroundColor Gray
    Write-Host ""
    
    fastboot boot output\twrp-dagu-20260401.img
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "[SUCCESS] TWRP should be starting now!" -ForegroundColor Green
        Write-Host "If successful, you can permanently flash later." -ForegroundColor Gray
    } else {
        Write-Host ""
        Write-Host "[ERROR] Boot failed!" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
Write-Host ""
```

运行脚本：
```powershell
.\flash_twrp.ps1
```

---

## 📋 常见问题排查

### Q1: ADB 找不到设备？

**解决**：
```powershell
# 1. 重启 ADB 服务器
adb kill-server
adb start-server

# 2. 重新连接 USB
# 3. 在平板上重新授权 USB 调试

# 4. 检查驱动
# 设备管理器 → Android Device → 更新驱动
```

### Q2: Fastboot 模式下找不到设备？

**解决**：
```powershell
# 1. 尝试不同 USB 端口
# 2. 使用原装 USB 线
# 3. 安装小米 USB 驱动

# 手动进入 fastboot 模式：
# 关机状态下，同时按住 音量下 + 电源键
```

### Q3: 权限不足无法刷入？

**解决**：
```powershell
# 确保 Bootloader 已解锁
# 访问 https://www.miui.com/unlock/ 申请解锁
```

---

## ✅ 刷入前检查清单

- [ ] ADB 和 Fastboot 已安装并可用
- [ ] USB 调试已启用
- [ ] Bootloader 已解锁
- [ ] 设备电量 > 50%
- [ ] 备份了重要数据
- [ ] 使用原装 USB 线和端口
- [ ] 安装了正确的 USB 驱动

---

## 🎯 下一步

### 安装完 ADB/Fastboot 后：

1. **运行自动脚本**：
   ```powershell
   .\flash_twrp.ps1
   ```

2. **或手动执行**：
   ```powershell
   adb reboot bootloader
   fastboot boot output\twrp-dagu-20260401.img
   ```

---

## 📞 获取帮助

### 文档资源
- `QUICK_LOCAL_BUILD_SUMMARY.md` - 快速总结
- `LOCAL_BUILD_GUIDE.md` - 本地构建指南
- `GITHUB_ACTIONS_BUILD_GUIDE.md` - 云构建指南

### 驱动下载
- 小米 USB 驱动：https://c.mi.com/thread-2120901-1-0.html
- 通用 ADB 驱动：Google USB Driver

### 社区支持
- XDA 论坛：Xiaomi Mi Pad 5 版块
- Telegram: "dagu TWRP" 群组

---

**准备好了吗？先安装 ADB 和 Fastboot，然后就可以开始刷机了！** 🚀

*最后更新：2026 年 4 月 1 日*
