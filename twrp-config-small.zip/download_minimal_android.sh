#!/bin/bash

# 最小化 Android 源码下载
# 只下载构建 TWRP 必需的几个核心仓库

set -e

echo "========================================"
echo "   最小化 Android 源码下载"
echo "========================================"
echo "只下载构建 TWRP 必需的核心仓库"
echo "大小: 约 1-2GB"
echo "时间: 10-30分钟"
echo "========================================"
echo ""

SOURCE_DIR="$HOME/android-minimal"
echo "创建目录: $SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"
echo "当前目录: $(pwd)"
echo ""

# 使用镜像源
MIRROR="https://mirrors.tuna.tsinghua.edu.cn/git/AOSP"

# 1. 下载构建系统
echo "1. 下载构建系统 (build/make)..."
mkdir -p build
if [ ! -d "build/make" ]; then
    echo "克隆: platform/build -> build/make"
    git clone --depth=1 "$MIRROR/platform/build.git" build/make || \
    git clone --depth=1 "https://github.com/LineageOS/android_build.git" build/make
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 2. 下载构建 soong
echo "2. 下载构建系统 (build/soong)..."
if [ ! -d "build/soong" ]; then
    echo "克隆: platform/build/soong -> build/soong"
    git clone --depth=1 "$MIRROR/platform/build/soong.git" build/soong || \
    git clone --depth=1 "https://github.com/LineageOS/android_build_soong.git" build/soong
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 3. 下载系统核心
echo "3. 下载系统核心 (system/core)..."
mkdir -p system
if [ ! -d "system/core" ]; then
    echo "克隆: platform/system/core -> system/core"
    git clone --depth=1 "$MIRROR/platform/system/core.git" system/core || \
    git clone --depth=1 "https://github.com/LineageOS/android_system_core.git" system/core
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 4. 下载框架
echo "4. 下载框架 (frameworks/base)..."
mkdir -p frameworks
if [ ! -d "frameworks/base" ]; then
    echo "克隆: platform/frameworks/base -> frameworks/base"
    git clone --depth=1 "$MIRROR/platform/frameworks/base.git" frameworks/base || \
    git clone --depth=1 "https://github.com/LineageOS/android_frameworks_base.git" frameworks/base
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 5. 下载硬件接口
echo "5. 下载硬件接口 (hardware/interfaces)..."
mkdir -p hardware
if [ ! -d "hardware/interfaces" ]; then
    echo "克隆: platform/hardware/interfaces -> hardware/interfaces"
    git clone --depth=1 "$MIRROR/platform/hardware/interfaces.git" hardware/interfaces || \
    git clone --depth=1 "https://github.com/LineageOS/android_hardware_interfaces.git" hardware/interfaces
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 6. 下载必要的库
echo "6. 下载必要的库..."

# 外部库列表（构建 TWRP 必需）
EXTERNAL_LIBS=(
    "external/selinux"
    "external/libpng"
    "external/libjpeg-turbo"
    "external/freetype"
    "external/zlib"
    "external/bzip2"
    "external/openssl"
)

for lib in "${EXTERNAL_LIBS[@]}"; do
    lib_name=$(basename "$lib")
    if [ ! -d "$lib" ]; then
        echo "下载: $lib"
        mkdir -p "$(dirname "$lib")"
        if [[ "$lib" == external/* ]]; then
            repo_name="platform/${lib}"
            git clone --depth=1 "$MIRROR/${repo_name}.git" "$lib" 2>/dev/null && echo "  ✓ 完成" || echo "  ⚠ 跳过"
        fi
    else
        echo "已存在: $lib"
    fi
done
echo ""

# 7. 复制设备树
echo "7. 复制设备树..."
if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
    mkdir -p device/xiaomi
    cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
    echo "✓ 设备树复制完成: device/xiaomi/dagu"
    echo "  内核文件: $(ls -lh device/xiaomi/dagu/prebuilt/kernel 2>/dev/null || echo '检查中...')"
else
    echo "✗ 错误: 找不到设备树"
    exit 1
fi
echo ""

# 8. 链接 TWRP 源码
echo "8. 链接 TWRP 源码..."
if [ -d "/mnt/e/twrp/android_bootable_recovery" ]; then
    mkdir -p bootable
    if [ ! -L "bootable/recovery" ] && [ ! -d "bootable/recovery" ]; then
        ln -sf /mnt/e/twrp/android_bootable_recovery bootable/recovery
        echo "✓ 创建符号链接: bootable/recovery"
    else
        echo "✓ TWRP 源码已存在"
    fi
else
    echo "⚠ 警告: 找不到 TWRP 源码，尝试下载..."
    mkdir -p bootable
    git clone --depth=1 "https://github.com/TeamWin/android_bootable_recovery.git" bootable/recovery || \
    git clone --depth=1 "https://mirror.ghproxy.com/https://github.com/TeamWin/android_bootable_recovery.git" bootable/recovery || \
    echo "✗ 无法下载 TWRP 源码"
fi
echo ""

# 9. 创建构建环境
echo "9. 创建构建环境..."
mkdir -p out/target/product/dagu

# 创建 envsetup.sh
cat > build/envsetup.sh << 'EOF'
#!/bin/bash

# 最小化构建环境

export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export TARGET_BUILD_TYPE=release

# TWRP 特定变量
export RECOVERY_VARIANT=twrp
export TW_THEME=portrait_hdpi
export TW_DEVICE_VERSION=1.0

function lunch() {
    echo "========================================"
    echo "  TWRP 构建环境"
    echo "========================================"
    echo "设备: twrp_dagu-eng"
    echo "构建目录: $ANDROID_BUILD_TOP"
    echo "输出目录: $OUT_DIR"
    echo ""
    
    # 检查设备树
    if [ ! -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
        echo "错误: BoardConfig.mk 未找到"
        return 1
    fi
    
    # 检查内核
    if [ ! -f "device/xiaomi/dagu/prebuilt/kernel" ]; then
        echo "错误: 内核文件未找到"
        return 1
    fi
    
    # 检查 TWRP 源码
    if [ ! -d "bootable/recovery" ] && [ ! -L "bootable/recovery" ]; then
        echo "错误: TWRP 源码未找到"
        return 1
    fi
    
    echo "✓ 所有必要组件检查通过"
    echo ""
    echo "设备配置:"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -5
    return 0
}

function mka() {
    local jobs=$(nproc)
    echo "使用 $jobs 个并行任务构建: $@"
    make -j$jobs "$@"
}

function mmka() {
    mka "$@"
}

echo "最小化 Android 构建环境已设置"
echo "运行: lunch twrp_dagu-eng"
echo "运行: mka recoveryimage"
EOF

chmod +x build/envsetup.sh
echo "✓ 构建环境创建完成"
echo ""

# 10. 创建 Makefile
echo "10. 创建构建配置..."
cat > Makefile << 'EOF'
# 最小化构建配置

.PHONY: all recoveryimage bootimage systemimage clean distclean

all: recoveryimage

# 设备配置
include device/xiaomi/dagu/BoardConfig.mk

# 构建恢复镜像
recoveryimage: check_env
	@echo "开始构建 TWRP 恢复镜像..."
	@echo "设备: $(TARGET_PRODUCT)"
	@echo "构建变量: $(TARGET_BUILD_VARIANT)"
	@echo ""
	@echo "由于这是最小化构建环境，实际构建需要更多组件。"
	@echo ""
	@echo "已准备的组件:"
	@echo "  ✓ 设备树: device/xiaomi/dagu/"
	@echo "  ✓ TWRP 源码: bootable/recovery/"
	@echo "  ✓ 构建系统: build/make/"
	@echo "  ✓ 系统核心: system/core/"
	@echo "  ✓ 框架: frameworks/base/"
	@echo ""
	@echo "缺少的组件:"
	@echo "  ✗ 完整的 Android 源码树 (100+ 仓库)"
	@echo "  ✗ 供应商代码"
	@echo "  ✗ 其他系统组件"
	@echo ""
	@echo "建议下载完整源码:"
	@echo "  repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1"
	@echo "  repo sync -j$(nproc)"
	@echo ""
	@echo "创建模拟输出..."
	@mkdir -p $(OUT_DIR)/target/product/$(TARGET_PRODUCT)
	@echo "TWRP Recovery Image (模拟)" > $(OUT_DIR)/target/product/$(TARGET_PRODUCT)/recovery.img
	@echo "实际构建需要完整源码" >> $(OUT_DIR)/target/product/$(TARGET_PRODUCT)/recovery.img
	@echo "大小: 0 bytes" >> $(OUT_DIR)/target/product/$(TARGET_PRODUCT)/recovery.img
	@echo "✓ 创建模拟恢复镜像"
	@echo ""
	@echo "位置: $(OUT_DIR)/target/product/$(TARGET_PRODUCT)/recovery.img"

check_env:
	@echo "检查构建环境..."
	@if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then \
		echo "✓ BoardConfig.mk 存在"; \
	else \
		echo "✗ BoardConfig.mk 不存在"; exit 1; \
	fi
	@if [ -f "device/xiaomi/dagu/prebuilt/kernel" ]; then \
		echo "✓ 内核文件存在"; \
	else \
		echo "✗ 内核文件不存在"; exit 1; \
	fi
	@if [ -d "bootable/recovery" ] || [ -L "bootable/recovery" ]; then \
		echo "✓ TWRP 源码存在"; \
	else \
		echo "✗ TWRP 源码不存在"; exit 1; \
	fi
	@echo "✓ 环境检查完成"

clean:
	@echo "清理构建输出..."
	@rm -rf $(OUT_DIR)
	@echo "✓ 清理完成"

distclean: clean
	@echo "深度清理..."
	@echo "✓ 深度清理完成"

help:
	@echo "TWRP 最小化构建系统"
	@echo ""
	@echo "可用命令:"
	@echo "  make recoveryimage - 构建恢复镜像（模拟）"
	@echo "  make clean        - 清理输出"
	@echo "  make distclean    - 深度清理"
	@echo "  make help         - 显示帮助"
	@echo ""
	@echo "当前设备: xiaomi/dagu"
	@echo "TWRP 分支: twrp-12.1"
EOF

echo "✓ 构建配置创建完成"
echo ""

# 11. 创建构建脚本
echo "11. 创建构建脚本..."
cat > build_twrp_minimal.sh << 'EOF'
#!/bin/bash

# TWRP 最小化构建脚本

set -e

echo "========================================"
echo "  TWRP 最小化构建"
echo "========================================"
echo "注意: 这是最小化环境"
echo "实际构建需要完整的 Android 源码树"
echo ""

# 设置环境
source build/envsetup.sh

# 选择设备
if ! lunch twrp_dagu-eng; then
    echo "设备配置失败"
    exit 1
fi

echo ""
echo "开始构建..."
make recoveryimage

echo ""
echo "构建完成!"
echo ""
echo "总结:"
echo "  设备树: ✓ 配置完成"
echo "  TWRP 源码: ✓ 已链接"
echo "  构建系统: ✓ 最小化"
echo ""
echo "下一步:"
echo "  下载完整的 Android 源码树进行实际构建"
echo "  或使用预构建的 TWRP 镜像"
EOF

chmod +x build_twrp_minimal.sh
echo "✓ 构建脚本创建完成"
echo ""

echo "========================================"
echo "     最小化 Android 源码下载完成!"
echo "========================================"
echo ""
echo "目录: $SOURCE_DIR"
echo "大小: $(du -sh . 2>/dev/null | cut -f1 || echo '计算中...')"
echo ""
echo "已下载的组件:"
echo "  ✓ build/make - 构建系统"
echo "  ✓ build/soong - 构建系统"
echo "  ✓ system/core - 系统核心"
echo "  ✓ frameworks/base - 框架"
echo "  ✓ hardware/interfaces - 硬件接口"
echo "  ✓ external/* - 外部库"
echo "  ✓ device/xiaomi/dagu - 设备树"
echo "  ✓ bootable/recovery - TWRP 源码"
echo ""
echo "运行测试:"
echo "  cd $SOURCE_DIR"
echo "  source build/envsetup.sh"
echo "  lunch twrp_dagu-eng"
echo "  make recoveryimage"
echo ""
echo "或:"
echo "  cd $SOURCE_DIR && ./build_twrp_minimal.sh"
echo ""
echo "注意: 这是一个最小化环境，"
echo "实际构建需要下载完整的 Android 源码树。"