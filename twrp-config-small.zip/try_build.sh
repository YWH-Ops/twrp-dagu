#!/bin/bash

# 尝试构建 TWRP

cd ~/twrp-minimal || { echo "错误: 无法进入 ~/twrp-minimal 目录"; exit 1; }

echo "=== 尝试构建 TWRP ==="
echo "当前目录: $(pwd)"
echo ""

# 设置环境
echo "1. 设置构建环境..."
source build/envsetup.sh 2>&1 || { echo "错误: 设置环境失败"; exit 1; }
echo "✓ 环境设置完成"
echo ""

# 检查必要的工具
echo "2. 检查构建工具..."
for tool in make gcc g++ clang; do
    if command -v $tool >/dev/null 2>&1; then
        echo "  ✓ $tool: $(which $tool)"
    else
        echo "  ✗ $tool: 未安装"
    fi
done
echo ""

# 尝试简单的构建测试
echo "3. 尝试构建测试..."
echo "创建测试 Makefile..."

# 创建一个简单的测试 Makefile
cat > test.mk << 'EOF'
# 测试 Makefile
.PHONY: all clean

all: test_build

test_build:
	@echo "=== TWRP 构建测试 ==="
	@echo "构建目录: $(ANDROID_BUILD_TOP)"
	@echo "输出目录: $(OUT_DIR)"
	@echo "目标产品: $(TARGET_PRODUCT)"
	@echo ""
	@echo "检查设备树..."
	@if [ -d "device/xiaomi/dagu" ]; then \
		echo "✓ 设备树存在: device/xiaomi/dagu"; \
		if [ -f "device/xiaomi/dagu/prebuilt/kernel" ]; then \
			echo "✓ 内核文件存在: $(ls -lh device/xiaomi/dagu/prebuilt/kernel)"; \
		else \
			echo "✗ 错误: 内核文件不存在"; \
		fi; \
	else \
		echo "✗ 错误: 设备树不存在"; \
	fi
	@echo ""
	@echo "检查 TWRP 源码..."
	@if [ -L "bootable/recovery" ] || [ -d "bootable/recovery" ]; then \
		echo "✓ TWRP 源码存在"; \
		if [ -L "bootable/recovery" ]; then \
			echo "  类型: 符号链接 -> $(readlink bootable/recovery)"; \
		fi; \
	else \
		echo "✗ 错误: TWRP 源码不存在"; \
	fi
	@echo ""
	@echo "测试完成!"
	@echo ""
	@echo "下一步操作:"
	@echo "  1. 需要完整的 Android 源码树进行实际构建"
	@echo "  2. 运行完整的 repo sync 下载所有组件"
	@echo "  3. 或使用预构建的 TWRP（如果有）"

clean:
	@echo "清理测试文件..."
	@rm -f test.mk
EOF

echo "运行测试..."
make -f test.mk
echo ""

# 清理
make -f test.mk clean
echo ""

echo "4. 检查是否可以开始实际构建..."
echo "当前设置:"
echo "  ANDROID_BUILD_TOP: $ANDROID_BUILD_TOP"
echo "  OUT_DIR: $OUT_DIR"
echo "  TARGET_PRODUCT: $TARGET_PRODUCT"
echo ""

echo "5. 尝试运行实际构建命令..."
echo "注意: 由于缺少完整的 Android 源码树，实际构建可能会失败"
echo ""

# 尝试运行 envsetup.sh 中的 lunch 函数
echo "尝试选择设备..."
if type lunch 2>/dev/null | head -1 | grep -q "function"; then
    lunch twrp_dagu-eng
else
    echo "lunch 函数未定义，手动设置..."
    export TARGET_PRODUCT=twrp_dagu
    export TARGET_BUILD_VARIANT=eng
    export RECOVERY_VARIANT=twrp
    echo "设置完成: TARGET_PRODUCT=twrp_dagu"
fi
echo ""

echo "=== 构建准备状态 ==="
echo "状态: 准备就绪（但需要完整源码）"
echo ""
echo "已完成的步骤:"
echo "  ✓ 下载了核心组件（build, system, hardware, frameworks）"
echo "  ✓ 设备树已配置"
echo "  ✓ TWRP 源码已链接"
echo "  ✓ 构建环境已设置"
echo ""
echo "缺少的组件:"
echo "  ✗ 完整的 Android 源码树（约 200 多个仓库）"
echo "  ✗ 供应商代码（vendor）"
echo "  ✗ 其他依赖库"
echo ""
echo "建议:"
echo "  1. 运行完整下载: ./download_twrp_fast.sh（需要约 20GB 空间）"
echo "  2. 或使用预编译的 TWRP（如果有）"
echo "  3. 或从其他来源获取完整的 TWRP 源码树"
echo ""
echo "最小化构建测试完成!"