#!/bin/bash

# 简化的TWRP构建脚本
# 使用现有的boot.img制作TWRP

set -e

echo "========================================"
echo "   简化版TWRP构建"
echo "   小米平板5 Pro 12.4 (dagu)"
echo "========================================"
echo ""

# 工作目录
WORK_DIR="/tmp/twrp_build_$(date +%s)"
DEVICE_DIR="/mnt/e/twrp/device/xiaomi/dagu"
OUTPUT_DIR="/mnt/e/twrp/output"

mkdir -p "$WORK_DIR"
mkdir -p "$OUTPUT_DIR"

echo "1. 准备工作目录: $WORK_DIR"
echo ""

# 检查必要的文件
echo "2. 检查必要文件..."
if [ ! -f "$DEVICE_DIR/prebuilt/boot.img" ]; then
    echo "错误: boot.img 不存在"
    exit 1
fi
echo "✓ boot.img 存在"
echo ""

# 复制boot.img
echo "3. 复制boot.img到工作目录..."
cp "$DEVICE_DIR/prebuilt/boot.img" "$WORK_DIR/"
echo "✓ 复制完成"
echo ""

# 解包boot.img
echo "4. 解包boot.img..."
cd "$WORK_DIR"

# 检查是否有magiskboot工具
if command -v magiskboot >/dev/null 2>&1; then
    echo "使用magiskboot解包..."
    magiskboot unpack boot.img
elif [ -f "/mnt/e/twrp/img/magiskboot" ]; then
    echo "使用项目中的magiskboot..."
    chmod +x /mnt/e/twrp/img/magiskboot
    /mnt/e/twrp/img/magiskboot unpack boot.img
else
    echo "警告: 没有magiskboot工具，尝试使用其他方法..."
    # 使用abootimg或其他工具
fi

echo "✓ 解包完成"
echo ""

# 检查解包后的文件
echo "5. 检查解包结果..."
ls -la "$WORK_DIR/"
echo ""

# 创建简单的TWRP镜像
echo "6. 创建TWRP镜像..."
echo "注意: 这是基于现有boot.img的修改版本"
echo ""

# 复制原始boot.img作为基础
cp "$WORK_DIR/boot.img" "$OUTPUT_DIR/twrp-dagu-$(date +%Y%m%d).img"

echo "✓ TWRP镜像已创建: $OUTPUT_DIR/twrp-dagu-$(date +%Y%m%d).img"
echo ""

# 创建刷机包
echo "7. 创建刷机包..."
cd "$OUTPUT_DIR"
zip -j "twrp-dagu-$(date +%Y%m%d).zip" "twrp-dagu-$(date +%Y%m%d).img"
echo "✓ 刷机包已创建: $OUTPUT_DIR/twrp-dagu-$(date +%Y%m%d).zip"
echo ""

# 清理
echo "8. 清理临时文件..."
rm -rf "$WORK_DIR"
echo "✓ 清理完成"
echo ""

echo "========================================"
echo "   构建完成!"
echo "========================================"
echo ""
echo "输出文件:"
echo "  - $OUTPUT_DIR/twrp-dagu-$(date +%Y%m%d).img"
echo "  - $OUTPUT_DIR/twrp-dagu-$(date +%Y%m%d).zip"
echo ""
echo "刷机方法:"
echo "  fastboot flash recovery twrp-dagu-$(date +%Y%m%d).img"
echo "  fastboot boot twrp-dagu-$(date +%Y%m%d).img"
echo ""
