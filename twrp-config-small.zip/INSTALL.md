# TWRP 安装指南 - 小米平板5 Pro 12.4 (dagu)

## 📋 概述

本指南详细说明如何为小米平板5 Pro 12.4 (dagu) 构建和安装 TWRP 恢复系统。

## 🛠️ 构建 TWRP

### 方法一：使用构建脚本（推荐）

#### Windows 用户
1. **运行构建脚本**：
   ```powershell
   # 以管理员身份运行 PowerShell
   cd e:\twrp
   .\build_windows.ps1
   ```

2. **在菜单中选择操作**：
   - 选项 1: 检查环境和设备树
   - 选项 2: 在 WSL2 中构建 TWRP
   - 选项 3: 创建刷机包
   - 选项 4: 清理输出目录

#### Linux/macOS 用户
1. **设置执行权限**：
   ```bash
   chmod +x quick_start.sh
   ```

2. **运行构建脚本**：
   ```bash
   # 完整构建流程
   ./quick_start.sh all

   # 或分步执行
   ./quick_start.sh check      # 检查环境
   ./quick_start.sh download   # 下载源码
   ./quick_start.sh prepare    # 准备设备树
   ./quick_start.sh build      # 构建 recovery
   ./quick_start.sh package    # 创建刷机包
   ```

### 方法二：手动构建

#### 1. 环境准备
```bash
# Ubuntu/Debian
sudo apt update && sudo apt upgrade -y
sudo apt install -y git-core gnupg flex bison build-essential zip curl zlib1g-dev gcc-multilib g++-multilib libc6-dev-i386 lib32ncurses5-dev x11proto-core-dev libx11-dev lib32z1-dev libgl1-mesa-dev libxml2-utils xsltproc unzip fontconfig python3 openjdk-11-jdk

# 安装 repo 工具
mkdir ~/bin
curl https://storage.googleapis.com/git-repo-downloads/repo > ~/bin/repo
chmod a+x ~/bin/repo
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

#### 2. 下载 TWRP 源码
```bash
mkdir ~/twrp-build && cd ~/twrp-build
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1
repo sync -j$(nproc) --no-clone-bundle --no-tags
```

#### 3. 复制设备树
```bash
# 复制本项目的设备树
cp -r /path/to/your/twrp/device/xiaomi/dagu ~/twrp-build/device/xiaomi/
```

#### 4. 构建 recovery
```bash
cd ~/twrp-build
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

#### 5. 获取构建结果
构建完成后，恢复镜像位于：
```
~/twrp-build/out/target/product/dagu/recovery.img
```

## 📱 刷入 TWRP

### 准备工作
1. **解锁 bootloader**（如果未解锁）
2. **启用 USB 调试**：
   - 设置 > 关于平板电脑 > 连续点击"版本号"7次
   - 返回设置 > 开发者选项 > 启用"USB调试"
3. **安装 ADB 和 Fastboot**：
   - 下载 [Platform Tools](https://developer.android.com/studio/releases/platform-tools)
   - 解压并添加到系统 PATH

### 方法一：Fastboot 刷入（推荐）
```bash
# 1. 进入 fastboot 模式
adb reboot bootloader

# 2. 检查设备连接
fastboot devices

# 3. 刷入 recovery
fastboot flash recovery recovery.img

# 4. 重启到 recovery
fastboot reboot recovery
```

### 方法二：临时启动（测试用）
```bash
# 临时启动 recovery，不刷入设备
fastboot boot recovery.img
```

### 方法三：通过现有恢复刷入
1. 将 `recovery.img` 重命名为 `twrp.img`
2. 将文件复制到设备存储
3. 在现有恢复中选择 "Install"
4. 选择 "Install Image"
5. 选择 `twrp.img` 并刷入到 Recovery 分区

### 方法四：使用刷机包
1. 将刷机包 `twrp-*.zip` 复制到设备存储
2. 启动到现有的恢复模式
3. 选择 "Install" → 选择刷机包
4. 滑动确认刷入
5. 重启到恢复模式

## 🔧 验证安装

### 检查 TWRP 功能
1. **启动测试**：
   - 完全关机
   - 按住 **音量+** 和 **电源键** 进入恢复模式
   - 应该看到 TWRP 界面

2. **触摸测试**：
   - 确认触摸屏正常工作
   - 滑动解锁（如果需要）
   - 点击各个菜单项

3. **挂载测试**：
   - 进入 "Mount" 菜单
   - 勾选 system, vendor, data, cache 等分区
   - 确认可以正常挂载

4. **备份测试**：
   - 进入 "Backup" 菜单
   - 选择要备份的分区
   - 创建备份并验证

5. **文件管理测试**：
   - 进入 "Advanced" → "File Manager"
   - 浏览文件系统
   - 确认可以读写存储

### 常见问题解决

#### 问题 1：无法进入 fastboot 模式
**解决方法**：
```bash
# 尝试不同的按键组合
adb reboot bootloader

# 或手动进入
# 关机后按住 音量- + 电源键
```

#### 问题 2：设备未识别
**解决方法**：
1. 检查 USB 连接
2. 重新安装驱动程序
3. 尝试不同的 USB 端口
4. 检查 USB 调试是否启用

#### 问题 3：刷入失败
**解决方法**：
```bash
# 解锁 bootloader
fastboot flashing unlock

# 或
fastboot oem unlock
```

#### 问题 4：触摸屏不工作
**解决方法**：
1. 使用鼠标或键盘操作
2. 检查触控驱动配置
3. 尝试不同版本的 TWRP

## 📊 设备分区信息

### 关键分区
```
/boot          - 引导分区
/recovery     - 恢复分区
/system       - 系统分区
/vendor       - 供应商分区
/data         - 数据分区
/cache        - 缓存分区
/persist      - 持久数据分区
/metadata     - 元数据分区
```

### 分区大小
- **引导分区**: 96MB
- **恢复分区**: 64MB
- **系统分区**: 3.5GB
- **数据分区**: 107GB (F2FS)

## 🔄 恢复官方恢复

如果需要恢复官方恢复系统：

### 方法一：通过 Fastboot
```bash
# 1. 下载官方恢复镜像
# 2. 进入 fastboot 模式
adb reboot bootloader

# 3. 刷入官方恢复
fastboot flash recovery stock_recovery.img

# 4. 重启
fastboot reboot
```

### 方法二：通过 TWRP
1. 将官方恢复镜像复制到设备存储
2. 在 TWRP 中选择 "Install"
3. 选择 "Install Image"
4. 选择官方恢复镜像并刷入到 Recovery 分区

## ⚠️ 注意事项

### 重要警告
1. **备份数据**：刷机前务必备份重要数据
2. **解锁风险**：解锁 bootloader 会清除设备数据
3. **保修失效**：解锁 bootloader 可能导致保修失效
4. **变砖风险**：错误的操作可能导致设备无法启动

### 推荐操作
1. **首次刷机**：先使用 `fastboot boot` 测试
2. **备份原系统**：在 TWRP 中备份原系统
3. **保存备份**：将备份复制到电脑安全位置
4. **测试功能**：确保所有功能正常工作后再进行其他操作

### 技术支持
- **XDA 论坛**: [Xiaomi Mi Pad 5](https://forum.xda-developers.com/c/xiaomi-mi-pad-5.12371/)
- **Telegram 群组**: 搜索 "dagu TWRP"
- **GitHub Issues**: [TWRP Issues](https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp/issues)

## 📁 文件说明

### 构建输出文件
```
output/
├── recovery.img                 # TWRP 恢复镜像
├── twrp-3.7.0-*.zip            # 刷机包
├── build.log                   # 构建日志
└── verification_report.txt     # 验证报告
```

### 设备树文件
```
device/xiaomi/dagu/
├── AndroidProducts.mk          # 产品定义
├── BoardConfig.mk              # 硬件配置
├── device.mk                   # 设备属性
├── recovery.fstab              # 分区映射
├── twrp_dagu.mk               # TWRP 配置
├── vendorsetup.sh             # 构建集成
├── prebuilt/
│   ├── boot.img               # 引导镜像
│   └── kernel                 # 内核文件
└── README.md                  # 文档
```

## 🔧 高级功能

### 自定义 TWRP
1. **修改主题**：编辑 `BoardConfig.mk` 中的 `TW_THEME`
2. **添加功能**：在 `device.mk` 中添加 `PRODUCT_PACKAGES`
3. **调整配置**：修改 `recovery.fstab` 中的分区设置

### 调试模式
```bash
# 启用详细日志
adb shell setprop persist.sys.twrp.debug 1

# 查看日志
adb logcat -s recovery
```

### 提取分区
```bash
# 在 TWRP 中提取分区
adb shell "dd if=/dev/block/bootdevice/by-name/boot of=/sdcard/boot.img"
adb pull /sdcard/boot.img
```

## 📝 更新日志

### v1.0 (2026-03-31)
- 初始版本发布
- 完整的构建脚本
- 详细的安装指南
- 验证和测试工具

### 已知问题
- [ ] 触控屏可能需要校准
- [ ] 某些分区可能无法挂载
- [ ] 加密分区可能需要额外配置

## 🤝 贡献

### 报告问题
1. 在 GitHub 创建 Issue
2. 提供设备信息（型号、Android 版本）
3. 提供错误日志和截图
4. 描述复现步骤

### 提交更改
1. Fork 项目
2. 创建功能分支
3. 提交更改
4. 创建 Pull Request

## 📄 许可证

本项目基于 Apache License 2.0 许可证分发。

## 🙏 致谢

- Team Win Recovery Project (TWRP)
- Xiaomi for device firmware
- The Android Open Source Project
- All contributors and testers

---
**维护者**: [Your Name Here]  
**设备**: 小米平板5 Pro 12.4 (dagu)  
**状态**: 初始版本  
**最后更新**: 2026-03-31  

**提示**: 刷机有风险，操作需谨慎。请确保理解所有步骤后再进行操作。