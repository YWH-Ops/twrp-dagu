# 内核修复总结与后续步骤

## ✅ 已完成的工作

### 1. 问题诊断
- **发现问题**: `prebuilt/kernel` 文件是完整的 boot.img (128MB)，而不是纯内核
- **根本原因**: 文件命名错误，实际包含完整引导镜像
- **解决方案**: 使用备份的 boot.img (192MB) 替换

### 2. 修复步骤
1. **备份原文件**: 将 `prebuilt/kernel` 备份为 `prebuilt/kernel.backup`
2. **替换文件**: 使用 `Backups/Partitions_20260330_191944/boot.img` 替换 `prebuilt/kernel`
3. **验证文件**: 确认新文件是正确的 Android bootimg 格式

### 3. 验证结果
- **文件类型**: `Android bootimg, kernel (0x1fa0458), ramdisk (0x62c)`
- **文件大小**: 192MB (正确的大小)
- **TWRP 标记**: 包含 `twrpfastboot=1` 标记
- **内核版本**: `Linux version 4.19.157-perf-g5285edb4d726`

## 📁 当前文件状态

### prebuilt/ 目录
```
prebuilt/
├── boot.img           # 128MB, 原始预编译引导镜像
├── kernel             # 192MB, 从备份复制的正确引导镜像 ✅
└── kernel.backup      # 128MB, 原错误文件的备份
```

### 关键文件对比
| 文件 | 大小 | 类型 | 状态 | 用途 |
|------|------|------|------|------|
| `kernel.backup` | 128MB | boot.img | 备份 | 原错误文件 |
| `kernel` | 192MB | boot.img | 使用中 | 正确的引导镜像 |
| `boot.img` | 128MB | boot.img | 未使用 | 原始预编译镜像 |

## 🔧 设备树配置

### BoardConfig.mk 配置
当前配置正确，不需要修改：
```makefile
# 内核配置 - 从dagu的boot.img中提取
BOARD_KERNEL_CMDLINE := console=ttyMSM0,115200n8 earlycon=msm_geni_serial,0xa90000 androidboot.hardware=qcom androidboot.console=ttyMSM0 androidboot.memcg=1 lpm_levels.sleep_disabled=1 video=vfb:640x400,bpp=32,memsize=3072000 msm_rtb.filter=0x237 service_locator.enable=1 swiotlb=2048 loop.max_part=7 androidboot.usbcontroller=a600000.dwc3 kpti=off
BOARD_KERNEL_BASE := 0x00000000
BOARD_KERNEL_PAGESIZE := 4096
BOARD_KERNEL_TAGS_OFFSET := 0x00000100
BOARD_RAMDISK_OFFSET := 0x01000000
BOARD_DTB_OFFSET := 0x01f00000
BOARD_KERNEL_IMAGE_NAME := Image.gz-dtb
TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/kernel  # ✅ 指向正确的文件
```

## 🚀 开始构建 TWRP

### 方法 1: 使用构建脚本
```bash
# 在 TWRP 源码根目录运行
cd /path/to/twrp/source

# 方法 A: 使用 bash 脚本 (Linux/WSL)
bash /mnt/e/twrp/build_twrp.sh

# 方法 B: 使用批处理脚本 (Windows)
e:\twrp\build_twrp.bat
```

### 方法 2: 手动构建
```bash
# 1. 初始化环境
source build/envsetup.sh

# 2. 选择设备
lunch twrp_dagu-eng

# 3. 开始构建
mka recoveryimage

# 4. 检查输出
ls -lh out/target/product/dagu/recovery.img
```

## ⚠️ 构建前检查清单

### 必需条件
- [x] 内核文件已修复 (`prebuilt/kernel` = 192MB boot.img)
- [x] 设备树配置正确
- [x] TWRP 源码完整
- [ ] 足够的磁盘空间 (>100GB)
- [ ] 足够的内存 (>16GB)
- [ ] 稳定的网络连接

### 验证命令
```bash
# 验证内核文件
file device/xiaomi/dagu/prebuilt/kernel

# 验证设备树
ls -la device/xiaomi/dagu/

# 检查构建环境
which make
which gcc
java -version
```

## 🔍 常见问题排查

### 问题 1: 构建失败 - 内核错误
**症状**: `error: invalid kernel image`
**解决**: 确保使用正确的 boot.img 文件
```bash
# 检查当前内核文件
ls -lh device/xiaomi/dagu/prebuilt/kernel
file device/xiaomi/dagu/prebuilt/kernel

# 如果不正确，重新复制
cp Backups/Partitions_20260330_191944/boot.img device/xiaomi/dagu/prebuilt/kernel
```

### 问题 2: 分区大小错误
**症状**: `image too large for partition`
**解决**: 检查分区大小配置
```bash
# 查看当前分区大小
grep "BOARD_RECOVERYIMAGE_PARTITION_SIZE" device/xiaomi/dagu/BoardConfig.mk

# 如果需要调整
# 修改为: BOARD_RECOVERYIMAGE_PARTITION_SIZE := 100663296
```

### 问题 3: 缺少依赖
**症状**: 各种编译错误
**解决**: 安装必需工具
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y git-core gnupg flex bison build-essential zip curl zlib1g-dev gcc-multilib g++-multilib libc6-dev-i386 libncurses5 lib32ncurses5-dev x11proto-core-dev libx11-dev lib32z1-dev libgl1-mesa-dev libxml2-utils xsltproc unzip fontconfig

# 其他系统请参考 TWRP 官方文档
```

## 📊 内核信息详情

### 备份 boot.img 详细信息
- **文件**: `Backups/Partitions_20260330_191944/boot.img`
- **大小**: 192MB (201,326,592 字节)
- **类型**: Android bootimg
- **内核地址**: 0x1fa0458
- **ramdisk 偏移**: 0x62c
- **TWRP 标记**: `twrpfastboot=1`
- **内核版本**: `Linux version 4.19.157-perf-g5285edb4d726`
- **构建时间**: `Tue Dec 20 22:14:35 CST 2022`

### 原 kernel 文件问题
- **错误**: 128MB 的完整 boot.img
- **原因**: 文件命名错误，应为纯内核但实际是完整引导镜像
- **影响**: TWRP 构建会失败或生成错误的恢复镜像

## 🛠️ 附加工具脚本

### 1. 验证脚本
```bash
#!/bin/bash
# verify_kernel.sh
echo "=== 内核验证 ==="
file device/xiaomi/dagu/prebuilt/kernel
echo "=== 内核版本 ==="
strings device/xiaomi/dagu/prebuilt/kernel | grep -i "linux version" | head -3
echo "=== TWRP 标记 ==="
hexdump -C device/xiaomi/dagu/prebuilt/kernel | grep -i "twrp" | head -5
```

### 2. 还原脚本
```bash
#!/bin/bash
# restore_kernel.sh
echo "恢复原始 kernel 文件..."
cp device/xiaomi/dagu/prebuilt/kernel.backup device/xiaomi/dagu/prebuilt/kernel
echo "当前 kernel 文件:"
ls -lh device/xiaomi/dagu/prebuilt/kernel
file device/xiaomi/dagu/prebuilt/kernel
```

### 3. 更新脚本
```bash
#!/bin/bash
# update_kernel.sh
echo "更新 kernel 文件..."
cp Backups/Partitions_20260330_191944/boot.img device/xiaomi/dagu/prebuilt/kernel
echo "更新完成:"
ls -lh device/xiaomi/dagu/prebuilt/kernel
file device/xiaomi/dagu/prebuilt/kernel
```

## 🎯 下一步建议

### 立即操作
1. **验证内核**: 运行验证脚本确保内核正确
2. **开始构建**: 运行构建脚本或手动构建
3. **测试恢复**: 在设备上测试生成的 recovery.img

### 长期改进
1. **文档更新**: 更新设备树文档说明内核文件要求
2. **构建自动化**: 创建完整的 CI/CD 流程
3. **测试套件**: 添加自动化测试验证内核兼容性
4. **错误处理**: 添加构建前验证步骤

## 📞 技术支持

### 如果遇到问题
1. **检查日志**: 查看构建输出中的错误信息
2. **验证文件**: 确保所有文件正确无误
3. **查阅文档**: 参考 TWRP 官方构建指南
4. **社区支持**: 在 XDA Developers 论坛寻求帮助

### 有用的命令
```bash
# 清理构建
make clean

# 仅构建恢复镜像
mka recoveryimage

# 查看构建变量
get_build_var TARGET_PREBUILT_KERNEL

# 调试模式构建
mka recoveryimage -j$(nproc) showcommands
```

## ✅ 最终检查
在开始构建前，运行以下命令确认一切正常：

```bash
# 1. 确认内核文件
ls -lh device/xiaomi/dagu/prebuilt/kernel
file device/xiaomi/dagu/prebuilt/kernel

# 2. 确认设备树
grep -n "TARGET_PREBUILT_KERNEL" device/xiaomi/dagu/BoardConfig.mk

# 3. 确认环境
which make
which gcc
java -version

# 4. 开始构建
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

**现在您可以开始构建 TWRP 了！** 🎉