#!/bin/bash

# TWRP 云构建测试脚本
# 用于在本地模拟 GitHub Actions 构建环境

set -e

echo "========================================"
echo "  TWRP 云构建本地测试"
echo "========================================"
echo "时间: $(date)"
echo "设备: 小米平板5 Pro 12.4 (dagu)"
echo "========================================"
echo ""

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查必要的工具
check_tools() {
    print_status "检查必要的工具..."
    
    local tools=("git" "curl" "make" "gcc" "g++" "python3" "java" "ccache")
    local missing=()
    
    for tool in "${tools[@]}"; do
        if ! command -v $tool >/dev/null 2>&1; then
            missing+=("$tool")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        print_error "缺少以下工具: ${missing[*]}"
        echo "请安装: sudo apt-get install ${missing[*]}"
        return 1
    fi
    
    print_success "所有必要工具已安装"
    return 0
}

# 检查设备树
check_device_tree() {
    print_status "检查设备树..."
    
    local required_files=(
        "device/xiaomi/dagu/BoardConfig.mk"
        "device/xiaomi/dagu/twrp_dagu.mk"
        "device/xiaomi/dagu/recovery.fstab"
        "device/xiaomi/dagu/prebuilt/kernel"
    )
    
    local missing=()
    
    for file in "${required_files[@]}"; do
        if [ ! -f "$file" ]; then
            missing+=("$file")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        print_error "缺少以下设备树文件:"
        for file in "${missing[@]}"; do
            echo "  - $file"
        done
        return 1
    fi
    
    # 检查内核文件大小
    local kernel_file="device/xiaomi/dagu/prebuilt/kernel"
    local kernel_size=$(ls -lh "$kernel_file" 2>/dev/null | awk '{print $5}' || echo "0")
    
    if [[ "$kernel_size" == "192M" ]]; then
        print_success "内核文件大小正确: $kernel_size"
    else
        print_warning "内核文件大小异常: $kernel_size (应为192M)"
    fi
    
    print_success "设备树检查通过"
    return 0
}

# 检查 TWRP 源码
check_twrp_source() {
    print_status "检查 TWRP 源码..."
    
    if [ ! -d "android_bootable_recovery" ]; then
        print_error "TWRP 源码目录不存在: android_bootable_recovery"
        return 1
    fi
    
    local required_dirs=(
        "android_bootable_recovery/gui"
        "android_bootable_recovery/install"
        "android_bootable_recovery/recovery_ui"
        "android_bootable_recovery/minui"
    )
    
    for dir in "${required_dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            print_warning "缺少目录: $dir"
        fi
    done
    
    local build_files=(
        "android_bootable_recovery/Android.mk"
        "android_bootable_recovery/Android.bp"
    )
    
    for file in "${build_files[@]}"; do
        if [ ! -f "$file" ]; then
            print_warning "缺少构建文件: $file"
        fi
    done
    
    local twrp_size=$(du -sh android_bootable_recovery 2>/dev/null | cut -f1 || echo "未知")
    print_success "TWRP 源码存在，大小: $twrp_size"
    return 0
}

# 模拟 GitHub Actions 环境
setup_github_env() {
    print_status "设置 GitHub Actions 模拟环境..."
    
    # 创建临时目录
    local temp_dir="/tmp/twrp-cloud-test-$(date +%s)"
    mkdir -p "$temp_dir"
    cd "$temp_dir"
    
    print_status "临时目录: $temp_dir"
    
    # 复制必要的文件
    cp -r "$OLDPWD/device" .
    cp -r "$OLDPWD/android_bootable_recovery" .
    
    # 创建构建目录结构
    mkdir -p build system hardware external
    
    print_success "环境设置完成"
    echo "工作目录: $temp_dir"
    
    # 返回原目录但保留临时目录信息
    cd "$OLDPWD"
    echo "TEMP_DIR=$temp_dir" > /tmp/twrp_test_env.txt
}

# 测试构建配置
test_build_config() {
    print_status "测试构建配置..."
    
    local temp_dir
    if [ -f "/tmp/twrp_test_env.txt" ]; then
        source /tmp/twrp_test_env.txt
    else
        print_error "未找到临时目录"
        return 1
    fi
    
    cd "$TEMP_DIR"
    
    # 创建简单的构建测试
    cat > test_build_config.sh << 'EOF'
#!/bin/bash

echo "=== 构建配置测试 ==="
echo "工作目录: $(pwd)"
echo ""

# 检查目录结构
echo "目录结构:"
find . -maxdepth 2 -type d | sort
echo ""

# 检查设备树
echo "设备树文件:"
find device -type f -name "*.mk" -o -name "*.sh" | sort
echo ""

# 检查 TWRP 源码
echo "TWRP 源码文件 (前10个):"
find android_bootable_recovery -type f -name "*.cpp" -o -name "*.h" | head -10
echo ""

# 测试编译环境
echo "编译环境测试:"
echo "GCC 版本: $(gcc --version | head -1)"
echo "Make 版本: $(make --version | head -1)"
echo "Python 版本: $(python3 --version)"
echo "Java 版本: $(java -version 2>&1 | head -1)"
echo ""

# 创建测试编译
echo "创建测试编译..."
cat > test_hello.c << 'TESTCODE'
#include <stdio.h>

int main() {
    printf("Hello from TWRP Cloud Build Test!\n");
    printf("Device: dagu (Xiaomi Pad 5 Pro 12.4)\n");
    printf("Test successful!\n");
    return 0;
}
TESTCODE

# 编译测试
if gcc -o test_hello test_hello.c; then
    echo "✅ 编译测试通过"
    ./test_hello
else
    echo "❌ 编译测试失败"
fi
echo ""

# 清理
rm -f test_hello test_hello.c
EOF
    
    chmod +x test_build_config.sh
    ./test_build_config.sh
    
    cd "$OLDPWD"
}

# 测试交叉编译
test_cross_compile() {
    print_status "测试交叉编译环境..."
    
    # 检查是否安装了交叉编译器
    local cross_compilers=("aarch64-linux-gnu-gcc" "arm-linux-gnueabi-gcc")
    local missing_compilers=()
    
    for compiler in "${cross_compilers[@]}"; do
        if ! command -v $compiler >/dev/null 2>&1; then
            missing_compilers+=("$compiler")
        fi
    done
    
    if [ ${#missing_compilers[@]} -gt 0 ]; then
        print_warning "缺少交叉编译器: ${missing_compilers[*]}"
        echo "安装命令: sudo apt-get install gcc-aarch64-linux-gnu gcc-arm-linux-gnueabi"
        return 1
    fi
    
    # 测试 ARM64 编译
    print_status "测试 ARM64 编译..."
    cat > test_arm64.c << 'EOF'
#include <stdio.h>

int main() {
    printf("ARM64 Cross Compilation Test\n");
    printf("Platform: aarch64-linux-gnu\n");
    return 0;
}
EOF
    
    if aarch64-linux-gnu-gcc -static -o test_arm64 test_arm64.c; then
        print_success "ARM64 交叉编译成功"
        file test_arm64
    else
        print_error "ARM64 交叉编译失败"
    fi
    
    # 测试 ARM 编译
    print_status "测试 ARM 编译..."
    cat > test_arm.c << 'EOF'
#include <stdio.h>

int main() {
    printf("ARM Cross Compilation Test\n");
    printf("Platform: arm-linux-gnueabi\n");
    return 0;
}
EOF
    
    if arm-linux-gnueabi-gcc -static -o test_arm test_arm.c; then
        print_success "ARM 交叉编译成功"
        file test_arm
    else
        print_error "ARM 交叉编译失败"
    fi
    
    # 清理
    rm -f test_arm64 test_arm64.c test_arm test_arm.c
    
    print_success "交叉编译测试完成"
}

# 生成测试报告
generate_test_report() {
    print_status "生成测试报告..."
    
    local report_file="cloud-build-test-report-$(date +%Y%m%d-%H%M%S).md"
    
    cat > "$report_file" << EOF
# TWRP 云构建测试报告

## 测试信息
- **测试时间**: $(date)
- **设备**: 小米平板5 Pro 12.4 (dagu)
- **测试环境**: $(uname -a)

## 测试结果

### 1. 工具检查
EOF
    
    # 工具检查结果
    local tools=("git" "curl" "make" "gcc" "g++" "python3" "java" "ccache")
    for tool in "${tools[@]}"; do
        if command -v $tool >/dev/null 2>&1; then
            echo "- ✅ $tool: $(which $tool)" >> "$report_file"
        else
            echo "- ❌ $tool: 未安装" >> "$report_file"
        fi
    done
    
    cat >> "$report_file" << EOF

### 2. 设备树检查
EOF
    
    # 设备树检查结果
    local device_files=(
        "device/xiaomi/dagu/BoardConfig.mk"
        "device/xiaomi/dagu/twrp_dagu.mk"
        "device/xiaomi/dagu/recovery.fstab"
        "device/xiaomi/dagu/prebuilt/kernel"
    )
    
    for file in "${device_files[@]}"; do
        if [ -f "$file" ]; then
            local size=$(ls -lh "$file" 2>/dev/null | awk '{print $5}' || echo "未知")
            echo "- ✅ $file ($size)" >> "$report_file"
        else
            echo "- ❌ $file: 缺失" >> "$report_file"
        fi
    done
    
    cat >> "$report_file" << EOF

### 3. TWRP 源码检查
EOF
    
    # TWRP 源码检查结果
    if [ -d "android_bootable_recovery" ]; then
        local twrp_size=$(du -sh android_bootable_recovery 2>/dev/null | cut -f1 || echo "未知")
        echo "- ✅ TWRP 源码目录存在 ($twrp_size)" >> "$report_file"
        
        local twrp_dirs=("gui" "install" "recovery_ui" "minui")
        for dir in "${twrp_dirs[@]}"; do
            if [ -d "android_bootable_recovery/$dir" ]; then
                echo "  - ✅ $dir 目录存在" >> "$report_file"
            else
                echo "  - ⚠️ $dir 目录缺失" >> "$report_file"
            fi
        done
    else
        echo "- ❌ TWRP 源码目录缺失" >> "$report_file"
    fi
    
    cat >> "$report_file" << EOF

### 4. 交叉编译测试
EOF
    
    # 交叉编译测试结果
    if command -v aarch64-linux-gnu-gcc >/dev/null 2>&1; then
        echo "- ✅ ARM64 交叉编译器已安装" >> "$report_file"
    else
        echo "- ❌ ARM64 交叉编译器未安装" >> "$report_file"
    fi
    
    if command -v arm-linux-gnueabi-gcc >/dev/null 2>&1; then
        echo "- ✅ ARM 交叉编译器已安装" >> "$report_file"
    else
        echo "- ❌ ARM 交叉编译器未安装" >> "$report_file"
    fi
    
    cat >> "$report_file" << EOF

## 云构建准备情况评估

### 通过条件 (必须全部满足)
1. ✅ 所有必要工具已安装
2. ✅ 设备树文件完整
3. ✅ TWRP 源码存在
4. ⚠️  交叉编译器 (建议安装)

### 建议
EOF
    
    # 根据检查结果给出建议
    if command -v aarch64-linux-gnu-gcc >/dev/null 2>&1 && \
       command -v arm-linux-gnueabi-gcc >/dev/null 2>&1; then
        echo "1. **环境准备就绪**: 可以开始云构建" >> "$report_file"
        echo "2. **建议操作**: 直接推送代码到 GitHub 并运行 Actions" >> "$report_file"
    else
        echo "1. **需要安装交叉编译器**: sudo apt-get install gcc-aarch64-linux-gnu gcc-arm-linux-gnueabi" >> "$report_file"
        echo "2. **然后重新运行测试**" >> "$report_file"
    fi
    
    cat >> "$report_file" << EOF

## 下一步操作

### 立即开始云构建
\`\`\`bash
# 1. 初始化 Git 仓库 (如果尚未初始化)
git init
git add .
git commit -m "Add TWRP device tree and build configuration"

# 2. 推送到 GitHub
# git remote add origin https://github.com/your-username/your-repo.git
# git push -u origin main

# 3. 在 GitHub 上启用 Actions
# 4. 运行 Cloud TWRP Builder workflow
\`\`\`

### 测试构建
\`\`\`bash
# 运行快速测试
./test_cloud_build.sh

# 或者直接运行 GitHub Actions 模拟
./run_build_test.sh
\`\`\`

## 注意事项
1. **GitHub Actions 免费额度**: 每月2000分钟
2. **构建时间**: 完整构建约3-4小时
3. **存储限制**: 构建产物保留7天
4. **网络问题**: 建议使用国内镜像加速

## 支持
- **GitHub Issues**: 报告构建问题
- **文档**: 查看云构建指南.md
- **示例**: 参考现有配置文件

---
*报告生成时间: $(date)*
*测试脚本版本: 1.0*
EOF
    
    print_success "测试报告已生成: $report_file"
    echo ""
    echo "查看报告:"
    echo "  cat $report_file | less"
    echo ""
    echo "或打开文件查看完整内容"
}

# 清理临时文件
cleanup() {
    print_status "清理临时文件..."
    
    if [ -f "/tmp/twrp_test_env.txt" ]; then
        source /tmp/twrp_test_env.txt
        if [ -d "$TEMP_DIR" ]; then
            rm -rf "$TEMP_DIR"
            print_success "临时目录已清理: $TEMP_DIR"
        fi
        rm -f /tmp/twrp_test_env.txt
    fi
    
    # 清理测试文件
    rm -f test_arm64 test_arm64.c test_arm test_arm.c 2>/dev/null
}

# 主函数
main() {
    echo ""
    print_status "开始 TWRP 云构建测试..."
    echo ""
    
    # 检查工具
    if ! check_tools; then
        print_error "工具检查失败，请先安装必要工具"
        exit 1
    fi
    
    # 检查设备树
    if ! check_device_tree; then
        print_error "设备树检查失败"
        exit 1
    fi
    
    # 检查 TWRP 源码
    if ! check_twrp_source; then
        print_warning "TWRP 源码检查发现问题，但继续测试"
    fi
    
    # 设置 GitHub 环境
    setup_github_env
    
    # 测试构建配置
    test_build_config
    
    # 测试交叉编译
    test_cross_compile
    
    # 生成测试报告
    generate_test_report
    
    # 清理
    cleanup
    
    echo ""
    echo "========================================"
    print_success "TWRP 云构建测试完成!"
    echo "========================================"
    echo ""
    echo "下一步操作:"
    echo "1. 查看测试报告: cat cloud-build-test-report-*.md"
    echo "2. 安装缺失的工具 (如有)"
    echo "3. 推送代码到 GitHub"
    echo "4. 在 GitHub Actions 中运行构建"
    echo ""
    echo "详细指南请查看: 云构建指南.md"
    echo ""
}

# 运行主函数
main "$@"

# 错误处理
trap 'print_error "测试被中断"; cleanup; exit 1' INT TERM