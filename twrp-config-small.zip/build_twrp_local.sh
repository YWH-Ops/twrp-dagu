#!/bin/bash

# 本地 TWRP 构建脚本
# 适用于当前目录结构

set -e

echo "================================================"
echo "     TWRP 本地构建脚本 - 小米平板5 Pro 12.4 (dagu)"
echo "================================================"
echo ""
echo "当前目录: $(pwd)"
echo ""

# 检查当前目录结构
echo "1. 检查目录结构..."

# 检查设备树
DEVICE_DIR="device/xiaomi/dagu"
if [ ! -d "$DEVICE_DIR" ]; then
    echo "错误: 设备树目录不存在: $DEVICE_DIR"
    exit 1
fi
echo "✓ 设备树目录存在: $DEVICE_DIR"

# 检查内核文件
KERNEL_FILE="$DEVICE_DIR/prebuilt/kernel"
if [ ! -f "$KERNEL_FILE" ]; then
    echo "错误: 内核文件不存在: $KERNEL_FILE"
    exit 1
fi
echo "✓ 内核文件存在: $KERNEL_FILE"
echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
echo "  类型: $(file "$KERNEL_FILE")"

# 检查 BoardConfig.mk
if [ ! -f "$DEVICE_DIR/BoardConfig.mk" ]; then
    echo "错误: BoardConfig.mk 未找到"
    exit 1
fi
echo "✓ BoardConfig.mk 存在"

# 检查 recovery.fstab
if [ ! -f "$DEVICE_DIR/recovery.fstab" ]; then
    echo "错误: recovery.fstab 未找到"
    exit 1
fi
echo "✓ recovery.fstab 存在"

echo ""
echo "2. 检查 TWRP 源码..."

# 检查 TWRP 源码目录
if [ ! -d "android_bootable_recovery" ] && [ ! -L "bootable/recovery" ]; then
    echo "错误: TWRP 源码目录未找到"
    echo "请确保 android_bootable_recovery 目录存在"
    exit 1
fi

# 创建符号链接（如果需要）
if [ ! -L "bootable/recovery" ] && [ -d "android_bootable_recovery" ]; then
    echo "创建符号链接: bootable/recovery -> android_bootable_recovery"
    mkdir -p bootable
    ln -sf ../android_bootable_recovery bootable/recovery
fi

if [ -L "bootable/recovery" ]; then
    echo "✓ TWRP 源码链接存在: bootable/recovery"
else
    echo "✓ TWRP 源码目录存在: android_bootable_recovery"
fi

echo ""
echo "3. 检查构建环境..."

# 检查必要的工具
function check_tool() {
    local tool=$1
    local name=$2
    
    if command -v $tool >/dev/null 2>&1; then
        echo "✓ $name: $(which $tool)"
    else
        echo "✗ 错误: $name ($tool) 未安装"
        return 1
    fi
}

echo "检查构建工具:"
check_tool "make" "Make" || exit 1
check_tool "gcc" "GCC" || exit 1
check_tool "g++" "G++" || exit 1
check_tool "python3" "Python 3" || exit 1
check_tool "java" "Java" || exit 1

echo ""
echo "4. 尝试直接构建..."

# 创建简化的构建环境
echo "创建构建环境..."
export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export RECOVERY_VARIANT=twrp

# 创建输出目录
mkdir -p out/target/product/dagu

echo ""
echo "构建配置:"
echo "  ANDROID_BUILD_TOP: $ANDROID_BUILD_TOP"
echo "  TARGET_PRODUCT: $TARGET_PRODUCT"
echo "  OUT_DIR: $OUT_DIR"

echo ""
echo "5. 检查是否可以编译..."

# 进入 TWRP 目录
cd bootable/recovery
echo "进入目录: $(pwd)"

# 检查 Makefile
if [ -f "Android.mk" ]; then
    echo "✓ 找到 Android.mk"
    echo "文件大小: $(ls -lh Android.mk | awk '{print $5}')"
    echo "文件行数: $(wc -l < Android.mk)"
else
    echo "错误: Android.mk 未找到"
    exit 1
fi

# 尝试简单的编译检查
echo ""
echo "6. 尝试编译检查..."
echo "运行: make -n -f Android.mk 检查编译命令"

if make -n -f Android.mk 2>/dev/null | head -5; then
    echo ""
    echo "✓ 编译命令检查成功"
    echo ""
    echo "下一步:"
    echo "  您需要完整的 Android 源码树来构建 TWRP"
    echo "  建议运行: ./simple_twrp_clone.sh 来下载完整源码"
    echo "  或运行: ./download_twrp_fast.sh 快速下载"
    echo ""
    echo "或者，如果您已经有完整的 Android 源码:"
    echo "  1. 将 device/xiaomi/dagu 复制到 Android 源码树的 device/xiaomi/ 目录"
    echo "  2. 在 Android 源码根目录运行: source build/envsetup.sh"
    echo "  3. 运行: lunch twrp_dagu-eng"
    echo "  4. 运行: mka recoveryimage"
else
    echo ""
    echo "⚠ 编译检查失败"
    echo ""
    echo "您需要完整的 Android 源码树。建议:"
    echo "  1. 运行 ./simple_twrp_clone.sh 下载完整 TWRP 源码"
    echo "  2. 或者下载完整的 AOSP 源码并添加 TWRP"
fi

echo ""
echo "================================================"
echo "     TWRP 本地构建检查完成"
echo "================================================"
echo ""
echo "总结:"
echo "  - 设备树: ✓ 完整"
echo "  - 内核: ✓ 存在 (192MB boot.img)"
echo "  - TWRP 源码: ✓ 存在"
echo "  - 构建环境: ⚠ 需要完整 Android 源码"
echo ""
echo "下一步操作:"
echo "  运行: ./simple_twrp_clone.sh 下载完整 TWRP 源码"
echo "  或运行: ./download_twrp_fast.sh 快速下载"