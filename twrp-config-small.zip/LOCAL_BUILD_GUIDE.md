# TWRP 本地构建完整指南
## 小米平板 5 Pro 12.4 (dagu) - Windows/WSL2 环境

---

## 📋 目录

1. [构建方法对比](#构建方法对比)
2. [方法一：WSL2 构建（推荐）](#方法一 wsl2-构建推荐)
3. [方法二：纯 Windows 环境](#方法二纯-windows-环境)
4. [方法三：使用现有构建产物](#方法三使用现有构建产物)
5. [故障排除](#故障排除)

---

## 🎯 构建方法对比

| 方法 | 难度 | 时间 | 推荐度 | 说明 |
|------|------|------|--------|------|
| **WSL2 构建** | ⭐⭐⭐ | 1-2 小时 | ⭐⭐⭐⭐⭐ | 最稳定，官方支持 |
| **Docker 构建** | ⭐⭐ | 1-2 小时 | ⭐⭐⭐⭐ | 简单，但需要 Docker |
| **GitHub Actions** | ⭐ | 30-60 分钟 | ⭐⭐⭐⭐⭐ | 最简单，云端完成 |
| **使用现有产物** | ⭐ | 5 分钟 | ⭐⭐⭐⭐ | 直接刷入测试 |

---

## 方法一：WSL2 构建（推荐）⭐⭐⭐⭐⭐

### 前提条件

- ✅ Windows 10/11 with WSL2
- ✅ Ubuntu 20.04/22.04 LTS
- ✅ 至少 100GB 可用磁盘空间
- ✅ 16GB+ RAM（推荐）

### 步骤 1：准备 WSL2 环境

```powershell
# 1. 检查 WSL 版本
wsl --version

# 2. 安装 Ubuntu（如果没有）
wsl --install -d Ubuntu-22.04

# 3. 进入 WSL2
wsl
```

### 步骤 2：安装构建依赖

在 WSL2 终端中执行：

```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装必要的工具
sudo apt install -y \
    git-core gnupg flex bison build-essential zip curl \
    zlib1g-dev gcc-multilib g++-multilib libc6-dev-i386 \
    libncurses5 lib32ncurses5-dev x11proto-core-dev \
    libx11-dev lib32z1-dev libgl1-mesa-dev libxml2-utils \
    xsltproc unzip fontconfig python3 python3-pip \
    ccache lzop gperf libssl-dev bc rsync schedtool \
    libtinfo5 libncurses5-dev libreadline-dev \
    libbz2-dev liblz4-tool lz4 openjdk-11-jdk

# 设置 Java
sudo update-java-alternatives --set java-1.11.0-openjdk-amd64
```

### 步骤 3：下载 TWRP 源码

```bash
# 创建目录
mkdir -p ~/twrp-source
cd ~/twrp-source

# 初始化 repo
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1

# 同步源码（约 20GB，需要较长时间）
repo sync -j$(nproc) --no-tags --no-clone-bundle
```

### 步骤 4：复制设备树

```bash
# 从 Windows 挂载点复制设备树
cp -r /mnt/e/twrp/device/xiaomi/dagu ~/twrp-source/device/xiaomi/

# 验证复制成功
ls -la device/xiaomi/dagu/
```

### 步骤 5：开始构建

```bash
# 进入源码目录
cd ~/twrp-source

# 初始化构建环境
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

# 开始构建（需要 1-2 小时）
mka recoveryimage
```

### 步骤 6：获取构建产物

构建成功后，recovery 镜像位于：

```bash
~/twrp-source/out/target/product/dagu/recovery.img
```

复制到 Windows：

```bash
cp ~/twrp-source/out/target/product/dagu/recovery.img /mnt/e/twrp/output/
```

---

## 方法二：纯 Windows 环境 ⭐⭐

### 使用 Docker（简化版）

#### 步骤 1：安装 Docker Desktop

1. 下载 Docker Desktop for Windows
2. 安装并启用 WSL2 后端
3. 启动 Docker Desktop

#### 步骤 2：使用 Docker 容器构建

创建 `build_with_docker.bat`：

```batch
@echo off
echo Building TWRP with Docker...
docker run -it --rm ^
    -v %CD%:/workspace ^
    -w /workspace ^
    ubuntu:20.04 /bin/bash -c ^
    "apt-get update && apt-get install -y git repo && echo 'Setup complete'"
```

**注意**: 完整的 Docker 构建比较复杂，建议使用 WSL2 或 GitHub Actions。

---

## 方法三：使用现有构建产物 ⭐⭐⭐⭐

### 直接使用已有的镜像

你已经有一个构建好的镜像：

```
e:\twrp\output\twrp-dagu-20260401.img (128MB)
```

### 步骤 1：验证镜像

```powershell
cd e:\twrp\output

# 检查文件大小
ls -lh twrp-dagu-20260401.img

# 应该显示约 128MB
```

### 步骤 2：测试刷入

```powershell
# 1. 进入 fastboot 模式
adb reboot bootloader

# 等待 5 秒
Start-Sleep -Seconds 5

# 2. 临时启动 TWRP（安全测试）
fastboot boot twrp-dagu-20260401.img

# 如果不满意，重启就会回到原系统
```

### 步骤 3：永久刷入

```powershell
# 1. 进入 fastboot
adb reboot bootloader

# 2. 刷入 recovery
fastboot flash recovery twrp-dagu-20260401.img

# 3. 重启到 TWRP
fastboot reboot recovery
```

---

## 🔧 快速构建脚本

### PowerShell 自动化脚本

创建 `local_build_helper.ps1`：

```powershell
Write-Host "=== TWRP Local Build Helper ===" -ForegroundColor Cyan
Write-Host ""

# 检查现有构建
if (Test-Path "output\twrp-dagu-*.img") {
    Write-Host "[OK] Found existing build:" -ForegroundColor Green
    Get-Item "output\twrp-dagu-*.img" | ForEach-Object {
        $size = [math]::Round($_.Length / 1MB, 2)
        Write-Host "  - $($_.Name) ($size MB)" -ForegroundColor Gray
    }
    Write-Host ""
    
    $useExisting = Read-Host "Use existing build? (Y/N, default: Y)"
    if ($useExisting -ne "N" -and $useExisting -ne "n") {
        Write-Host ""
        Write-Host "Ready to flash!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Commands:" -ForegroundColor Cyan
        Write-Host "  1. adb reboot bootloader" -ForegroundColor White
        Write-Host "  2. fastboot boot output\twrp-dagu-*.img" -ForegroundColor White
        Write-Host ""
        return
    }
}

# 提供其他选项
Write-Host ""
Write-Host "Choose build method:" -ForegroundColor Cyan
Write-Host "  [1] WSL2 Build (Recommended)" -ForegroundColor White
Write-Host "  [2] GitHub Actions Cloud Build" -ForegroundColor White
Write-Host "  [3] Use Existing Build" -ForegroundColor White

$choice = Read-Host "Enter choice (1/2/3, default: 3)"

switch ($choice) {
    "1" {
        Write-Host ""
        Write-Host "Starting WSL2 build..." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Please follow these steps in WSL2:" -ForegroundColor Cyan
        Write-Host "  1. wsl" -ForegroundColor White
        Write-Host "  2. cd ~ && mkdir twrp-source && cd twrp-source" -ForegroundColor White
        Write-Host "  3. repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1" -ForegroundColor White
        Write-Host "  4. repo sync -j\$(nproc)" -ForegroundColor White
        Write-Host "  5. cp -r /mnt/e/twrp/device/xiaomi/dagu ~/twrp-source/device/xiaomi/" -ForegroundColor White
        Write-Host "  6. source build/envsetup.sh && lunch twrp_dagu-eng" -ForegroundColor White
        Write-Host "  7. mka recoveryimage" -ForegroundColor White
        Write-Host ""
    }
    "2" {
        Write-Host ""
        Write-Host "Opening GitHub Actions..." -ForegroundColor Green
        Start-Process "https://github.com/b15185591889/twrp-dagu/actions"
        Write-Host "Follow the cloud build guide." -ForegroundColor Gray
    }
    "3" {
        Write-Host ""
        Write-Host "Using existing build." -ForegroundColor Green
        Write-Host "Flash commands:" -ForegroundColor Cyan
        Write-Host "  1. adb reboot bootloader" -ForegroundColor White
        Write-Host "  2. fastboot boot output\twrp-dagu-*.img" -ForegroundColor White
    }
}
```

运行脚本：

```powershell
cd e:\twrp
.\local_build_helper.ps1
```

---

## 📊 构建时间对比

| 阶段 | WSL2 | GitHub Actions |
|------|------|----------------|
| 环境搭建 | 30 分钟 | 5 分钟 |
| 下载源码 | 30-60 分钟 | 10-20 分钟 |
| 设备树配置 | 2 分钟 | 2 分钟 |
| 编译构建 | 40-80 分钟 | 20-40 分钟 |
| 上传产物 | - | 3-5 分钟 |
| **总计** | **104-174 分钟** | **40-72 分钟** |

---

## ⚠️ 常见问题

### Q1: WSL2 空间不足？

```bash
# 检查空间
df -h

# 清理空间
sudo apt clean
repo gc
```

### Q2: 构建失败？

```bash
# 查看详细错误
tail -100 out/error.log

# 清理重新构建
make clean
mka recoveryimage
```

### Q3: 网络太慢？

```bash
# 使用国内镜像
export REPO_URL='https://mirrors.tuna.tsinghua.edu.cn/git/git-repo'
```

### Q4: 找不到设备？

```powershell
# 检查 ADB 连接
adb devices

# 检查 Fastboot 连接
fastboot devices
```

---

## 💡 最佳实践建议

### 对于 Windows 用户

1. **首选**: GitHub Actions 云构建（最简单）
2. **备选**: WSL2 本地构建（最灵活）
3. **快速测试**: 使用现有构建产物

### 对于 Linux/Mac 用户

直接使用本地构建：

```bash
cd /path/to/twrp-source
source build/envsetup.sh
lunch twrp_dagu-eng
mka recoveryimage
```

---

## 📞 获取帮助

### 文档资源

- `README_BUILD.md` - 构建说明
- `TWRP_BUILD_GUIDE.md` - 完整教程
- `GITHUB_ACTIONS_BUILD_GUIDE.md` - 云构建指南
- `FAST_TRACK_GUIDE.md` - 快速开始

### 社区支持

- XDA 论坛：Xiaomi Mi Pad 5 版块
- Telegram: "dagu TWRP" 群组
- GitHub Issues: 你的仓库 Issues

---

## ✅ 总结

### 最简单的路径（推荐）

1. **使用现有构建** - 直接刷入测试
2. **GitHub Actions** - 云端自动构建
3. **WSL2 本地构建** - 完全控制

### 当前状态

✅ 你已经有构建好的镜像：`output/twrp-dagu-20260401.img`  
✅ 可以直接用于测试和刷入  
✅ 如需重新构建，选择上述任一方法

---

**立即开始**: 使用现有镜像进行快速测试！🚀

```powershell
adb reboot bootloader
fastboot boot output\twrp-dagu-20260401.img
```

*最后更新：2026 年 4 月 1 日*
