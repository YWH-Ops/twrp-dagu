@echo off
chcp 65001 >nul
title TWRP Builder - 小米平板5 Pro 12.4 (dagu)
color 0A

echo ================================================
echo    TWRP 构建工具 - 小米平板5 Pro 12.4 (dagu)
echo ================================================
echo.

:menu
cls
echo 请选择操作:
echo.
echo  1. 检查构建环境
echo  2. 在 WSL2 中构建 TWRP
echo  3. 创建刷机包
echo  4. 验证构建结果
echo  5. 查看构建指南
echo  6. 查看安装指南
echo  7. 清理输出目录
echo  8. 退出
echo.

set /p choice=请输入选项 (1-8): 

if "%choice%"=="1" goto check
if "%choice%"=="2" goto build
if "%choice%"=="3" goto package
if "%choice%"=="4" goto verify
if "%choice%"=="5" goto guide
if "%choice%"=="6" goto install
if "%choice%"=="7" goto clean
if "%choice%"=="8" goto exit
echo 无效选项，请重试
timeout /t 2 >nul
goto menu

:check
echo.
echo [1/3] 检查工具...
where adb >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo  ✓ ADB 已安装
) else (
    echo  ✗ ADB 未安装
)

where fastboot >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo  ✓ Fastboot 已安装
) else (
    echo  ✗ Fastboot 未安装
)

where wsl >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo  ✓ WSL 已安装
) else (
    echo  ✗ WSL 未安装
)

echo.
echo [2/3] 检查设备树...
if exist "device\xiaomi\dagu\BoardConfig.mk" (
    echo  ✓ BoardConfig.mk 存在
) else (
    echo  ✗ BoardConfig.mk 不存在
)

if exist "device\xiaomi\dagu\device.mk" (
    echo  ✓ device.mk 存在
) else (
    echo  ✗ device.mk 不存在
)

if exist "device\xiaomi\dagu\recovery.fstab" (
    echo  ✓ recovery.fstab 存在
) else (
    echo  ✗ recovery.fstab 不存在
)

echo.
echo [3/3] 检查 WSL2 环境...
wsl --list --verbose | findstr "Ubuntu" >nul
if %ERRORLEVEL% EQU 0 (
    echo  ✓ Ubuntu 已安装
) else (
    echo  ✗ Ubuntu 未安装
)

echo.
echo 检查完成!
echo.
pause
goto menu

:build
echo.
echo 警告: 构建 TWRP 需要较长时间 (30-60分钟)
echo 请确保:
echo  1. WSL2 和 Ubuntu 已安装
echo  2. 至少 100GB 可用磁盘空间
echo  3. 稳定的网络连接
echo.
set /p confirm=是否继续? (y/N): 
if /i not "%confirm%"=="y" goto menu

echo.
echo 开始构建 TWRP...
echo 这将打开 PowerShell 构建脚本...
timeout /t 3 >nul
powershell -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1" build
echo.
pause
goto menu

:package
echo.
echo 创建刷机包...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1" package
echo.
pause
goto menu

:verify
echo.
echo 验证构建结果...
echo.
if exist "verify_build.py" (
    python verify_build.py
) else (
    echo 验证脚本不存在，请先构建
)
echo.
pause
goto menu

:guide
echo.
echo 打开构建指南...
start "" "构建指南.md"
echo.
pause
goto menu

:install
echo.
echo 打开安装指南...
start "" "INSTALL.md"
echo.
pause
goto menu

:clean
echo.
echo 清理输出目录...
if exist "output" (
    rmdir /s /q "output"
    echo 输出目录已清理
) else (
    echo 输出目录不存在
)
echo.
pause
goto menu

:exit
echo.
echo 退出 TWRP 构建工具
echo.
pause
exit /b 0