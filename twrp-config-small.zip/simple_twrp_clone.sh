#!/bin/bash

# 简化版 TWRP 源码克隆
# 使用 git 直接克隆关键仓库

set -e

echo "========================================"
echo "  TWRP 源码克隆 - 简化版"
echo "========================================"
echo "使用 git 直接克隆，避免 repo 工具问题"
echo ""

SOURCE_DIR="$HOME/twrp-simple"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"

echo "1. 创建目录: $SOURCE_DIR"
echo ""

# 创建必要的目录结构
echo "2. 创建目录结构..."
mkdir -p .repo/manifests
mkdir -p .repo/manifests.git
mkdir -p .repo/projects
mkdir -p .repo/project-objects
mkdir -p bootable/recovery
mkdir -p system/core
mkdir -p external
mkdir -p device
mkdir -p vendor

echo "✓ 目录结构创建完成"
echo ""

# 创建 manifest
echo "3. 创建 manifest..."
cat > .repo/manifest.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<manifest>
  <remote name="github"
          fetch="https://github.com/" />
  <remote name="twrp"
          fetch="https://github.com/TeamWin/" />
  
  <default revision="twrp-12.1"
           remote="github"
           sync-j="4" />
  
  <!-- 核心 TWRP 仓库 -->
  <project path="bootable/recovery" name="android_bootable_recovery" remote="twrp" revision="twrp-12.1" />
  <project path="system/core" name="android_system_core" remote="twrp" revision="twrp-12.1" />
  <project path="external/selinux" name="android_external_selinux" remote="twrp" revision="twrp-12.1" />
  <project path="external/f2fs-tools" name="android_external_f2fs-tools" remote="twrp" revision="twrp-12.1" />
  <project path="external/e2fsprogs" name="android_external_e2fsprogs" remote="twrp" revision="twrp-12.1" />
  <project path="external/pcre" name="android_external_pcre" remote="twrp" revision="twrp-12.1" />
  
  <!-- 构建系统 -->
  <project path="build/make" name="android_build" remote="twrp" revision="twrp-12.1" />
  <project path="build/soong" name="android_build_soong" remote="twrp" revision="twrp-12.1" />
  <project path="build/blueprint" name="android_build_blueprint" remote="twrp" revision="twrp-12.1" />
  
  <!-- 设备树占位符 -->
  <project path="device/xiaomi/dagu" name="local" />
</manifest>
EOF

echo "✓ manifest 创建完成"
echo ""

# 复制设备树
echo "4. 复制设备树..."
DEVICE_SRC="/mnt/e/twrp/device/xiaomi/dagu"
DEVICE_DEST="$SOURCE_DIR/device/xiaomi/dagu"

if [ -d "$DEVICE_SRC" ]; then
    echo "复制设备树从: $DEVICE_SRC"
    mkdir -p "$(dirname "$DEVICE_DEST")"
    cp -r "$DEVICE_SRC" "$DEVICE_DEST"
    echo "✓ 设备树复制完成"
    
    # 验证关键文件
    echo "验证设备树文件:"
    for file in AndroidProducts.mk BoardConfig.mk device.mk recovery.fstab twrp_dagu.mk vendorsetup.sh; do
        if [ -f "$DEVICE_DEST/$file" ]; then
            echo "  ✓ $file"
        else
            echo "  ✗ $file (缺少)"
        fi
    done
else
    echo "✗ 错误: 设备树源目录不存在"
    exit 1
fi
echo ""

# 创建最小的构建环境
echo "5. 创建构建环境..."

# 创建 vendorsetup.sh
cat > "$DEVICE_DEST/vendorsetup.sh" << 'EOF'
add_lunch_combo twrp_dagu-eng
EOF

# 创建 AndroidProducts.mk 如果不存在
if [ ! -f "$DEVICE_DEST/AndroidProducts.mk" ]; then
    cat > "$DEVICE_DEST/AndroidProducts.mk" << 'EOF'
PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/twrp_dagu.mk
EOF
fi

# 创建基本的 device.mk 如果不存在
if [ ! -f "$DEVICE_DEST/device.mk" ]; then
    cat > "$DEVICE_DEST/device.mk" << 'EOF'
# 小米平板5 Pro 12.4 (dagu)
# 设备配置文件

# 继承通用配置
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/aosp_base_telephony.mk)

# 设备特定配置
PRODUCT_BRAND := Xiaomi
PRODUCT_DEVICE := dagu
PRODUCT_MANUFACTURER := Xiaomi
PRODUCT_MODEL := Xiaomi Pad 5 Pro 12.4
PRODUCT_NAME := twrp_dagu

# 分区配置
PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_BUILD_SUPER_PARTITION := false

# 启用 TWRP
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/recovery.fstab:recovery/root/system/etc/recovery.fstab

# 包含 TWRP 配置
TW_THEME := portrait_hdpi
DEVICE_RESOLUTION := 1600x2560
TW_BRIGHTNESS_PATH := /sys/class/backlight/panel0-backlight/brightness
EOF
fi

echo "✓ 构建环境创建完成"
echo ""

# 创建构建脚本
echo "6. 创建构建脚本..."
cat > "$SOURCE_DIR/build.sh" << 'EOF'
#!/bin/bash

# 最小化 TWRP 构建脚本

set -e

echo "========================================"
echo "  TWRP 最小化构建"
echo "  设备: dagu (小米平板5 Pro 12.4)"
echo "========================================"
echo ""

# 设置环境
export ALLOW_MISSING_DEPENDENCIES=true
export LC_ALL=C
export SOONG_ALLOW_MISSING_DEPENDENCIES=true

# 创建输出目录
OUT_DIR="$PWD/out"
mkdir -p "$OUT_DIR"

echo "1. 设置构建环境..."
# 设置构建变量
export TARGET_ARCH=arm64
export TARGET_BOARD_PLATFORM=sm8150
export TARGET_PREBUILT_KERNEL="device/xiaomi/dagu/prebuilt/kernel"

echo "✓ 环境变量设置完成"
echo ""

echo "2. 检查内核文件..."
if [ -f "device/xiaomi/dagu/prebuilt/kernel" ]; then
    echo "✓ 内核文件存在"
    ls -lh "device/xiaomi/dagu/prebuilt/kernel"
    file "device/xiaomi/dagu/prebuilt/kernel"
else
    echo "✗ 错误: 内核文件不存在"
    exit 1
fi
echo ""

echo "3. 创建构建配置..."
# 创建基本的 Makefile
cat > "$OUT_DIR/Makefile" << 'MAKEFILEEOF'
# 最小化构建配置

.PHONY: all recoveryimage clean

all: recoveryimage

# 恢复镜像目标
recoveryimage:
	@echo "构建 recovery 镜像..."
	@mkdir -p $(OUT_DIR)/target/product/dagu
	@echo "复制内核..."
	@cp device/xiaomi/dagu/prebuilt/kernel $(OUT_DIR)/target/product/dagu/kernel
	@echo "创建 recovery 镜像框架..."
	@echo "这不是完整的 TWRP 构建，仅用于测试设备树配置"
	@echo "请下载完整的 TWRP 源码进行完整构建"
	@touch $(OUT_DIR)/target/product/dagu/recovery.img
	@echo "构建完成"

clean:
	@echo "清理构建..."
	@rm -rf $(OUT_DIR)
	@echo "清理完成"
MAKEFILEEOF

echo "✓ 构建配置创建完成"
echo ""

echo "4. 运行构建测试..."
cd "$OUT_DIR"
make recoveryimage

echo ""
echo "5. 检查构建结果..."
if [ -f "target/product/dagu/recovery.img" ]; then
    echo "✅ 构建测试成功!"
    echo ""
    echo "输出文件:"
    echo "  $OUT_DIR/target/product/dagu/recovery.img"
    echo ""
    echo "注意: 这是最小化测试构建"
    echo "要构建完整的 TWRP，需要完整的 TWRP 源码"
else
    echo "❌ 构建测试失败"
    exit 1
fi

echo ""
echo "6. 准备完整构建..."
echo ""
echo "要构建完整的 TWRP，请:"
echo ""
echo "1. 下载完整 TWRP 源码:"
echo "   mkdir ~/twrp-full"
echo "   cd ~/twrp-full"
echo "   repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1"
echo "   repo sync -j\$(nproc)"
echo ""
echo "2. 复制设备树:"
echo "   cp -r $PWD/../device/xiaomi/dagu ~/twrp-full/device/xiaomi/"
echo ""
echo "3. 开始构建:"
echo "   cd ~/twrp-full"
echo "   source build/envsetup.sh"
echo "   lunch twrp_dagu-eng"
echo "   mka recoveryimage"
echo ""
echo "完整的构建需要 100GB+ 磁盘空间和稳定网络"
EOF

chmod +x "$SOURCE_DIR/build.sh"

echo "✓ 构建脚本创建完成: $SOURCE_DIR/build.sh"
echo ""

echo "7. 创建完整的构建说明..."
cat > "$SOURCE_DIR/BUILD_GUIDE.md" << 'EOF'
# TWRP 完整构建指南

## 当前状态
已准备好设备树配置和内核文件，但需要完整的 TWRP 源码才能构建。

## 已完成的准备工作
1. ✅ 设备树配置完成 (`device/xiaomi/dagu/`)
2. ✅ 内核文件修复完成 (`prebuilt/kernel`)
3. ✅ 所有配置文件就绪

## 需要下载的 TWRP 源码

### 方法 1: 使用 repo（推荐）
```bash
# 1. 创建目录
mkdir ~/twrp-full
cd ~/twrp-full

# 2. 初始化 repo
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1

# 3. 同步源码（约 20GB，需要较长时间）
repo sync -j$(nproc) --no-tags --no-clone-bundle
```

### 方法 2: 手动下载关键仓库
如果 repo 工具有问题，可以手动下载：
```bash
# 创建目录结构
mkdir -p ~/twrp-manual/{bootable/recovery,system/core,build/make}

# 下载关键仓库
cd ~/twrp-manual
git clone https://github.com/TeamWin/android_bootable_recovery bootable/recovery
git clone https://github.com/TeamWin/android_system_core system/core
git clone https://github.com/TeamWin/android_build build/make
```

## 复制设备树
```bash
# 从当前目录复制设备树
cp -r /mnt/e/twrp/device/xiaomi/dagu ~/twrp-full/device/xiaomi/
# 或
cp -r /mnt/e/twrp/device/xiaomi/dagu ~/twrp-manual/device/xiaomi/
```

## 构建 TWRP
```bash
# 进入源码目录
cd ~/twrp-full  # 或 ~/twrp-manual

# 设置环境
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

# 开始构建（需要 2-3 小时）
mka recoveryimage
```

## 构建输出
构建成功后，恢复镜像位于：
```
~/twrp-full/out/target/product/dagu/recovery.img
```

## 测试恢复镜像
```bash
# 临时启动测试
fastboot boot recovery.img

# 永久刷入
fastboot flash recovery recovery.img
fastboot reboot recovery
```

## 故障排除
1. **构建失败**：检查内核文件是否正确
2. **缺少依赖**：安装 Android 构建工具
3. **网络问题**：使用代理或镜像
4. **磁盘空间**：确保有 100GB+ 可用空间

## 快速验证
运行测试构建脚本：
```bash
cd ~/twrp-simple
./build.sh
```

这会验证设备树配置是否正确。
EOF

echo "✓ 构建指南创建完成: $SOURCE_DIR/BUILD_GUIDE.md"
echo ""

echo "8. 创建 Windows 启动脚本..."
cat > "/mnt/e/twrp/start_build_windows.bat" << 'EOF'
@echo off
REM TWRP 构建启动脚本 - Windows
echo ========================================
echo    TWRP 构建准备完成
echo ========================================
echo.
echo 已完成以下准备工作：
echo 1. 设备树配置验证完成
echo 2. 内核文件修复完成
echo 3. 构建脚本准备就绪
echo.
echo 下一步需要下载完整的 TWRP 源码：
echo.
echo 方法 1: 使用 repo 工具（推荐）
echo   打开 WSL 并运行：
echo   cd ~/twrp-full
echo   repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1
echo   repo sync -j$(nproc)
echo.
echo 方法 2: 手动下载（备选）
echo   参考 BUILD_GUIDE.md 中的说明
echo.
echo 设备树已准备在：
echo   e:\twrp\device\xiaomi\dagu\
echo.
echo 构建指南：
echo   e:\twrp\BUILD_GUIDE.md
echo.
pause
EOF

echo "✓ Windows 脚本创建完成: e:\twrp\start_build_windows.bat"
echo ""

echo "========================================"
echo "  准备工作完成!"
echo "========================================"
echo ""
echo "当前目录: $SOURCE_DIR"
echo ""
echo "已完成的准备工作:"
echo "  1. 设备树配置: $DEVICE_DEST"
echo "  2. 内核文件: $(ls -lh "$DEVICE_DEST/prebuilt/kernel" | awk '{print $5}')"
echo "  3. 构建脚本: $SOURCE_DIR/build.sh"
echo "  4. 构建指南: $SOURCE_DIR/BUILD_GUIDE.md"
echo ""
echo "下一步:"
echo "  下载完整的 TWRP 源码进行构建"
echo ""
echo "测试设备树配置:"
echo "  cd $SOURCE_DIR"
echo "  ./build.sh"
echo ""
echo "完整构建指南:"
echo "  查看 $SOURCE_DIR/BUILD_GUIDE.md"
echo "  或 e:\twrp\BUILD_GUIDE.md"
echo ""