# GitHub 设置指南 - TWRP 云构建

## 📋 已完成的工作

✅ **Git 仓库已初始化** - 代码已提交到本地仓库

## 🔐 下一步：设置 GitHub

### 第一步：获取 GitHub 用户名
1. 访问 https://github.com
2. 登录您的账户
3. 查看右上角头像旁边的用户名
   - 例如：`zhangsan`、`githubuser123`
4. 或者查看个人资料页面 URL：`https://github.com/您的用户名`

### 第二步：创建 GitHub 仓库
1. 访问 https://github.com/new
2. 填写以下信息：
   - **Repository name**: `twrp-dagu`
   - **Description**: `TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)`
   - **Visibility**: `Public` (公开)
   - **不要勾选**：
     - ✅ Initialize this repository with a README
     - ✅ Add .gitignore
     - ✅ Choose a license
3. 点击 `Create repository`

### 第三步：推送代码到 GitHub

在 WSL 终端中运行以下命令（替换 `YOUR_GITHUB_USERNAME` 为您的 GitHub 用户名）：

```bash
cd /mnt/e/twrp

# 添加所有文件
git add -f .

# 提交更改
git commit -m "准备 TWRP 云构建"

# 添加远程仓库（替换 YOUR_GITHUB_USERNAME）
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/twrp-dagu.git

# 重命名分支并推送
git branch -M main
git push -u origin main
```

### 第四步：启用 GitHub Actions

1. 访问您的仓库：`https://github.com/YOUR_GITHUB_USERNAME/twrp-dagu`
2. 点击顶部 `Actions` 标签
3. 点击 `I understand my workflows, go ahead and enable them`
4. 您会看到三个工作流：
   - **Cloud TWRP Builder with China Mirror** (主构建工作流)
   - **Quick TWRP Build Test** (快速测试工作流)
   - **Build TWRP for Xiaomi Pad 5 Pro 12.4** (原始构建工作流)

### 第五步：启动构建

1. 在 Actions 页面，点击 `Cloud TWRP Builder with China Mirror`
2. 点击 `Run workflow`
3. 配置参数：
   - **use_china_mirror**: `true` (使用国内镜像加速)
   - **build_type**: `minimal` (首次构建建议)
   - **upload_artifact**: `true` (上传构建产物)
4. 点击 `Run workflow`
5. 等待构建完成 (约1-2小时)

## ⚡ 一键推送脚本

我已经为您创建了一键推送脚本。运行以下命令：

```bash
cd /mnt/e/twrp
./setup_github_repo.sh
```

脚本会引导您完成所有步骤。

## 🔧 手动推送命令

如果遇到问题，可以使用以下命令手动推送：

```bash
# 1. 设置 Git 配置（如果未设置）
git config --global user.name "您的名字"
git config --global user.email "您的邮箱"

# 2. 检查 Git 状态
git status

# 3. 添加所有文件
git add -f .

# 4. 提交更改
git commit -m "TWRP 云构建配置"

# 5. 添加远程仓库
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/twrp-dagu.git

# 6. 重命名分支并推送
git branch -M main
git push -u origin main
```

## 📝 常见问题

### Q1: 推送时要求输入用户名和密码
**解决**：使用访问令牌代替密码
1. 访问 https://github.com/settings/tokens
2. 点击 `Generate new token`
3. 选择 `repo` 权限
4. 生成令牌并保存
5. 推送时使用令牌作为密码

### Q2: 权限被拒绝
**解决**：
```bash
# 检查远程仓库地址
git remote -v

# 重新设置远程仓库
git remote remove origin
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/twrp-dagu.git
```

### Q3: 仓库已存在
**解决**：
```bash
# 强制推送
git push -f origin main
```

### Q4: 需要 SSH 密钥
**解决**：
1. 生成 SSH 密钥：`ssh-keygen -t ed25519 -C "your_email@example.com"`
2. 添加到 GitHub：https://github.com/settings/keys
3. 使用 SSH 地址：`git@github.com:YOUR_GITHUB_USERNAME/twrp-dagu.git`

## 🚀 快速开始命令

```bash
# 设置 Git 配置
git config --global user.name "TWRP Builder"
git config --global user.email "builder@example.com"

# 推送代码（替换 YOUR_GITHUB_USERNAME）
cd /mnt/e/twrp
git add -f .
git commit -m "TWRP 云构建"
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/twrp-dagu.git
git branch -M main
git push -u origin main
```

## 📞 需要帮助？

如果您在设置过程中遇到问题，请提供：
1. **GitHub 用户名**
2. **遇到的错误信息**
3. **您已经尝试的步骤**

我可以为您生成具体的命令和解决方案。

## ✅ 检查清单

- [ ] 获取 GitHub 用户名
- [ ] 创建 GitHub 仓库
- [ ] 推送代码到 GitHub
- [ ] 启用 GitHub Actions
- [ ] 启动 TWRP 构建
- [ ] 等待构建完成
- [ ] 下载 recovery.img

**现在请告诉我您的 GitHub 用户名，我可以为您生成完整的命令！**