#!/bin/bash

echo "========================================"
echo "   下载状态检查"
echo "========================================"
echo "检查时间: $(date)"
echo ""

# 检查构建目录
echo "1. 检查构建目录..."
BUILD_DIRS=$(find /home -name "android-twrp-fast-*" -type d 2>/dev/null | sort -r)
if [ -n "$BUILD_DIRS" ]; then
    LATEST_DIR=$(echo "$BUILD_DIRS" | head -1)
    echo "最新构建目录: $LATEST_DIR"
    echo "所有构建目录:"
    echo "$BUILD_DIRS"
    echo ""
    
    # 检查目录内容
    echo "目录内容:"
    ls -la "$LATEST_DIR" 2>/dev/null || echo "无法访问目录"
    echo ""
    
    # 检查大小
    echo "目录大小:"
    du -sh "$LATEST_DIR" 2>/dev/null || echo "无法计算大小"
    echo ""
    
    # 检查组件
    echo "2. 检查组件状态:"
    COMPONENTS=(
        "build/make"
        "build/soong"
        "system/core"
        "hardware/interfaces"
        "external/selinux"
        "bootable/recovery"
        "device/xiaomi/dagu"
    )
    
    for comp in "${COMPONENTS[@]}"; do
        if [ -d "$LATEST_DIR/$comp" ] || [ -L "$LATEST_DIR/$comp" ]; then
            echo "  ✓ $comp"
            if [ "$comp" = "device/xiaomi/dagu" ] && [ -f "$LATEST_DIR/$comp/BoardConfig.mk" ]; then
                echo "    文件: $(ls -lh "$LATEST_DIR/$comp/BoardConfig.mk" 2>/dev/null | awk '{print $5}')"
            fi
            if [ "$comp" = "bootable/recovery" ] && [ -f "$LATEST_DIR/$comp/Android.mk" ]; then
                echo "    文件: $(ls -lh "$LATEST_DIR/$comp/Android.mk" 2>/dev/null | awk '{print $5}')"
            fi
        else
            echo "  ✗ $comp (缺失)"
        fi
    done
    
    echo ""
    
    # 检查构建环境
    echo "3. 检查构建环境:"
    if [ -f "$LATEST_DIR/build/envsetup.sh" ]; then
        echo "  ✓ build/envsetup.sh"
    else
        echo "  ✗ build/envsetup.sh (缺失)"
    fi
    
    if [ -f "$LATEST_DIR/test_build.sh" ]; then
        echo "  ✓ test_build.sh"
    else
        echo "  ✗ test_build.sh (缺失)"
    fi
    echo ""
    
    # 检查文件数量
    echo "4. 统计文件:"
    echo "  .mk 文件: $(find "$LATEST_DIR" -name "*.mk" 2>/dev/null | wc -l)"
    echo "  .bp 文件: $(find "$LATEST_DIR" -name "*.bp" 2>/dev/null | wc -l)"
    echo "  总文件数: $(find "$LATEST_DIR" -type f 2>/dev/null | wc -l)"
    echo ""
    
else
    echo "未找到构建目录"
    echo "请运行 fast_twrp_download.sh 或 download_with_china_mirrors.sh"
fi

echo "========================================"
echo "   镜像源状态"
echo "========================================"
echo "测试清华大学镜像:"
ping -c 2 mirrors.tuna.tsinghua.edu.cn >/dev/null 2>&1 && echo "  ✓ 清华大学镜像可达" || echo "  ✗ 清华大学镜像不可达"
echo ""
echo "测试 GitHub:"
ping -c 2 github.com >/dev/null 2>&1 && echo "  ✓ GitHub 可达" || echo "  ✗ GitHub 不可达"
echo ""
echo "测试网络连接:"
curl -I --connect-timeout 5 https://mirrors.tuna.tsinghua.edu.cn 2>/dev/null | head -1 | grep "200\|301\|302" && echo "  ✓ 清华大学镜像网站可访问" || echo "  ✗ 清华大学镜像网站不可访问"
echo ""

echo "========================================"
echo "   下一步建议"
echo "========================================"
if [ -n "$LATEST_DIR" ]; then
    echo "1. 进入构建目录:"
    echo "   cd $LATEST_DIR"
    echo ""
    echo "2. 运行构建测试:"
    echo "   ./test_build.sh"
    echo ""
    echo "3. 或开始构建:"
    echo "   source build/envsetup.sh"
    echo "   lunch twrp_dagu-eng"
    echo "   mka recoveryimage"
    echo ""
    
    # 检查缺失组件
    MISSING_COUNT=0
    for comp in "${COMPONENTS[@]}"; do
        if [ ! -d "$LATEST_DIR/$comp" ] && [ ! -L "$LATEST_DIR/$comp" ]; then
            MISSING_COUNT=$((MISSING_COUNT+1))
        fi
    done
    
    if [ $MISSING_COUNT -gt 0 ]; then
        echo "警告: 缺少 $MISSING_COUNT 个组件"
        echo "建议运行: ./fast_twrp_download.sh 重新下载"
    else
        echo "所有必要组件已就绪，可以开始构建!"
    fi
else
    echo "1. 下载源码:"
    echo "   ./fast_twrp_download.sh"
    echo ""
    echo "2. 或使用完整镜像:"
    echo "   ./download_with_china_mirrors.sh"
fi
echo ""