#!/bin/bash

# 验证 GitHub Actions 配置脚本
# 检查所有必要的配置文件和结构

echo "========================================"
echo "GitHub Actions 配置验证"
echo "========================================"
echo ""

# 检查 GitHub Actions 目录
echo "检查 GitHub Actions 目录结构..."
if [ ! -d ".github/workflows" ]; then
    echo "❌ 缺少 .github/workflows 目录"
    exit 1
fi

echo "✅ .github/workflows 目录存在"

# 检查工作流文件
workflow_files=(
    ".github/workflows/cloud-build.yml"
    ".github/workflows/quick-build.yml"
    ".github/workflows/build-twrp.yml"
)

for file in "${workflow_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
        
        # 检查文件大小
        file_size=$(wc -l < "$file")
        if [ "$file_size" -lt 10 ]; then
            echo "  ⚠️  文件可能为空或过小 ($file_size 行)"
        else
            echo "  📄 文件大小: $file_size 行"
        fi
        
        # 检查基本语法
        if grep -q "name:" "$file" && grep -q "on:" "$file" && grep -q "jobs:" "$file"; then
            echo "  ✅ 基本语法正确"
        else
            echo "  ⚠️  基本语法可能有问题"
        fi
    else
        echo "❌ $file 不存在"
    fi
done

echo ""
echo "========================================"
echo "检查设备树结构..."
echo "========================================"

# 检查设备树
device_tree_files=(
    "device/xiaomi/dagu/BoardConfig.mk"
    "device/xiaomi/dagu/twrp_dagu.mk"
    "device/xiaomi/dagu/recovery.fstab"
    "device/xiaomi/dagu/prebuilt/kernel"
)

for file in "${device_tree_files[@]}"; do
    if [ -f "$file" ]; then
        file_size=$(ls -lh "$file" 2>/dev/null | awk '{print $5}' || echo "未知")
        echo "✅ $file 存在 ($file_size)"
        
        # 检查关键配置
        case "$file" in
            "device/xiaomi/dagu/BoardConfig.mk")
                if grep -q "TARGET_ARCH" "$file"; then
                    echo "  📋 TARGET_ARCH: $(grep "TARGET_ARCH" "$file" | head -1)"
                fi
                if grep -q "TW_" "$file"; then
                    tw_count=$(grep -c "^TW_" "$file")
                    echo "  📋 TWRP 配置项: $tw_count 个"
                fi
                ;;
            "device/xiaomi/dagu/twrp_dagu.mk")
                if grep -q "PRODUCT_NAME" "$file"; then
                    echo "  📋 产品名称: $(grep "PRODUCT_NAME" "$file")"
                fi
                ;;
            "device/xiaomi/dagu/recovery.fstab")
                partition_count=$(grep -c "^/dev/" "$file" 2>/dev/null || echo "0")
                echo "  📋 分区配置: $partition_count 个"
                ;;
            "device/xiaomi/dagu/prebuilt/kernel")
                if [ -f "$file" ]; then
                    kernel_size=$(ls -lh "$file" | awk '{print $5}')
                    kernel_type=$(file "$file" 2>/dev/null | cut -d: -f2 || echo "未知")
                    echo "  📋 内核大小: $kernel_size"
                    echo "  📋 文件类型: $kernel_type"
                fi
                ;;
        esac
    else
        echo "❌ $file 不存在"
    fi
done

echo ""
echo "========================================"
echo "检查 TWRP 源码..."
echo "========================================"

if [ -d "android_bootable_recovery" ]; then
    twrp_size=$(du -sh android_bootable_recovery 2>/dev/null | cut -f1 || echo "未知")
    echo "✅ TWRP 源码目录存在 ($twrp_size)"
    
    # 检查关键目录
    key_dirs=("gui" "install" "recovery_ui" "minui")
    for dir in "${key_dirs[@]}"; do
        if [ -d "android_bootable_recovery/$dir" ]; then
            file_count=$(find "android_bootable_recovery/$dir" -type f -name "*.cpp" -o -name "*.h" -o -name "*.mk" 2>/dev/null | wc -l)
            echo "  📁 $dir: $file_count 个文件"
        else
            echo "  ⚠️  $dir: 目录不存在"
        fi
    done
    
    # 检查构建文件
    build_files=("Android.mk" "Android.bp")
    for file in "${build_files[@]}"; do
        if [ -f "android_bootable_recovery/$file" ]; then
            echo "  📄 $file: 存在"
        else
            echo "  ⚠️  $file: 不存在"
        fi
    done
else
    echo "❌ TWRP 源码目录不存在"
fi

echo ""
echo "========================================"
echo "检查辅助文档..."
echo "========================================"

doc_files=(
    "云构建指南.md"
    "GITHUB_ACTIONS_GUIDE.md"
    "使用指南.md"
    "项目分析报告.md"
    "国内镜像下载完成总结.md"
)

for file in "${doc_files[@]}"; do
    if [ -f "$file" ]; then
        file_size=$(wc -l < "$file")
        echo "✅ $file ($file_size 行)"
    else
        echo "⚠️  $file: 不存在"
    fi
done

echo ""
echo "========================================"
echo "检查构建脚本..."
echo "========================================"

build_scripts=(
    "test_cloud_build.sh"
    "run_build_test.sh"
    "build_twrp_final.sh"
    "check_download_status.sh"
    "fast_twrp_download.sh"
)

for script in "${build_scripts[@]}"; do
    if [ -f "$script" ]; then
        if [ -x "$script" ]; then
            echo "✅ $script: 可执行"
        else
            echo "⚠️  $script: 不可执行 (使用 chmod +x $script 修复)"
        fi
    else
        echo "❌ $script: 不存在"
    fi
done

echo ""
echo "========================================"
echo "验证总结"
echo "========================================"

# 统计结果
total_checks=0
passed_checks=0
warnings=0
errors=0

# 计算统计
check_files() {
    local pattern="$1"
    local type="$2"
    
    for file in $pattern; do
        ((total_checks++))
        if [ -e "$file" ]; then
            ((passed_checks++))
        else
            if [ "$type" = "error" ]; then
                ((errors++))
            else
                ((warnings++))
            fi
        fi
    done
}

# 检查必需文件
check_files ".github/workflows/*.yml" "error"
check_files "device/xiaomi/dagu/*.mk" "error"
check_files "device/xiaomi/dagu/recovery.fstab" "error"
check_files "device/xiaomi/dagu/prebuilt/kernel" "error"

# 检查重要文件
check_files "android_bootable_recovery" "warning"
check_files "云构建指南.md" "warning"
check_files "GITHUB_ACTIONS_GUIDE.md" "warning"

echo ""
echo "📊 验证结果:"
echo "  总计检查: $total_checks"
echo "  通过: $passed_checks"
echo "  警告: $warnings"
echo "  错误: $errors"

echo ""
echo "========================================"
echo "下一步操作建议"
echo "========================================"

if [ $errors -eq 0 ]; then
    echo "✅ 所有必需文件都存在！可以开始云构建。"
    echo ""
    echo "下一步:"
    echo "1. 推送代码到 GitHub:"
    echo "   git add ."
    echo "   git commit -m '准备云构建配置'"
    echo "   git push origin main"
    echo ""
    echo "2. 访问 GitHub 仓库页面"
    echo "3. 点击 'Actions' 标签"
    echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
    echo "5. 点击 'Run workflow'"
    echo "6. 配置参数并开始构建"
else
    echo "⚠️  存在 $errors 个错误需要修复"
    echo ""
    echo "需要修复的问题:"
    
    # 列出缺失的必需文件
    for file in .github/workflows/*.yml; do
        if [ ! -e "$file" ]; then
            echo "  - 创建 $file"
        fi
    done
    
    for file in device/xiaomi/dagu/*.mk device/xiaomi/dagu/recovery.fstab device/xiaomi/dagu/prebuilt/kernel; do
        if [ ! -e "$file" ]; then
            echo "  - 创建 $file"
        fi
    done
    
    echo ""
    echo "修复后重新运行此验证脚本。"
fi

if [ $warnings -gt 0 ]; then
    echo ""
    echo "📝 警告 (非致命):"
    echo "  - TWRP 源码和文档文件是可选的，但建议保留"
    echo "  - 确保所有构建脚本都有执行权限"
fi

echo ""
echo "========================================"
echo "GitHub Actions 配置验证完成"
echo "========================================"
echo ""
echo "更多信息请查看:"
echo "  - 云构建指南.md (详细的使用说明)"
echo "  - GITHUB_ACTIONS_GUIDE.md (技术文档)"
echo "  - 使用指南.md (用户指南)"
echo ""
echo "祝您构建成功！🚀"