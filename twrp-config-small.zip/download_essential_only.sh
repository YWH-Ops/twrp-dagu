#!/bin/bash

# 只下载必要的 TWRP 构建组件
# 不下载完整的 Android 源码

set -e

echo "========================================"
echo "    TWRP 必要组件下载"
echo "========================================"
echo "只下载构建 TWRP 所需的最小组件集"
echo "大小: 约 2-3GB"
echo "时间: 10-30分钟"
echo "========================================"
echo ""

SOURCE_DIR="$HOME/twrp-essential"
echo "创建目录: $SOURCE_DIR"
mkdir -p "$SOURCE_DIR"
cd "$SOURCE_DIR"

echo "当前目录: $(pwd)"
echo ""

# 1. 下载构建系统
echo "1. 下载构建系统 (build/make)..."
mkdir -p build
if [ ! -d "build/make" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_build build/make
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 2. 下载系统核心
echo "2. 下载系统核心 (system/core)..."
mkdir -p system
if [ ! -d "system/core" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_system_core system/core
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 3. 下载硬件接口
echo "3. 下载硬件接口 (hardware/interfaces)..."
mkdir -p hardware
if [ ! -d "hardware/interfaces" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_hardware_interfaces hardware/interfaces
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 4. 下载框架
echo "4. 下载框架 (frameworks/base)..."
mkdir -p frameworks
if [ ! -d "frameworks/base" ]; then
    git clone --depth=1 https://github.com/TeamWin/android_frameworks_base frameworks/base
    echo "✓ 下载完成"
else
    echo "✓ 已存在"
fi
echo ""

# 5. 下载外部库
echo "5. 下载必要的外部库..."
mkdir -p external
EXTERNAL_REPOS=(
    "https://github.com/TeamWin/android_external_selinux"
    "https://github.com/TeamWin/android_external_libpng"
    "https://github.com/TeamWin/android_external_libjpeg-turbo"
    "https://github.com/TeamWin/android_external_freetype"
    "https://github.com/TeamWin/android_external_zlib"
)

for repo in "${EXTERNAL_REPOS[@]}"; do
    repo_name=$(basename "$repo")
    dir_name="external/${repo_name#android_external_}"
    
    if [ ! -d "$dir_name" ]; then
        echo "下载: $repo_name"
        git clone --depth=1 "$repo" "$dir_name" 2>/dev/null && echo "  ✓ 完成" || echo "  ⚠ 失败"
    else
        echo "已存在: $dir_name"
    fi
done
echo ""

# 6. 复制设备树
echo "6. 复制设备树..."
if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
    mkdir -p device/xiaomi
    cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
    echo "✓ 设备树复制完成: device/xiaomi/dagu"
else
    echo "⚠ 警告: 找不到设备树"
fi
echo ""

# 7. 链接 TWRP 源码
echo "7. 链接 TWRP 源码..."
if [ -d "/mnt/e/twrp/android_bootable_recovery" ]; then
    mkdir -p bootable
    if [ ! -L "bootable/recovery" ]; then
        ln -sf /mnt/e/twrp/android_bootable_recovery bootable/recovery
        echo "✓ 创建符号链接: bootable/recovery"
    else
        echo "✓ 符号链接已存在"
    fi
else
    echo "⚠ 警告: 找不到 TWRP 源码"
fi
echo ""

# 8. 创建构建环境
echo "8. 创建构建环境..."
mkdir -p out/target/product/dagu

cat > build/envsetup.sh << 'EOF'
#!/bin/bash

# 简化构建环境

export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export TARGET_BUILD_TYPE=release

# TWRP 特定变量
export RECOVERY_VARIANT=twrp
export TW_THEME=portrait_hdpi
export TW_DEVICE_VERSION=1.0

function lunch() {
    echo "========================================"
    echo "  设备: twrp_dagu-eng"
    echo "  构建目录: $ANDROID_BUILD_TOP"
    echo "========================================"
    
    # 检查设备树
    if [ ! -d "device/xiaomi/dagu" ]; then
        echo "错误: 设备树未找到"
        return 1
    fi
    
    # 检查内核
    if [ ! -f "device/xiaomi/dagu/prebuilt/kernel" ]; then
        echo "错误: 内核文件未找到"
        return 1
    fi
    
    echo "✓ 设备配置检查通过"
    return 0
}

function mka() {
    echo "使用 make 构建: $@"
    make -j$(nproc) "$@"
}

echo "TWRP 构建环境已设置"
echo "运行: lunch twrp_dagu-eng"
echo "运行: mka recoveryimage"
EOF

chmod +x build/envsetup.sh
echo "✓ 构建环境创建完成"
echo ""

# 9. 创建构建脚本
echo "9. 创建构建脚本..."

cat > build_twrp_essential.sh << 'EOF'
#!/bin/bash

# TWRP 构建脚本（必要组件版）

set -e

echo "========================================"
echo "  TWRP 构建 - 必要组件版"
echo "========================================"
echo "注意: 这是一个简化的构建环境"
echo "可能缺少某些依赖，构建可能失败"
echo ""

# 设置环境
source build/envsetup.sh
lunch twrp_dagu-eng

echo ""
echo "检查构建环境..."
echo "ANDROID_BUILD_TOP: $ANDROID_BUILD_TOP"
echo "OUT_DIR: $OUT_DIR"
echo "TARGET_PRODUCT: $TARGET_PRODUCT"
echo ""

echo "检查设备树..."
if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
    echo "✓ BoardConfig.mk 存在"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -10
else
    echo "✗ BoardConfig.mk 不存在"
    exit 1
fi
echo ""

echo "检查内核文件..."
KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在: $(ls -lh "$KERNEL_FILE")"
    echo "  文件类型: $(file "$KERNEL_FILE")"
else
    echo "✗ 内核文件不存在"
    exit 1
fi
echo ""

echo "检查 TWRP 源码..."
if [ -L "bootable/recovery" ] || [ -d "bootable/recovery" ]; then
    echo "✓ TWRP 源码存在"
    if [ -L "bootable/recovery" ]; then
        echo "  类型: 符号链接 -> $(readlink bootable/recovery)"
    fi
else
    echo "✗ TWRP 源码不存在"
    exit 1
fi
echo ""

echo "尝试构建..."
echo "当前目录: $(pwd)"
echo "开始时间: $(date)"
echo ""
echo "注意: 由于缺少完整 Android 源码，"
echo "实际构建可能需要完整源码树。"
echo ""
echo "下一步操作建议:"
echo "1. 下载完整的 TWRP 源码树"
echo "2. 或使用预构建的 TWRP 镜像"
echo "3. 从其他设备移植 TWRP"
echo ""
echo "构建测试完成!"
EOF

chmod +x build_twrp_essential.sh
echo "✓ 构建脚本创建完成"
echo ""

echo "========================================"
echo "     必要组件下载完成!"
echo "========================================"
echo "目录: $SOURCE_DIR"
echo "大小: $(du -sh . 2>/dev/null | cut -f1 || echo '计算中...')"
echo ""
echo "已下载的组件:"
echo "  ✓ build/make - 构建系统"
echo "  ✓ system/core - 系统核心"
echo "  ✓ hardware/interfaces - 硬件接口"
echo "  ✓ frameworks/base - 框架"
echo "  ✓ external/* - 外部库"
echo "  ✓ device/xiaomi/dagu - 设备树"
echo "  ✓ bootable/recovery - TWRP 源码链接"
echo ""
echo "运行构建测试:"
echo "  cd $SOURCE_DIR"
echo "  ./build_twrp_essential.sh"
echo ""
echo "注意: 这是一个最小化环境，"
echo "完整构建需要下载所有 Android 源码。"