#!/bin/bash

# 简化版 TWRP 源码下载脚本

set -e

echo "========================================"
echo "  TWRP 源码下载 - 简化版"
echo "========================================"
echo ""

# 配置
SOURCE_DIR="$HOME/twrp-build"
MANIFEST_URL="https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git"
MANIFEST_BRANCH="twrp-12.1"

echo "1. 创建源码目录..."
if [ -d "$SOURCE_DIR" ]; then
    echo "目录已存在: $SOURCE_DIR"
    read -p "删除并重新下载? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "删除旧目录..."
        rm -rf "$SOURCE_DIR"
        mkdir -p "$SOURCE_DIR"
    fi
else
    mkdir -p "$SOURCE_DIR"
fi

cd "$SOURCE_DIR"
echo "当前目录: $(pwd)"
echo ""

# 检查 repo 工具
if ! command -v repo &> /dev/null; then
    echo "2. 安装 repo 工具..."
    mkdir -p ~/bin
    curl https://storage.googleapis.com/git-repo-downloads/repo > ~/bin/repo
    chmod a+x ~/bin/repo
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
    source ~/.bashrc
    echo "✓ repo 工具安装完成"
else
    echo "2. repo 工具已安装"
fi
echo ""

# 初始化 repo
echo "3. 初始化 repo..."
if [ ! -d ".repo" ]; then
    repo init -u "$MANIFEST_URL" -b "$MANIFEST_BRANCH" --depth=1
    echo "✓ repo 初始化完成"
else
    echo "repo 已初始化，跳过"
fi
echo ""

# 同步源码（有限深度以节省时间）
echo "4. 同步源码（深度1，较快）..."
echo "这可能需要一些时间，请耐心等待..."
repo sync -c -j4 --no-tags --no-clone-bundle --optimized-fetch --force-sync --depth=1
echo "✓ 源码同步完成"
echo ""

# 复制设备树
echo "5. 复制设备树..."
DEVICE_TREE_SOURCE="/mnt/e/twrp/device/xiaomi/dagu"
DEVICE_TREE_DEST="$SOURCE_DIR/device/xiaomi/dagu"

if [ -d "$DEVICE_TREE_SOURCE" ]; then
    echo "复制设备树..."
    mkdir -p "$(dirname "$DEVICE_TREE_DEST")"
    cp -r "$DEVICE_TREE_SOURCE" "$DEVICE_TREE_DEST"
    echo "✓ 设备树复制完成"
else
    echo "警告: 设备树源目录不存在: $DEVICE_TREE_SOURCE"
fi
echo ""

# 验证
echo "6. 验证..."
echo "源码目录: $SOURCE_DIR"
echo "大小: $(du -sh $SOURCE_DIR 2>/dev/null | cut -f1 || echo '正在计算...')"
echo ""
echo "设备树文件:"
ls -la "$DEVICE_TREE_DEST/" 2>/dev/null || echo "设备树目录不存在"
echo ""

echo "========================================"
echo "  下载完成!"
echo "========================================"
echo ""
echo "下一步:"
echo "cd $SOURCE_DIR"
echo ""
echo "构建命令:"
echo "source build/envsetup.sh"
echo "lunch twrp_dagu-eng"
echo "mka recoveryimage"
echo ""
echo "或使用我创建的构建脚本:"
echo "bash /mnt/e/twrp/simple_build.sh"