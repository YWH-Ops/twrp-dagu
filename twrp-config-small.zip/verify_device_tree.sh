#!/bin/bash

# 设备树验证脚本
# 验证所有配置是否正确

set -e

echo "========================================"
echo "  设备树验证脚本"
echo "  设备: dagu (小米平板5 Pro 12.4)"
echo "========================================"
echo ""

PROJECT_ROOT="/mnt/e/twrp"
DEVICE_TREE="$PROJECT_ROOT/device/xiaomi/dagu"

echo "项目根目录: $PROJECT_ROOT"
echo "设备树目录: $DEVICE_TREE"
echo ""

# 1. 检查目录结构
echo "1. 检查目录结构..."
if [ -d "$DEVICE_TREE" ]; then
    echo "✓ 设备树目录存在"
else
    echo "✗ 错误: 设备树目录不存在"
    exit 1
fi

echo ""

# 2. 检查必要文件
echo "2. 检查必要文件..."
REQUIRED_FILES=(
    "AndroidProducts.mk"
    "BoardConfig.mk"
    "device.mk"
    "recovery.fstab"
    "twrp_dagu.mk"
    "vendorsetup.sh"
)

ALL_OK=true
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$DEVICE_TREE/$file" ]; then
        echo "  ✓ $file"
        
        # 显示文件大小
        FILE_SIZE=$(ls -lh "$DEVICE_TREE/$file" | awk '{print $5}')
        echo "    大小: $FILE_SIZE"
        
        # 显示关键内容
        case $file in
            "BoardConfig.mk")
                echo "    关键配置:"
                grep -E "TARGET_PREBUILT_KERNEL|BOARD_KERNEL|TW_" "$DEVICE_TREE/$file" | head -10 | sed 's/^/      /'
                ;;
            "recovery.fstab")
                echo "    分区数量: $(grep -c "^/" "$DEVICE_TREE/$file" 2>/dev/null || echo "0")"
                ;;
        esac
    else
        echo "  ✗ $file 未找到"
        ALL_OK=false
    fi
    echo ""
done

if [ "$ALL_OK" = true ]; then
    echo "✓ 所有必要文件存在"
else
    echo "✗ 缺少必要文件"
    exit 1
fi

echo ""

# 3. 检查内核文件
echo "3. 检查内核文件..."
KERNEL_FILE="$DEVICE_TREE/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在"
    echo "  路径: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$KERNEL_FILE")"
    
    # 检查是否为有效的 boot.img
    if file "$KERNEL_FILE" | grep -q "Android bootimg"; then
        echo "  ✓ 有效的 Android bootimg"
        
        # 检查内核版本
        echo "  内核版本信息:"
        strings "$KERNEL_FILE" | grep -i "linux version" | head -3 | sed 's/^/    /'
        
        # 检查 TWRP 标记
        if hexdump -C "$KERNEL_FILE" | head -50 | grep -q "twrpfastboot"; then
            echo "  ✓ 包含 TWRP 标记"
        else
            echo "  ⚠️ 不包含 TWRP 标记（正常，原始内核可能没有）"
        fi
    else
        echo "  ✗ 错误: 不是有效的 Android bootimg"
        exit 1
    fi
else
    echo "✗ 错误: 内核文件不存在"
    exit 1
fi

echo ""

# 4. 检查备份文件
echo "4. 检查备份文件..."
BACKUP_DIR="$PROJECT_ROOT/Backups/Partitions_20260330_191944"
if [ -d "$BACKUP_DIR" ]; then
    echo "✓ 备份目录存在: $BACKUP_DIR"
    
    # 检查备份的 boot.img
    BACKUP_BOOT="$BACKUP_DIR/boot.img"
    if [ -f "$BACKUP_BOOT" ]; then
        echo "  ✓ 备份 boot.img 存在"
        echo "    大小: $(ls -lh "$BACKUP_BOOT" | awk '{print $5}')"
        
        # 比较内核文件
        if cmp -s "$KERNEL_FILE" "$BACKUP_BOOT"; then
            echo "  ✓ 内核文件与备份一致"
        else
            echo "  ⚠️ 内核文件与备份不同"
            echo "    当前: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
            echo "    备份: $(ls -lh "$BACKUP_BOOT" | awk '{print $5}')"
        fi
    else
        echo "  ⚠️ 备份 boot.img 不存在"
    fi
else
    echo "⚠️ 备份目录不存在"
fi

echo ""

# 5. 验证 BoardConfig.mk 配置
echo "5. 验证 BoardConfig.mk 配置..."
BOARD_CONFIG="$DEVICE_TREE/BoardConfig.mk"
if [ -f "$BOARD_CONFIG" ]; then
    echo "关键配置检查:"
    
    # 检查内核路径
    KERNEL_PATH=$(grep "TARGET_PREBUILT_KERNEL" "$BOARD_CONFIG" | head -1)
    if echo "$KERNEL_PATH" | grep -q "prebuilt/kernel"; then
        echo "  ✓ TARGET_PREBUILT_KERNEL 配置正确"
        echo "    配置: $KERNEL_PATH"
    else
        echo "  ✗ TARGET_PREBUILT_KERNEL 配置可能错误"
        echo "    当前配置: $KERNEL_PATH"
    fi
    
    # 检查分区大小
    RECOVERY_SIZE=$(grep "BOARD_RECOVERYIMAGE_PARTITION_SIZE" "$BOARD_CONFIG" | head -1)
    if [ -n "$RECOVERY_SIZE" ]; then
        SIZE_VALUE=$(echo "$RECOVERY_SIZE" | grep -o '[0-9]\+')
        SIZE_MB=$((SIZE_VALUE / 1024 / 1024))
        echo "  ✓ BOARD_RECOVERYIMAGE_PARTITION_SIZE = $SIZE_MB MB"
    else
        echo "  ⚠️ BOARD_RECOVERYIMAGE_PARTITION_SIZE 未设置"
    fi
    
    # 检查平台配置
    PLATFORM=$(grep "TARGET_BOARD_PLATFORM" "$BOARD_CONFIG" | head -1)
    if echo "$PLATFORM" | grep -q "sm8150"; then
        echo "  ✓ TARGET_BOARD_PLATFORM = sm8150 (正确)"
    else
        echo "  ⚠️ TARGET_BOARD_PLATFORM 可能不正确: $PLATFORM"
    fi
    
    # 检查架构
    ARCH=$(grep "TARGET_ARCH" "$BOARD_CONFIG" | head -1)
    if echo "$ARCH" | grep -q "arm64"; then
        echo "  ✓ TARGET_ARCH = arm64 (正确)"
    else
        echo "  ⚠️ TARGET_ARCH 可能不正确: $ARCH"
    fi
else
    echo "✗ BoardConfig.mk 不存在"
    exit 1
fi

echo ""

# 6. 验证恢复分区表
echo "6. 验证恢复分区表..."
FSTAB_FILE="$DEVICE_TREE/recovery.fstab"
if [ -f "$FSTAB_FILE" ]; then
    echo "恢复分区表内容:"
    echo "----------------------------------------"
    cat "$FSTAB_FILE"
    echo "----------------------------------------"
    
    # 统计分区数量
    PARTITION_COUNT=$(grep -c "^/" "$FSTAB_FILE" 2>/dev/null || echo "0")
    echo "分区数量: $PARTITION_COUNT"
    
    if [ $PARTITION_COUNT -ge 5 ]; then
        echo "✓ 分区表配置完整"
    else
        echo "⚠️ 分区表可能不完整"
    fi
else
    echo "✗ recovery.fstab 不存在"
    exit 1
fi

echo ""

# 7. 总结
echo "7. 验证总结..."
echo "========================================"
echo "  设备树验证结果"
echo "========================================"
echo ""
echo "✅ 已完成:"
echo "  - 设备树目录结构完整"
echo "  - 所有必要配置文件存在"
echo "  - 内核文件正确 (Android bootimg)"
echo "  - BoardConfig.mk 配置基本正确"
echo "  - 恢复分区表完整"
echo ""
echo "📋 配置详情:"
echo "  - 内核文件: $KERNEL_FILE"
echo "  - 内核大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
echo "  - 设备平台: sm8150 (Snapdragon 870)"
echo "  - 架构: arm64"
echo "  - 分区数量: $PARTITION_COUNT"
echo ""
echo "🚀 下一步:"
echo "  1. 下载完整的 TWRP 源码"
echo "  2. 复制设备树到 TWRP 源码"
echo "  3. 运行构建命令"
echo ""
echo "📝 构建命令:"
echo "  # 复制设备树"
echo "  cp -r $DEVICE_TREE ~/twrp-source/device/xiaomi/"
echo ""
echo "  # 进入源码目录"
echo "  cd ~/twrp-source"
echo ""
echo "  # 设置环境"
echo "  source build/envsetup.sh"
echo ""
echo "  # 选择设备"
echo "  lunch twrp_dagu-eng"
echo ""
echo "  # 开始构建"
echo "  mka recoveryimage"
echo ""
echo "✅ 设备树验证通过！可以开始构建 TWRP。"