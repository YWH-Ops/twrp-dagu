@echo off
echo ========================================
echo TWRP 云构建 - Windows 一键设置脚本
echo ========================================
echo.

echo 步骤1: 验证配置文件...
wsl bash -c "cd /mnt/e/twrp && ./verify_github_actions.sh"
echo.

echo 步骤2: 检查 Git 状态...
wsl bash -c "cd /mnt/e/twrp && git status"
echo.

echo 步骤3: 请输入您的 GitHub 用户名:
set /p GITHUB_USERNAME=GitHub 用户名: 

if "%GITHUB_USERNAME%"=="" (
    echo 错误: GitHub 用户名不能为空
    pause
    exit /b 1
)

echo.
echo GitHub 用户名: %GITHUB_USERNAME%
echo.

echo 步骤4: 配置 Git...
wsl bash -c "cd /mnt/e/twrp && git config --global user.name '%GITHUB_USERNAME%' && git config --global user.email '%GITHUB_USERNAME%@users.noreply.github.com'"
echo.

echo 步骤5: 初始化 Git 仓库...
wsl bash -c "cd /mnt/e/twrp && if [ ! -d .git ]; then git init; fi"
echo.

echo 步骤6: 添加所有文件...
wsl bash -c "cd /mnt/e/twrp && git add ."
echo.

echo 步骤7: 提交更改...
wsl bash -c "cd /mnt/e/twrp && git commit -m '添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南'"
echo.

echo 步骤8: 请在浏览器中创建 GitHub 仓库...
echo.
echo 请打开浏览器访问: https://github.com/new
echo.
echo 填写以下信息:
echo   仓库名称: twrp-dagu
echo   描述: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)
echo   可见性: Public (公开)
echo   不要勾选: Initialize this repository with a README
echo   不要添加 .gitignore 或 license
echo.
echo 创建完成后按任意键继续...
pause >nul
echo.

echo 步骤9: 添加远程仓库...
wsl bash -c "cd /mnt/e/twrp && git remote remove origin 2>/dev/null || true && git remote add origin https://github.com/%GITHUB_USERNAME%/twrp-dagu.git"
echo.

echo 步骤10: 推送代码到 GitHub...
echo 正在推送到: https://github.com/%GITHUB_USERNAME%/twrp-dagu.git
echo 这可能需要一些时间...
echo.
wsl bash -c "cd /mnt/e/twrp && git branch -M main && git push -u origin main"
echo.

if errorlevel 0 (
    echo ✅ 代码推送成功！
    echo.
    
    echo 步骤11: 创建 README.md...
    wsl bash -c "cd /mnt/e/twrp && cat > README.md << 'EOF'
# TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)

[![GitHub Actions Status](https://github.com/%GITHUB_USERNAME%/twrp-dagu/workflows/Cloud%20TWRP%20Builder/badge.svg)](https://github.com/%GITHUB_USERNAME%/twrp-dagu/actions)

使用 GitHub Actions 自动构建的 TWRP 恢复镜像。

## 快速开始

1. 从 Releases 页面下载 recovery.img
2. 进入 Fastboot 模式: adb reboot bootloader
3. 刷入恢复: fastboot flash recovery recovery.img
4. 重启到恢复: fastboot boot recovery.img

## 构建

在 GitHub Actions 中运行 Cloud TWRP Builder 工作流。

## 文档

- [云构建指南](云构建指南.md)
- [GitHub Actions 指南](GITHUB_ACTIONS_GUIDE.md)
- [快速开始](云构建快速开始.md)

## 许可证

MIT License
EOF"
    wsl bash -c "cd /mnt/e/twrp && git add README.md && git commit -m '添加 README.md' && git push origin main"
    echo.
    
    echo 步骤12: 保存配置信息...
    echo GitHub 用户名: %GITHUB_USERNAME% > github_info.txt
    echo 仓库名称: twrp-dagu >> github_info.txt
    echo 仓库地址: https://github.com/%GITHUB_USERNAME%/twrp-dagu >> github_info.txt
    echo Actions: https://github.com/%GITHUB_USERNAME%/twrp-dagu/actions >> github_info.txt
    echo 设置时间: %date% %time% >> github_info.txt
    echo.
    
    echo ========================================
    echo 🎉 GitHub 仓库设置完成！
    echo ========================================
    echo.
    echo ✅ 代码已推送到: https://github.com/%GITHUB_USERNAME%/twrp-dagu
    echo ✅ GitHub Actions 已配置
    echo ✅ README.md 已添加
    echo.
    echo ========================================
    echo 立即开始构建 TWRP:
    echo ========================================
    echo.
    echo 1. 访问 GitHub 仓库:
    echo    https://github.com/%GITHUB_USERNAME%/twrp-dagu
    echo.
    echo 2. 点击顶部 'Actions' 标签
    echo.
    echo 3. 点击 'I understand my workflows, go ahead and enable them'
    echo.
    echo 4. 选择 'Cloud TWRP Builder with China Mirror'
    echo.
    echo 5. 点击 'Run workflow'
    echo.
    echo 6. 配置参数:
    echo    - use_china_mirror: true
    echo    - build_type: minimal
    echo    - upload_artifact: true
    echo.
    echo 7. 点击 'Run workflow' 开始构建
    echo.
    echo 8. 等待构建完成 (约1-2小时)
    echo.
    echo 9. 下载 recovery.img 并测试刷机
    echo.
    echo ========================================
    echo 配置信息已保存到: github_info.txt
    echo ========================================
) else (
    echo ❌ 推送失败！
    echo.
    echo 可能的原因:
    echo 1. GitHub 仓库未创建
    echo 2. 网络连接问题
    echo 3. 权限问题
    echo.
    echo 请手动创建仓库后重试:
    echo 访问: https://github.com/new
    echo.
    echo 或者运行手动设置:
    echo wsl bash -c \"cd /mnt/e/twrp && ./setup_github_repo.sh\"
)

echo.
pause