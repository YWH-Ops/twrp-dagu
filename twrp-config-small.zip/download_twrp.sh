#!/bin/bash

# TWRP 源码下载脚本
# 用于下载 TWRP 源码到 WSL 环境中

set -e

echo "================================================"
echo "     TWRP 源码下载脚本"
echo "================================================"
echo ""

# 配置
TWERP_SOURCE_DIR="$HOME/twrp-build"
MANIFEST_URL="https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git"
MANIFEST_BRANCH="twrp-12.1"

# 检查 WSL 环境
echo "1. 检查 WSL 环境..."
if ! grep -q Microsoft /proc/version 2>/dev/null; then
    echo "警告: 不在 WSL 环境中运行"
    read -p "继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "✓ WSL 环境检测完成"
echo ""

# 检查磁盘空间
echo "2. 检查磁盘空间..."
DISK_SPACE=$(df -h /home | awk 'NR==2 {print $4}')
echo "可用空间: $DISK_SPACE"
echo "建议: 至少 100GB 可用空间"
echo ""

# 检查必要工具
echo "3. 检查必要工具..."
MISSING_TOOLS=()

check_tool() {
    if ! command -v $1 &> /dev/null; then
        MISSING_TOOLS+=($1)
        echo "  ✗ $1"
    else
        echo "  ✓ $1"
    fi
}

echo "检查工具:"
check_tool git
check_tool curl
check_tool python3
check_tool repo

if [ ${#MISSING_TOOLS[@]} -ne 0 ]; then
    echo ""
    echo "安装缺少的工具:"
    echo "  sudo apt update && sudo apt install -y ${MISSING_TOOLS[@]}"
    
    read -p "自动安装? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo apt update
        sudo apt install -y ${MISSING_TOOLS[@]}
    else
        echo "请手动安装缺少的工具后重试"
        exit 1
    fi
fi

echo ""
echo "✓ 所有必要工具已安装"
echo ""

# 创建源码目录
echo "4. 创建源码目录..."
if [ -d "$TWERP_SOURCE_DIR" ]; then
    echo "源码目录已存在: $TWERP_SOURCE_DIR"
    echo "选项:"
    echo "  1) 继续使用现有目录"
    echo "  2) 删除并重新下载"
    echo "  3) 退出"
    
    read -p "选择 (1/2/3): " -n 1 -r
    echo
    case $REPLY in
        2)
            echo "删除现有目录..."
            rm -rf "$TWERP_SOURCE_DIR"
            mkdir -p "$TWERP_SOURCE_DIR"
            ;;
        3)
            echo "退出"
            exit 0
            ;;
        *)
            echo "继续使用现有目录"
            ;;
    esac
else
    echo "创建源码目录: $TWERP_SOURCE_DIR"
    mkdir -p "$TWERP_SOURCE_DIR"
fi

cd "$TWERP_SOURCE_DIR"
echo "当前目录: $(pwd)"
echo ""

# 初始化 repo
echo "5. 初始化 TWRP 源码..."
if [ ! -d ".repo" ]; then
    echo "初始化 repo..."
    repo init -u "$MANIFEST_URL" -b "$MANIFEST_BRANCH"
    if [ $? -ne 0 ]; then
        echo "错误: repo 初始化失败"
        exit 1
    fi
    echo "✓ repo 初始化完成"
else
    echo "repo 已初始化"
fi

echo ""

# 同步源码
echo "6. 同步源码..."
echo "这将下载约 20GB 数据，可能需要较长时间..."
echo "建议使用稳定的网络连接"
echo ""

read -p "开始同步? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "取消同步"
    exit 0
fi

echo "开始同步源码..."
repo sync -c -j$(nproc) --no-tags --no-clone-bundle --optimized-fetch --force-sync
SYNC_RESULT=$?

if [ $SYNC_RESULT -eq 0 ]; then
    echo "✓ 源码同步完成"
else
    echo "✗ 源码同步失败，错误码: $SYNC_RESULT"
    echo "可以稍后重试: repo sync -c -j$(nproc)"
    exit 1
fi

echo ""

# 复制设备树
echo "7. 复制设备树..."
DEVICE_TREE_SOURCE="/mnt/e/twrp/device/xiaomi/dagu"
DEVICE_TREE_DEST="$TWERP_SOURCE_DIR/device/xiaomi/dagu"

if [ -d "$DEVICE_TREE_SOURCE" ]; then
    echo "找到设备树: $DEVICE_TREE_SOURCE"
    
    if [ -d "$DEVICE_TREE_DEST" ]; then
        echo "目标设备树已存在，备份..."
        BACKUP_DIR="$DEVICE_TREE_DEST.backup.$(date +%Y%m%d_%H%M%S)"
        mv "$DEVICE_TREE_DEST" "$BACKUP_DIR"
        echo "备份到: $BACKUP_DIR"
    fi
    
    echo "复制设备树..."
    mkdir -p "$(dirname "$DEVICE_TREE_DEST")"
    cp -r "$DEVICE_TREE_SOURCE" "$DEVICE_TREE_DEST"
    
    # 验证复制
    if [ -d "$DEVICE_TREE_DEST" ]; then
        echo "✓ 设备树复制完成"
        echo "  源: $DEVICE_TREE_SOURCE"
        echo "  目标: $DEVICE_TREE_DEST"
    else
        echo "✗ 设备树复制失败"
        exit 1
    fi
else
    echo "警告: 未找到设备树源目录"
    echo "请确保设备树在正确位置: $DEVICE_TREE_SOURCE"
fi

echo ""

# 验证设备树
echo "8. 验证设备树..."
REQUIRED_FILES=(
    "AndroidProducts.mk"
    "BoardConfig.mk"
    "device.mk"
    "recovery.fstab"
    "twrp_dagu.mk"
    "vendorsetup.sh"
)

ALL_OK=true
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$DEVICE_TREE_DEST/$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ $file 未找到"
        ALL_OK=false
    fi
done

if [ "$ALL_OK" = true ]; then
    echo "✓ 设备树验证通过"
else
    echo "✗ 设备树验证失败，缺少必要文件"
    exit 1
fi

echo ""

# 创建构建脚本
echo "9. 创建构建脚本..."
BUILD_SCRIPT="$TWERP_SOURCE_DIR/build_dagu.sh"
cat > "$BUILD_SCRIPT" << 'EOF'
#!/bin/bash

# TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)

set -e

echo "================================================"
echo "     TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)"
echo "================================================"
echo ""

# 配置
DEVICE="dagu"
TARGET="twrp_${DEVICE}"
BUILD_VARIANT="eng"
SOURCE_DIR="$(pwd)"
OUTPUT_DIR="$SOURCE_DIR/out/target/product/$DEVICE"

echo "设备: $DEVICE"
echo "目标: $TARGET-$BUILD_VARIANT"
echo "源码目录: $SOURCE_DIR"
echo "输出目录: $OUTPUT_DIR"
echo ""

# 检查环境
echo "1. 检查构建环境..."
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 不在 TWRP 源码目录"
    echo "请先运行 download_twrp.sh 下载源码"
    exit 1
fi

echo "✓ 在 TWRP 源码目录"
echo ""

# 检查设备树
echo "2. 检查设备树..."
DEVICE_TREE="device/xiaomi/$DEVICE"
if [ ! -d "$DEVICE_TREE" ]; then
    echo "错误: 设备树目录不存在: $DEVICE_TREE"
    exit 1
fi

echo "✓ 设备树存在: $DEVICE_TREE"
echo ""

# 初始化环境
echo "3. 初始化构建环境..."
source build/envsetup.sh
echo "✓ 环境已初始化"
echo ""

# 选择设备
echo "4. 选择设备..."
lunch $TARGET-$BUILD_VARIANT
echo "✓ 设备已选择: $TARGET-$BUILD_VARIANT"
echo ""

# 检查内核文件
echo "5. 检查内核文件..."
KERNEL_FILE="$DEVICE_TREE/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$KERNEL_FILE" | cut -d: -f2-)"
else
    echo "✗ 内核文件不存在: $KERNEL_FILE"
    echo "请确保已正确复制设备树"
    exit 1
fi
echo ""

# 开始构建
echo "6. 开始构建 recovery..."
echo "这可能需要一些时间..."
echo "开始时间: $(date)"
echo ""

# 构建 recovery
mka recoveryimage

echo "构建完成时间: $(date)"
echo ""

# 检查输出
echo "7. 检查构建结果..."
if [ -f "$OUTPUT_DIR/recovery.img" ]; then
    echo "✓ TWRP 构建成功!"
    echo ""
    echo "恢复镜像信息:"
    echo "  位置: $OUTPUT_DIR/recovery.img"
    echo "  大小: $(ls -lh "$OUTPUT_DIR/recovery.img" | awk '{print $5}')"
    echo "  类型: $(file "$OUTPUT_DIR/recovery.img")"
    echo ""
    
    # 复制到 Windows 目录
    WINDOWS_OUTPUT="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_OUTPUT"
    cp "$OUTPUT_DIR/recovery.img" "$WINDOWS_OUTPUT/"
    echo "复制到 Windows: $WINDOWS_OUTPUT/recovery.img"
    
    # 创建刷机包
    echo ""
    echo "8. 创建刷机包..."
    PACKAGE_NAME="twrp-3.7.0-$(date +%Y%m%d)-$DEVICE.zip"
    cd "$WINDOWS_OUTPUT"
    zip -r "$PACKAGE_NAME" recovery.img > /dev/null
    echo "刷机包: $PACKAGE_NAME"
    echo "大小: $(ls -lh "$PACKAGE_NAME" | awk '{print $5}')"
    
    echo ""
    echo "================================================"
    echo "     构建完成!"
    echo "================================================"
    echo ""
    echo "下一步操作:"
    echo "1. 测试 recovery.img:"
    echo "   fastboot boot $WINDOWS_OUTPUT/recovery.img"
    echo ""
    echo "2. 刷入设备:"
    echo "   fastboot flash recovery $WINDOWS_OUTPUT/recovery.img"
    echo "   fastboot reboot recovery"
    echo ""
    echo "3. 使用刷机包:"
    echo "   复制 $WINDOWS_OUTPUT/$PACKAGE_NAME 到设备存储"
    echo "   在恢复模式中刷入"
else
    echo "✗ TWRP 构建失败"
    echo "检查构建日志:"
    echo "  tail -f $OUTPUT_DIR/build.log"
    exit 1
fi
EOF

chmod +x "$BUILD_SCRIPT"
echo "✓ 构建脚本已创建: $BUILD_SCRIPT"
echo ""

# 创建快速启动脚本
echo "10. 创建快速启动脚本..."
QUICK_SCRIPT="$TWERP_SOURCE_DIR/start_build.sh"
cat > "$QUICK_SCRIPT" << 'EOF'
#!/bin/bash

# 快速启动构建脚本

cd "$(dirname "$0")"
echo "当前目录: $(pwd)"

if [ -f "build_dagu.sh" ]; then
    bash build_dagu.sh
else
    echo "错误: 构建脚本不存在"
    echo "请确保在 TWRP 源码目录运行"
    exit 1
fi
EOF

chmod +x "$QUICK_SCRIPT"
echo "✓ 快速启动脚本已创建: $QUICK_SCRIPT"
echo ""

# 完成
echo "================================================"
echo "     TWRP 源码下载完成!"
echo "================================================"
echo ""
echo "源码位置: $TWERP_SOURCE_DIR"
echo "大小: $(du -sh $TWERP_SOURCE_DIR 2>/dev/null | cut -f1) 或等待同步完成"
echo ""
echo "下一步:"
echo "1. 进入源码目录:"
echo "   cd $TWERP_SOURCE_DIR"
echo ""
echo "2. 开始构建:"
echo "   bash build_dagu.sh"
echo ""
echo "或使用快速启动:"
echo "   bash start_build.sh"
echo ""
echo "注意:"
echo "- 首次构建需要较长时间（1-2小时）"
echo "- 确保有足够的磁盘空间（>100GB）"
echo "- 保持网络连接稳定"
echo "- 构建过程中不要中断"
echo ""
echo "构建成功后，恢复镜像将复制到:"
echo "  /mnt/e/twrp/output/recovery.img"
echo ""