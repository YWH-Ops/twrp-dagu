#!/bin/bash

# TWRP 云构建 - GitHub 仓库设置脚本

echo "========================================"
echo "TWRP 云构建 - GitHub 仓库设置"
echo "========================================"
echo ""

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${BLUE}>>>${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

# 步骤1: 获取 GitHub 用户名
print_step "步骤1: 输入您的 GitHub 用户名"
echo ""
echo "请输入您的 GitHub 用户名 (例如: zhangsan):"
read -p "GitHub 用户名: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    print_error "GitHub 用户名不能为空"
    exit 1
fi

echo ""
print_success "GitHub 用户名: $GITHUB_USERNAME"

# 步骤2: 配置仓库信息
REPO_NAME="twrp-dagu"
BRANCH="main"
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo ""
print_step "步骤2: 配置 Git"
echo "  仓库名称: $REPO_NAME"
echo "  分支: $BRANCH"
echo "  远程地址: $REMOTE_URL"
echo ""

# 配置 Git 用户信息
git config --global user.name "$GITHUB_USERNAME"
git config --global user.email "$GITHUB_USERNAME@users.noreply.github.com"
print_success "Git 用户信息已设置"

# 步骤3: 初始化 Git 仓库
print_step "步骤3: 初始化 Git 仓库"

if [ ! -d ".git" ]; then
    git init
    print_success "Git 仓库初始化完成"
else
    print_warning "Git 仓库已存在，跳过初始化"
fi

# 步骤4: 添加文件
print_step "步骤4: 添加文件到 Git"

# 先检查有哪些重要文件
print_step "检查重要文件..."
IMPORTANT_FILES=(
    ".github/workflows/cloud-build.yml"
    ".github/workflows/quick-build.yml"
    ".github/workflows/build-twrp.yml"
    "device/xiaomi/dagu/BoardConfig.mk"
    "device/xiaomi/dagu/twrp_dagu.mk"
    "device/xiaomi/dagu/recovery.fstab"
    "device/xiaomi/dagu/prebuilt/kernel"
    "云构建指南.md"
    "GITHUB_ACTIONS_GUIDE.md"
    "云构建快速开始.md"
)

missing_files=0
for file in "${IMPORTANT_FILES[@]}"; do
    if [ -f "$file" ] || [ -d "$file" ]; then
        print_success "找到: $file"
    else
        print_error "缺失: $file"
        ((missing_files++))
    fi
done

if [ $missing_files -gt 0 ]; then
    print_warning "有 $missing_files 个重要文件缺失，但继续..."
fi

# 添加所有文件（忽略一些大文件）
print_step "添加文件到暂存区..."
git add --all
print_success "文件已添加到暂存区"

# 步骤5: 提交更改
print_step "步骤5: 提交更改"

COMMIT_MESSAGE="添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南"

git commit -m "$COMMIT_MESSAGE"
if [ $? -eq 0 ]; then
    print_success "提交完成"
    echo ""
    echo "提交信息:"
    echo "---"
    echo "$COMMIT_MESSAGE" | head -10
    echo "..."
    echo "---"
else
    print_error "提交失败"
    echo "尝试强制提交..."
    git commit -m "$COMMIT_MESSAGE" --allow-empty
    if [ $? -eq 0 ]; then
        print_success "强制提交完成"
    else
        print_error "提交失败，请检查错误信息"
        exit 1
    fi
fi

# 步骤6: 检查 GitHub 仓库
print_step "步骤6: 检查 GitHub 仓库"
echo ""
echo "请先在 GitHub 上创建仓库:"
echo ""
echo "1. 打开浏览器访问: https://github.com/new"
echo ""
echo "2. 填写以下信息:"
echo "   - Repository name: $REPO_NAME"
echo "   - Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
echo "   - Public (公开)"
echo "   - 不要勾选: Initialize this repository with a README"
echo "   - 不要添加 .gitignore 或 license"
echo ""
echo "3. 点击 'Create repository'"
echo ""
read -p "创建完成后按 Enter 键继续..."

# 步骤7: 添加远程仓库并推送
print_step "步骤7: 配置远程仓库并推送"

# 移除现有的 origin（如果有）
if git remote | grep -q origin; then
    print_warning "已存在远程仓库 origin，重新设置..."
    git remote remove origin
fi

# 添加新的远程仓库
git remote add origin "$REMOTE_URL"
print_success "远程仓库已添加: $REMOTE_URL"

# 重命名分支
CURRENT_BRANCH=$(git branch --show-current 2>/dev/null || echo "master")
if [ "$CURRENT_BRANCH" != "$BRANCH" ]; then
    print_step "重命名分支: $CURRENT_BRANCH -> $BRANCH"
    git branch -M "$BRANCH"
    print_success "分支已重命名"
fi

# 推送代码
print_step "开始推送到 GitHub..."
echo ""
echo "正在推送到: $REMOTE_URL"
echo "分支: $BRANCH"
echo ""
echo "这可能需要一些时间，请耐心等待..."
echo ""

# 尝试推送
if git push -u origin "$BRANCH"; then
    echo ""
    print_success "✅ 代码推送成功！"
    echo ""
else
    print_error "❌ 推送失败"
    echo ""
    echo "可能的原因:"
    echo "1. 仓库未创建 - 请确认已创建仓库"
    echo "2. 网络问题 - 请检查网络连接"
    echo "3. 权限问题 - 请确认有推送权限"
    echo ""
    echo "您可以手动推送:"
    echo "  git push -u origin $BRANCH"
    echo ""
    exit 1
fi

# 步骤8: 创建 README.md
print_step "步骤8: 创建 README.md"

cat > README.md << 'EOF'
# TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)

[![GitHub Actions Status](https://github.com/'"$GITHUB_USERNAME"'/twrp-dagu/workflows/Cloud%20TWRP%20Builder/badge.svg)](https://github.com/'"$GITHUB_USERNAME"'/twrp-dagu/actions)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

使用 GitHub Actions 自动构建的 TWRP 恢复镜像，专为小米平板5 Pro 12.4 (dagu) 设计。

## 📦 下载

从 [Releases](https://github.com/'"$GITHUB_USERNAME"'/twrp-dagu/releases) 页面下载最新的 `recovery.img` 文件。

## 🚀 快速开始

### 刷机步骤

1. **下载恢复镜像**: 从 Releases 页面下载最新的 `recovery.img`
2. **进入 Fastboot 模式**:
   ```bash
   adb reboot bootloader
   ```
3. **刷入恢复**:
   ```bash
   fastboot flash recovery recovery.img
   ```
4. **重启到恢复**:
   ```bash
   fastboot boot recovery.img
   ```

### 构建你自己的版本

1. **Fork 本仓库**
2. **启用 GitHub Actions**
3. **运行构建工作流**
4. **下载构建产物**

## 🔧 构建配置

### GitHub Actions 工作流

| 工作流 | 描述 | 预计时间 |
|--------|------|----------|
| [Cloud TWRP Builder](.github/workflows/cloud-build.yml) | 完整构建流程 | 1-4小时 |
| [Quick Build Test](.github/workflows/quick-build.yml) | 快速环境测试 | 15分钟 |

### 构建参数

| 参数 | 选项 | 默认值 | 说明 |
|------|------|--------|------|
| `use_china_mirror` | true/false | true | 使用国内镜像加速 |
| `build_type` | minimal/full/test | minimal | 构建类型 |
| `upload_artifact` | true/false | true | 上传构建产物 |

## 📁 项目结构

```
twrp-dagu/
├── .github/workflows/          # GitHub Actions 工作流
├── device/xiaomi/dagu/         # 设备树
├── android_bootable_recovery/  # TWRP 源码
├── scripts/                    # 构建脚本
└── docs/                       # 文档
```

## 📚 文档

- [云构建指南](云构建指南.md) - 完整的使用说明
- [GitHub Actions 指南](GITHUB_ACTIONS_GUIDE.md) - 技术文档
- [快速开始](云构建快速开始.md) - 5步快速开始
- [项目分析报告](项目分析报告.md) - 技术分析

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

### 报告问题
1. 查看 [Issues](https://github.com/'"$GITHUB_USERNAME"'/twrp-dagu/issues)
2. 搜索是否已有类似问题
3. 创建新的 Issue

### 提交改进
1. Fork 本仓库
2. 创建特性分支
3. 提交更改
4. 创建 Pull Request

## 📄 许可证

本项目基于 [MIT License](LICENSE)。

## 🙏 致谢

- TeamWin 团队 (TWRP)
- GitHub Actions 团队
- 国内镜像源维护者
- 所有贡献者和测试者

## ⚠️ 免责声明

- 刷机有风险，操作需谨慎
- 请务必备份重要数据
- 作者不对任何数据丢失负责
- 请遵守相关法律法规

---
**如果这个项目对你有帮助，请点个 Star ⭐**

_构建愉快！_
EOF

git add README.md
git commit -m "添加 README.md" -m "包含项目说明、构建状态徽章和使用指南"
print_success "README.md 已创建并提交"

# 推送 README
git push origin "$BRANCH"
print_success "README.md 已推送到 GitHub"

# 步骤9: 创建许可证文件
print_step "步骤9: 创建许可证文件"

cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2026 TWRP Builder for Xiaomi Pad 5 Pro 12.4 (dagu)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

git add LICENSE
git commit -m "添加 MIT 许可证" -m "添加开源许可证文件"
git push origin "$BRANCH"
print_success "许可证文件已添加"

# 步骤10: 完成
print_step "步骤10: 完成设置"
echo ""
echo "========================================"
print_success "🎉 GitHub 仓库设置完成！"
echo "========================================"
echo ""
echo "✅ 代码已推送到: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "✅ GitHub Actions 已配置"
echo "✅ README.md 和 LICENSE 已添加"
echo ""
echo "========================================"
echo "立即开始构建 TWRP:"
echo "========================================"
echo ""
echo "1. 访问 GitHub 仓库:"
echo "   https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "2. 点击顶部 'Actions' 标签"
echo ""
echo "3. 点击 'I understand my workflows, go ahead and enable them'"
echo ""
echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
echo ""
echo "5. 点击 'Run workflow'"
echo ""
echo "6. 配置参数:"
echo "   - use_china_mirror: true"
echo "   - build_type: minimal"
echo "   - upload_artifact: true"
echo ""
echo "7. 点击 'Run workflow' 开始构建"
echo ""
echo "8. 等待构建完成 (约1-2小时)"
echo ""
echo "9. 下载 recovery.img 并测试刷机"
echo ""
echo "========================================"
echo "重要链接:"
echo "========================================"
echo "🔗 仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "🔗 Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "🔗 Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases"
echo ""
echo "========================================"
echo "本地验证:"
echo "========================================"
echo "运行验证脚本检查配置:"
echo "  ./verify_github_actions.sh"
echo ""
echo "运行本地测试:"
echo "  ./test_cloud_build.sh"
echo ""
echo "========================================"
echo "需要帮助?"
echo "========================================"
echo "📖 查看文档:"
echo "  云构建指南.md - 完整使用说明"
echo "  GITHUB_ACTIONS_GUIDE.md - 技术文档"
echo "  云构建快速开始.md - 5步快速开始"
echo ""
echo "🐛 报告问题:"
echo "  在仓库中提交 Issue"
echo ""
echo "💬 讨论:"
echo "  查看 Issues 和 Pull Requests"
echo ""
print_success "开始您的云构建之旅吧！祝您成功！🚀"

# 保存配置信息
cat > .github_info.txt << EOF
GitHub 仓库信息
================

用户名: $GITHUB_USERNAME
仓库名: $REPO_NAME
分支: $BRANCH

仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME
Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions
Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases

设置时间: $(date)

下一步操作:
1. 访问仓库页面
2. 启用 GitHub Actions
3. 运行 Cloud TWRP Builder
4. 等待构建完成
5. 下载并测试 recovery.img

文档:
- 云构建指南.md
- GITHUB_ACTIONS_GUIDE.md  
- 云构建快速开始.md

祝您构建成功！
EOF

print_success "配置信息已保存到: .github_info.txt"
echo ""
echo "您也可以手动查看配置:"
echo "  cat .github_info.txt"