#!/bin/bash

# TWRP 云构建 - 立即开始脚本
# 这个脚本将引导您完成整个构建过程

set -e

echo "========================================"
echo "🚀 TWRP 云构建 - 立即开始"
echo "========================================"
echo ""

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${BLUE}>>>${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

# 步骤1: 验证配置
print_step "步骤1: 验证配置..."
echo ""

if [ -f "./verify_github_actions.sh" ]; then
    ./verify_github_actions.sh
    echo ""
    print_success "配置验证完成"
else
    print_error "验证脚本不存在"
    exit 1
fi

echo "按 Enter 继续..."
read

# 步骤2: 获取 GitHub 信息
print_step "步骤2: GitHub 账户配置"
echo ""

# 检查现有的 Git 配置
CURRENT_NAME=$(git config --global user.name 2>/dev/null || echo "")
CURRENT_EMAIL=$(git config --global user.email 2>/dev/null || echo "")

if [ -n "$CURRENT_NAME" ]; then
    echo "当前 Git 用户名: $CURRENT_NAME"
    echo "当前 Git 邮箱: $CURRENT_EMAIL"
    echo ""
    read -p "使用现有配置？(y/n, 默认 y): " USE_EXISTING
    USE_EXISTING=${USE_EXISTING:-y}
    
    if [[ "$USE_EXISTING" != "y" && "$USE_EXISTING" != "Y" ]]; then
        CURRENT_NAME=""
        CURRENT_EMAIL=""
    fi
fi

if [ -z "$CURRENT_NAME" ]; then
    echo "请输入您的信息用于 Git 提交:"
    read -p "您的名字 (用于 Git 提交): " GIT_NAME
    read -p "您的邮箱 (用于 Git 提交): " GIT_EMAIL
    
    if [ -z "$GIT_NAME" ] || [ -z "$GIT_EMAIL" ]; then
        print_error "姓名和邮箱不能为空"
        exit 1
    fi
    
    git config --global user.name "$GIT_NAME"
    git config --global user.email "$GIT_EMAIL"
    print_success "Git 配置已更新"
else
    echo "使用现有 Git 配置"
fi

echo ""

# 步骤3: 获取 GitHub 用户名
print_step "步骤3: GitHub 仓库设置"
echo ""

echo "请输入您的 GitHub 用户名 (例如: zhangsan):"
read -p "GitHub 用户名: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    print_error "GitHub 用户名不能为空"
    exit 1
fi

REPO_NAME="twrp-dagu"
BRANCH="main"
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo ""
echo "GitHub 配置:"
echo "  用户名: $GITHUB_USERNAME"
echo "  仓库名: $REPO_NAME"
echo "  分支: $BRANCH"
echo "  远程地址: $REMOTE_URL"
echo ""

echo "按 Enter 继续..."
read

# 步骤4: 初始化 Git 仓库
print_step "步骤4: 初始化 Git 仓库"
echo ""

if [ ! -d ".git" ]; then
    git init
    print_success "Git 仓库初始化完成"
else
    print_warning "Git 仓库已存在"
fi

echo ""

# 步骤5: 添加文件
print_step "步骤5: 添加文件到 Git"
echo ""

echo "正在添加文件..."
git add .
if [ $? -eq 0 ]; then
    print_success "文件添加完成"
else
    print_error "文件添加失败"
    exit 1
fi

echo ""

# 步骤6: 提交更改
print_step "步骤6: 提交更改"
echo ""

COMMIT_MESSAGE="添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南"

echo "提交信息:"
echo "---"
echo "$COMMIT_MESSAGE" | head -10
echo "..."
echo "---"
echo ""

git commit -m "$COMMIT_MESSAGE"
if [ $? -eq 0 ]; then
    print_success "提交完成"
else
    print_warning "提交可能失败，尝试强制提交..."
    git commit -m "$COMMIT_MESSAGE" --allow-empty
    if [ $? -eq 0 ]; then
        print_success "强制提交完成"
    else
        print_error "提交失败"
        exit 1
    fi
fi

echo ""

# 步骤7: 创建 GitHub 仓库
print_step "步骤7: 创建 GitHub 仓库"
echo ""

echo "请先在浏览器中创建 GitHub 仓库:"
echo ""
echo "1. 打开: https://github.com/new"
echo ""
echo "2. 填写以下信息:"
echo "   - Repository name: $REPO_NAME"
echo "   - Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
echo "   - Visibility: Public (公开)"
echo "   - 不要勾选: Initialize this repository with a README"
echo "   - 不要添加 .gitignore 或 license"
echo ""
echo "3. 点击 'Create repository'"
echo ""
echo "4. 创建完成后按 Enter 继续..."
read

# 步骤8: 配置远程仓库
print_step "步骤8: 配置远程仓库"
echo ""

# 移除现有的 origin（如果有）
if git remote | grep -q origin; then
    print_warning "已存在远程仓库 origin，重新设置..."
    git remote remove origin
fi

# 添加新的远程仓库
git remote add origin "$REMOTE_URL"
if [ $? -eq 0 ]; then
    print_success "远程仓库已添加: $REMOTE_URL"
else
    print_error "添加远程仓库失败"
    exit 1
fi

echo ""

# 步骤9: 重命名分支并推送
print_step "步骤9: 推送代码到 GitHub"
echo ""

CURRENT_BRANCH=$(git branch --show-current 2>/dev/null || echo "master")
if [ "$CURRENT_BRANCH" != "$BRANCH" ]; then
    git branch -M "$BRANCH"
    print_success "分支重命名为: $BRANCH"
fi

echo "正在推送到 GitHub..."
echo "仓库: $REMOTE_URL"
echo "分支: $BRANCH"
echo ""
echo "这可能需要一些时间..."
echo ""

# 尝试推送
if git push -u origin "$BRANCH"; then
    echo ""
    print_success "✅ 代码推送成功！"
else
    echo ""
    print_error "❌ 推送失败"
    echo ""
    echo "可能的原因:"
    echo "1. GitHub 仓库未创建"
    echo "2. 网络连接问题"
    echo "3. 权限问题"
    echo ""
    echo "请确保:"
    echo "1. 已创建仓库: https://github.com/new"
    echo "2. 仓库名称为: $REPO_NAME"
    echo "3. 仓库是 Public (公开)"
    echo ""
    echo "重试推送命令:"
    echo "  git push -u origin $BRANCH"
    echo ""
    exit 1
fi

echo ""

# 步骤10: 添加 README 和 LICENSE
print_step "步骤10: 完善仓库"
echo ""

echo "添加 README.md..."
cat > README.md << EOF
# TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)

[![GitHub Actions Status](https://github.com/$GITHUB_USERNAME/twrp-dagu/workflows/Cloud%20TWRP%20Builder/badge.svg)](https://github.com/$GITHUB_USERNAME/twrp-dagu/actions)

使用 GitHub Actions 自动构建的 TWRP 恢复镜像。

## 快速开始

1. 从 Releases 页面下载 recovery.img
2. 进入 Fastboot 模式: \`adb reboot bootloader\`
3. 刷入恢复: \`fastboot flash recovery recovery.img\`
4. 重启到恢复: \`fastboot boot recovery.img\`

## 构建

在 GitHub Actions 中运行 Cloud TWRP Builder 工作流。

## 文档

- [云构建指南](云构建指南.md)
- [GitHub Actions 指南](GITHUB_ACTIONS_GUIDE.md)
- [快速开始](云构建快速开始.md)

## 许可证

MIT License
EOF

git add README.md
git commit -m "添加 README.md" -m "包含项目说明和构建状态徽章"
git push origin "$BRANCH"
print_success "README.md 已添加"

echo ""

# 步骤11: 完成设置
print_step "步骤11: 完成设置"
echo ""

cat > .github_info.txt << EOF
GitHub 仓库信息
================

用户名: $GITHUB_USERNAME
仓库名: $REPO_NAME
分支: $BRANCH

仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME
Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions
Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases

设置时间: $(date)

下一步操作:
1. 访问仓库页面
2. 启用 GitHub Actions
3. 运行 Cloud TWRP Builder
4. 等待构建完成
5. 下载并测试 recovery.img

文档:
- 云构建指南.md
- GITHUB_ACTIONS_GUIDE.md  
- 云构建快速开始.md

祝您构建成功！
EOF

print_success "配置信息已保存到: .github_info.txt"

echo ""
echo "========================================"
print_success "🎉 GitHub 仓库设置完成！"
echo "========================================"
echo ""
echo "✅ 代码已推送到: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "✅ Git 配置完成"
echo "✅ 文件已提交"
echo "✅ README.md 已添加"
echo ""

# 步骤12: 启动构建指南
print_step "步骤12: 立即开始构建"
echo ""
echo "请按照以下步骤启动构建:"
echo ""
echo "1. 打开浏览器访问:"
echo "   https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "2. 点击顶部 'Actions' 标签"
echo ""
echo "3. 点击 'I understand my workflows, go ahead and enable them'"
echo ""
echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
echo ""
echo "5. 点击 'Run workflow'"
echo ""
echo "6. 配置参数:"
echo "   - use_china_mirror: true (推荐)"
echo "   - build_type: minimal (首次测试)"
echo "   - upload_artifact: true"
echo ""
echo "7. 点击 'Run workflow' 开始构建"
echo ""
echo "8. 等待构建完成 (约1-2小时)"
echo ""
echo "9. 下载 recovery.img 并测试"
echo ""
echo "========================================"
echo "重要链接"
echo "========================================"
echo "🔗 仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "🔗 Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "🔗 Releases: https://github.com/$GITHUB_USERNAME/$REPO_NAME/releases"
echo ""
echo "========================================"
echo "构建监控"
echo "========================================"
echo "构建过程中可以:"
echo "1. 查看实时日志"
echo "2. 监控各个步骤"
echo "3. 下载构建产物"
echo "4. 查看错误信息"
echo ""
echo "========================================"
echo "需要帮助?"
echo "========================================"
echo "📖 查看文档:"
echo "  cat 云构建指南.md"
echo ""
echo "🐛 报告问题:"
echo "  在仓库中提交 Issue"
echo ""
print_success "祝您构建成功！🚀"

# 保存仓库信息到文件
echo "$GITHUB_USERNAME" > github_username.txt
echo "https://github.com/$GITHUB_USERNAME/$REPO_NAME" > github_repo_url.txt
echo "https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions" > github_actions_url.txt

echo ""
echo "GitHub 信息已保存到:"
echo "  github_username.txt"
echo "  github_repo_url.txt"
echo "  github_actions_url.txt"