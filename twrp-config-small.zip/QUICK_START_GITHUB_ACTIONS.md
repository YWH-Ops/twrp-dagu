# GitHub Actions 云构建 TWRP - 快速开始指南
## 3 分钟开始构建

---

## 🚀 超简单步骤

### 第 1 步：Fork 仓库（30 秒）

1. 打开浏览器访问你的 GitHub
2. 进入这个 TWRP 仓库页面
3. 点击右上角 **⚡ Fork** 按钮
4. 等待自动跳转到你的 Fork 仓库

✅ **完成标志**: URL 变成 `https://github.com/YOUR_USERNAME/twrp`

---

### 第 2 步：进入 Actions（20 秒）

1. 在你的 Fork 仓库顶部，点击 **Actions** 标签
2. 在左侧找到 **"Cloud TWRP Builder with China Mirror"**
3. 点击进入工作流页面

✅ **完成标志**: 看到 "This workflow has a workflow_dispatch event trigger"

---

### 第 3 步：运行构建（1 分钟）

1. 点击右侧的 **Run workflow** 按钮
2. 配置选项（使用默认值即可）：

```
Branch: main
Use China Mirror: true          ← 保持默认（更快）
Build Type: minimal             ← 保持默认（更快）
Upload Build Artifacts: true    ← 保持默认
```

3. 点击绿色的 **Run workflow** 按钮

✅ **完成标志**: 看到 "In progress" 或绿色勾选标记

---

### 第 4 步：等待完成（30-60 分钟）

#### 实时监控进度

你可以随时查看构建进度：

1. 点击 **Actions** 标签
2. 点击正在运行的记录（通常在顶部）
3. 点击具体的 job 查看详细日志

#### 关键节点

| 时间 | 阶段 | 状态 |
|------|------|------|
| 0-5 分钟 | Setup Environment | 🔄 环境搭建 |
| 5-25 分钟 | Download Source | 📥 下载源码 |
| 25-50 分钟 | Build TWRP | 🔨 编译构建 |
| 50-60 分钟 | Upload Artifacts | 📤 上传产物 |

#### 接收通知

- ✅ **GitHub 邮件通知**: 构建完成后会收到邮件
- ✅ **仓库通知**: Actions 页面会显示完成状态

---

### 第 5 步：下载产物（2 分钟）

构建成功后：

1. 再次进入 **Actions** 页面
2. 点击刚才完成的运行记录（绿色勾选）
3. 滚动到页面底部
4. 在 **Artifacts** 区域找到：
   - `twrp-dagu-{数字}` ← 这是你的 recovery.img
   - `build-log-{数字}` ← 构建日志
   - `build-report-{数字}` ← 构建报告

5. 点击 `twrp-dagu-{数字}` 下载
6. 解压 ZIP 文件获得 `recovery.img`

✅ **完成!** 你现在有了可用的 TWRP 镜像！

---

## ⚡ 最快构建技巧

### 加速秘诀

1. **必须使用中国镜像**
   ```yaml
   use_china_mirror: 'true'  # 速度快 10-20 倍
   ```

2. **选择 Minimal Build**
   ```yaml
   build_type: 'minimal'     # 只下载必要组件
   ```

3. **在非高峰时段构建**
   - 推荐：凌晨或清晨（UTC+8）
   - 避免：晚上 8-10 点

4. **保持网络稳定**
   - 构建过程中不要关闭浏览器
   - 可以使用手机热点备用

---

## 📊 构建选项说明

### 三种构建类型对比

| 类型 | 时间 | 大小 | 成功率 | 推荐度 |
|------|------|------|--------|--------|
| **Minimal** | 30-60 分钟 | ~5GB | ⭐⭐⭐⭐⭐ | ✅ 强烈推荐 |
| Full | 2-4 小时 | ~50GB | ⭐⭐⭐⭐ | ⚠️ 不推荐 |
| Test | 20-40 分钟 | ~2GB | ⭐⭐⭐ | 🔧 仅调试用 |

### 镜像源对比

| 镜像源 | 下载速度 | 稳定性 | 推荐 |
|--------|---------|--------|------|
| 清华镜像 | 10-20 MB/s | ⭐⭐⭐⭐⭐ | ✅ 首选 |
| 中科大镜像 | 8-15 MB/s | ⭐⭐⭐⭐ | ✅ 备选 |
| 官方源 | 0.5-2 MB/s | ⭐⭐⭐ | ❌ 不推荐 |

---

## ⚠️ 常见问题速查

### Q1: 找不到 Actions 标签？

**解决**: 
```
Settings → Actions → General
→ 选择 "Allow all actions and reusable workflows"
→ Save
```

### Q2: 提示 "Workflow is not allowed to run"?

**解决**:
```
Settings → Actions → General
→ Workflow permissions
→ 选择 "Read and write permissions"
→ Allow GitHub Actions to create and approve pull requests
```

### Q3: 构建失败怎么办？

**步骤**:
1. 查看构建日志（点击红色的 job）
2. 搜索 "error:" 关键词
3. 如果是网络错误，重新运行即可
4. 如果是配置错误，检查设备树文件

### Q4: 多久能构建完成？

**答案**:
- Minimal: 30-60 分钟（推荐）
- Full: 2-4 小时（不推荐）
- 首次构建可能稍慢

### Q5: 可以取消构建吗？

**可以**:
```
Actions → 选择运行记录
→ 右上角 "Cancel run"
→ 确认取消
```

---

## 🎯 构建成功后的操作

### 立即验证

```bash
# 1. 检查文件大小
ls -lh recovery.img
# 应该在 64-128MB 之间

# 2. 检查文件类型
file recovery.img
# 应该显示 "Android bootimg"
```

### 测试刷入（安全）

```bash
# 进入 fastboot
adb reboot bootloader

# 临时启动（不永久写入）
fastboot boot recovery.img
```

### 永久刷入

```bash
# 进入 fastboot
adb reboot bootloader

# 刷入 recovery
fastboot flash recovery recovery.img

# 重启到 recovery
fastboot reboot recovery
```

---

## 💡 高级技巧

### 批量构建

如果你有多个设备，可以：

1. 修改 `.github/workflows/cloud-build.yml`
2. 添加其他设备支持
3. 一次构建多个设备的 TWRP

### 定时构建

可以设置每天自动构建：

```yaml
on:
  schedule:
    - cron: '0 2 * * *'  # 每天 UTC 2:00
  workflow_dispatch:
```

### 自定义镜像

可以修改设备树来定制功能：
- 调整触控灵敏度
- 修改默认语言
- 添加特殊功能

---

## 📞 需要帮助？

### 获取支持的途径

1. **查看文档**
   - `GITHUB_ACTIONS_BUILD_GUIDE.md` - 详细指南
   - `README_BUILD.md` - 构建说明
   - `TWRP_BUILD_GUIDE.md` - 完整教程

2. **社区支持**
   - XDA 论坛：Xiaomi Mi Pad 5 版块
   - Telegram：搜索 "dagu TWRP"
   - GitHub Issues：提交问题

3. **查看日志**
   - 下载 `build-log-{数字}.zip`
   - 查看最后的错误信息
   - 搜索关键词 "error" 或 "failed"

---

## ✅ 检查清单

开始构建前，确保：

- [ ] 已注册 GitHub 账号
- [ ] 已验证邮箱地址
- [ ] 已 Fork 仓库到你的账号
- [ ] 已启用 GitHub Actions
- [ ] 了解基本刷机风险
- [ ] 准备了 USB 数据线
- [ ] 设备电量 > 50%
- [ ] 已解锁 Bootloader

---

## 🎉 开始构建！

准备好了吗？

👉 **立即行动**: 

1. 打开 https://github.com
2. 进入你的 TWRP 仓库
3. 点击 **Actions** 标签
4. 点击 **Run workflow**
5. 享受构建过程！

---

**提示**: 第一次构建可能需要耐心等待，建议使用 Minimal + 中国镜像组合，通常 30-40 分钟就能完成。

**祝构建顺利！** 🚀
