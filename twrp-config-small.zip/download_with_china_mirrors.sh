#!/bin/bash

# 使用国内镜像下载 Android 源码
# 支持多个国内镜像源：清华、中科大、阿里云

set -e

echo "========================================"
echo "   使用国内镜像下载 Android 源码"
echo "========================================"
echo "镜像源选项:"
echo "  1. 清华大学 TUNA (推荐)"
echo "  2. 中科大 USTC"
echo "  3. 阿里云"
echo "  4. 华为云"
echo "========================================"
echo ""

# 选择镜像源
select_mirror() {
    echo "请选择镜像源 (输入数字 1-4):"
    echo "1) 清华大学 TUNA (tuna)"
    echo "2) 中科大 USTC (ustc)"
    echo "3) 阿里云 (aliyun)"
    echo "4) 华为云 (huawei)"
    echo ""
    read -p "您的选择 [1]: " choice
    
    case $choice in
        2)
            echo "使用中科大镜像源..."
            REPO_URL="https://gerrit-googlesource.proxy.ustclug.org/git-repo"
            AOSP_MIRROR="https://mirrors.ustc.edu.cn/git/AOSP"
            GITHUB_MIRROR="https://ghproxy.com/https://github.com"
            ;;
        3)
            echo "使用阿里云镜像源..."
            REPO_URL="https://mirrors.aliyun.com/git-repo"
            AOSP_MIRROR="https://mirrors.aliyun.com/git/AOSP"
            GITHUB_MIRROR="https://github.com"
            ;;
        4)
            echo "使用华为云镜像源..."
            REPO_URL="https://repo.huaweicloud.com/git-repo"
            AOSP_MIRROR="https://mirrors.huaweicloud.com/git/AOSP"
            GITHUB_MIRROR="https://github.com"
            ;;
        *)
            echo "使用清华大学镜像源 (默认)..."
            REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo"
            AOSP_MIRROR="https://mirrors.tuna.tsinghua.edu.cn/git/AOSP"
            GITHUB_MIRROR="https://ghproxy.com/https://github.com"
            ;;
    esac
    
    echo "镜像源配置:"
    echo "  REPO_URL: $REPO_URL"
    echo "  AOSP_MIRROR: $AOSP_MIRROR"
    echo "  GITHUB_MIRROR: $GITHUB_MIRROR"
    echo ""
}

# 检查磁盘空间
check_disk_space() {
    echo "1. 检查磁盘空间..."
    AVAILABLE_SPACE=$(df -h ~ | awk 'NR==2 {print $4}' | sed 's/G//')
    echo "可用空间: ${AVAILABLE_SPACE}G"
    
    if [ ${AVAILABLE_SPACE%.*} -lt 100 ]; then
        echo "⚠ 警告: 可用空间不足 100GB，建议清理空间"
        read -p "继续? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "下载取消"
            exit 1
        fi
    fi
    echo ""
}

# 安装必要工具
install_tools() {
    echo "2. 安装必要工具..."
    
    # 检查并安装 git
    if ! command -v git >/dev/null 2>&1; then
        echo "安装 git..."
        sudo apt update && sudo apt install -y git
    fi
    echo "✓ git 已安装: $(git --version)"
    
    # 检查并安装 curl
    if ! command -v curl >/dev/null 2>&1; then
        echo "安装 curl..."
        sudo apt install -y curl
    fi
    echo "✓ curl 已安装"
    
    # 检查并安装 python3
    if ! command -v python3 >/dev/null 2>&1; then
        echo "安装 python3..."
        sudo apt install -y python3
    fi
    echo "✓ python3 已安装: $(python3 --version)"
    
    echo ""
}

# 配置 git 镜像
setup_git_mirrors() {
    echo "3. 配置 git 镜像..."
    
    # 备份原有配置
    if [ -f ~/.gitconfig ]; then
        cp ~/.gitconfig ~/.gitconfig.backup.$(date +%Y%m%d%H%M%S)
        echo "✓ 备份原有 git 配置"
    fi
    
    # 设置镜像
    git config --global url."$AOSP_MIRROR/".insteadof https://android.googlesource.com/
    git config --global url."$AOSP_MIRROR/".insteadof http://android.googlesource.com/
    git config --global url."$AOSP_MIRROR/".insteadof git://android.googlesource.com/
    
    # 设置 GitHub 镜像（如果需要）
    if [ "$GITHUB_MIRROR" != "https://github.com" ]; then
        git config --global url."$GITHUB_MIRROR/".insteadof https://github.com/
    fi
    
    echo "✓ git 镜像配置完成"
    echo "  镜像源: $AOSP_MIRROR"
    if [ "$GITHUB_MIRROR" != "https://github.com" ]; then
        echo "  GitHub 镜像: $GITHUB_MIRROR"
    fi
    echo ""
}

# 安装和配置 repo 工具
setup_repo_tool() {
    echo "4. 安装和配置 repo 工具..."
    
    # 创建 bin 目录
    mkdir -p ~/bin
    
    # 下载 repo 工具
    echo "下载 repo 工具从: $REPO_URL"
    curl -s $REPO_URL -o ~/bin/repo
    chmod a+x ~/bin/repo
    
    # 添加到 PATH
    if ! grep -q "~/bin" ~/.bashrc; then
        echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
    fi
    export PATH="$HOME/bin:$PATH"
    
    echo "✓ repo 工具已安装: $(repo --version 2>/dev/null | head -1 || echo '版本检查失败')"
    echo ""
}

# 选择下载模式
select_download_mode() {
    echo "5. 选择下载模式:"
    echo "  1) 完整 Android 源码 + TWRP (约 20GB)"
    echo "  2) 最小化 Android 源码 (约 2GB，仅核心组件)"
    echo "  3) 仅 TWRP 相关组件 (约 1GB，最快)"
    echo ""
    read -p "您的选择 [3]: " mode_choice
    
    case $mode_choice in
        1)
            DOWNLOAD_MODE="full"
            SOURCE_DIR="$HOME/android-twrp-full"
            echo "选择: 完整 Android 源码 + TWRP"
            echo "目录: $SOURCE_DIR"
            echo "大小: 约 20GB"
            ;;
        2)
            DOWNLOAD_MODE="minimal"
            SOURCE_DIR="$HOME/android-minimal"
            echo "选择: 最小化 Android 源码"
            echo "目录: $SOURCE_DIR"
            echo "大小: 约 2GB"
            ;;
        *)
            DOWNLOAD_MODE="twrp-only"
            SOURCE_DIR="$HOME/android-twrp-only"
            echo "选择: 仅 TWRP 相关组件"
            echo "目录: $SOURCE_DIR"
            echo "大小: 约 1GB"
            ;;
    esac
    echo ""
}

# 创建目录
setup_directory() {
    echo "6. 创建源码目录..."
    
    # 清理旧目录
    if [ -d "$SOURCE_DIR" ]; then
        echo "目录已存在: $SOURCE_DIR"
        read -p "删除并重新下载? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$SOURCE_DIR"
            echo "✓ 旧目录已删除"
        fi
    fi
    
    mkdir -p "$SOURCE_DIR"
    cd "$SOURCE_DIR"
    echo "✓ 目录创建完成: $(pwd)"
    echo ""
}

# 下载完整源码
download_full_source() {
    echo "开始下载完整 Android 源码 + TWRP..."
    echo "这需要较长时间，请耐心等待..."
    echo ""
    
    # 初始化 repo
    echo "初始化 repo..."
    repo init -u $AOSP_MIRROR/platform/manifest -b android-12.1.0_r27 --depth=1 --repo-url=$REPO_URL
    
    if [ $? -ne 0 ]; then
        echo "⚠ 初始化失败，尝试备用方案..."
        repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1 --repo-url=$REPO_URL
    fi
    
    echo "✓ repo 初始化完成"
    echo ""
    
    # 计算 CPU 核心数
    NUM_CPUS=$(nproc)
    echo "使用 $NUM_CPUS 个并行任务下载"
    echo "开始时间: $(date)"
    echo ""
    
    # 同步源码
    echo "开始同步源码..."
    repo sync -j$NUM_CPUS --no-tags --no-clone-bundle --current-branch --optimized-fetch --prune
    
    if [ $? -eq 0 ]; then
        echo ""
        echo "✓ 源码同步完成!"
        echo "完成时间: $(date)"
        echo "目录大小: $(du -sh . | cut -f1)"
    else
        echo ""
        echo "✗ 源码同步失败"
        echo "尝试使用更少的并行任务..."
        repo sync -j2 --no-tags --no-clone-bundle --current-branch
    fi
}

# 下载最小化源码
download_minimal_source() {
    echo "开始下载最小化 Android 源码..."
    echo ""
    
    # 创建目录结构
    mkdir -p .repo
    cat > .repo/manifest.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<manifest>
  <remote name="aosp"
          fetch="$AOSP_MIRROR" />
  <remote name="github"
          fetch="$GITHUB_MIRROR" />
  
  <default revision="android-12.1.0_r27"
           remote="aosp"
           sync-j="4" />
  
  <!-- 核心仓库 -->
  <project path="build/make" name="platform/build" groups="pdk" />
  <project path="build/soong" name="platform/build/soong" groups="pdk,tradefed" />
  <project path="system/core" name="platform/system/core" groups="pdk" />
  <project path="frameworks/base" name="platform/frameworks/base" groups="pdk-cw-fs,pdk-fs" />
  <project path="hardware/interfaces" name="platform/hardware/interfaces" groups="pdk" />
  <project path="hardware/libhardware" name="platform/hardware/libhardware" groups="pdk" />
  
  <!-- 必要的外部库 -->
  <project path="external/selinux" name="platform/external/selinux" groups="pdk" />
  <project path="external/libpng" name="platform/external/libpng" groups="pdk" />
  <project path="external/libjpeg-turbo" name="platform/external/libjpeg-turbo" groups="pdk" />
  <project path="external/freetype" name="platform/external/freetype" groups="pdk" />
  <project path="external/zlib" name="platform/external/zlib" groups="pdk" />
  <project path="external/bzip2" name="platform/external/bzip2" groups="pdk" />
  
  <!-- TWRP 恢复 -->
  <project path="bootable/recovery" name="android_bootable_recovery" remote="github" revision="twrp-12.1" />
  
</manifest>
EOF
    
    echo "✓ manifest 创建完成"
    echo ""
    
    # 初始化 repo
    repo init -u . --depth=1 --repo-url=$REPO_URL
    
    # 同步源码
    NUM_CPUS=$(nproc)
    echo "使用 $NUM_CPUS 个并行任务下载"
    echo "开始时间: $(date)"
    echo ""
    
    repo sync -j$NUM_CPUS --no-tags --no-clone-bundle --current-branch
}

# 仅下载 TWRP 相关组件
download_twrp_only() {
    echo "开始下载 TWRP 相关组件..."
    echo ""
    
    # 下载核心组件
    COMPONENTS=(
        "build/make"
        "build/soong"
        "system/core"
        "frameworks/base"
        "hardware/interfaces"
        "bootable/recovery"
    )
    
    for comp in "${COMPONENTS[@]}"; do
        name=$(basename "$comp")
        echo "下载: $comp"
        
        if [[ $comp == bootable/recovery ]]; then
            # TWRP 恢复
            git clone --depth=1 $GITHUB_MIRROR/TeamWin/android_bootable_recovery.git "$comp" || \
            git clone --depth=1 https://github.com/TeamWin/android_bootable_recovery.git "$comp"
        else
            # AOSP 组件
            git clone --depth=1 $AOSP_MIRROR/platform/${comp/\//\/}.git "$comp" || \
            echo "⚠ 下载失败: $comp"
        fi
        
        echo ""
    done
    
    echo "✓ 核心组件下载完成"
}

# 复制设备树和内核
setup_device_tree() {
    echo "7. 设置设备树..."
    
    if [ -d "/mnt/e/twrp/device/xiaomi/dagu" ]; then
        mkdir -p device/xiaomi
        cp -r /mnt/e/twrp/device/xiaomi/dagu device/xiaomi/
        echo "✓ 设备树复制完成: device/xiaomi/dagu"
        
        # 检查内核文件
        KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
        if [ -f "$KERNEL_FILE" ]; then
            echo "✓ 内核文件: $(ls -lh "$KERNEL_FILE")"
        else
            echo "⚠ 警告: 内核文件不存在"
        fi
    else
        echo "✗ 错误: 找不到设备树"
        exit 1
    fi
    echo ""
}

# 创建构建环境
create_build_env() {
    echo "8. 创建构建环境..."
    
    # 创建 envsetup.sh
    cat > build/envsetup.sh << 'EOF'
#!/bin/bash

# Android 构建环境设置

export ANDROID_BUILD_TOP=$(pwd)
export OUT_DIR=out
export TARGET_PRODUCT=twrp_dagu
export TARGET_BUILD_VARIANT=eng
export TARGET_BUILD_TYPE=release

# TWRP 特定变量
export RECOVERY_VARIANT=twrp
export TW_THEME=portrait_hdpi
export TW_DEVICE_VERSION=1.0

function lunch() {
    local product=$1
    if [ -z "$product" ]; then
        product="twrp_dagu-eng"
    fi
    
    echo "========================================"
    echo "  TWRP 构建环境"
    echo "========================================"
    echo "设备: $product"
    echo "构建目录: $ANDROID_BUILD_TOP"
    echo "输出目录: $OUT_DIR"
    echo ""
    
    # 检查设备树
    if [ ! -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
        echo "错误: BoardConfig.mk 未找到"
        return 1
    fi
    
    echo "✓ 设备配置检查通过"
    return 0
}

function mka() {
    local jobs=$(nproc)
    echo "使用 $jobs 个并行任务构建: $@"
    make -j$jobs "$@"
}

function mmka() {
    mka "$@"
}

echo "Android 构建环境已设置"
echo "运行: lunch twrp_dagu-eng"
echo "运行: mka recoveryimage"
EOF
    
    chmod +x build/envsetup.sh
    echo "✓ 构建环境创建完成"
    echo ""
}

# 创建构建脚本
create_build_script() {
    echo "9. 创建构建脚本..."
    
    cat > build_twrp.sh << 'EOF'
#!/bin/bash

# TWRP 构建脚本

set -e

echo "========================================"
echo "  开始构建 TWRP"
echo "========================================"

# 检查环境
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 不在 Android 源码目录"
    exit 1
fi

# 设置环境
source build/envsetup.sh

# 选择设备
lunch twrp_dagu-eng

echo ""
echo "检查设备配置..."
if [ -f "device/xiaomi/dagu/BoardConfig.mk" ]; then
    echo "✓ BoardConfig.mk 存在"
    echo "设备配置摘要:"
    grep -E "^(TARGET_|BOARD_|TW_)" device/xiaomi/dagu/BoardConfig.mk | head -10
else
    echo "✗ BoardConfig.mk 不存在"
    exit 1
fi

echo ""
echo "检查内核文件..."
KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在: $(ls -lh "$KERNEL_FILE")"
    echo "  文件类型: $(file "$KERNEL_FILE")"
else
    echo "✗ 内核文件不存在"
    exit 1
fi

echo ""
echo "检查 TWRP 源码..."
if [ -d "bootable/recovery" ] || [ -L "bootable/recovery" ]; then
    echo "✓ TWRP 源码存在"
    if [ -L "bootable/recovery" ]; then
        echo "  类型: 符号链接 -> $(readlink bootable/recovery)"
    fi
else
    echo "✗ TWRP 源码不存在"
    exit 1
fi

echo ""
echo "开始构建 recovery..."
echo "这可能需要较长时间（30分钟到2小时）..."
echo "开始时间: $(date)"
echo ""

# 创建输出目录
mkdir -p out/target/product/dagu

# 构建
mka recoveryimage

echo ""
echo "构建完成时间: $(date)"
echo ""

# 检查结果
if [ -f "out/target/product/dagu/recovery.img" ]; then
    echo "========================================"
    echo "  TWRP 构建成功!"
    echo "========================================"
    echo "恢复镜像: out/target/product/dagu/recovery.img"
    echo "大小: $(ls -lh out/target/product/dagu/recovery.img | awk '{print $5}')"
    echo "类型: $(file out/target/product/dagu/recovery.img)"
    
    # 复制到 Windows
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp out/target/product/dagu/recovery.img "$WINDOWS_DIR/"
    echo ""
    echo "已复制到 Windows:"
    echo "  $WINDOWS_DIR/recovery.img"
    
    # 创建刷机包
    echo ""
    echo "创建刷机包..."
    cd "$WINDOWS_DIR"
    PACKAGE_NAME="twrp-dagu-$(date +%Y%m%d-%H%M%S).zip"
    zip "$PACKAGE_NAME" recovery.img > /dev/null
    echo "刷机包: $PACKAGE_NAME"
    echo "大小: $(ls -lh "$PACKAGE_NAME" | awk '{print $5}')"
    
else
    echo "========================================"
    echo "  TWRP 构建失败"
    echo "========================================"
    echo "请检查构建日志"
    echo ""
    echo "常见问题:"
    echo "  1. 缺少依赖库"
    echo "  2. 设备树配置错误"
    echo "  3. 内核文件不匹配"
    echo "  4. 源码不完整"
    exit 1
fi
EOF
    
    chmod +x build_twrp.sh
    echo "✓ 构建脚本创建完成: build_twrp.sh"
    echo ""
}

# 主函数
main() {
    echo "========================================"
    echo "   开始下载 Android 源码"
    echo "========================================"
    echo ""
    
    # 选择镜像源
    select_mirror
    
    # 检查磁盘空间
    check_disk_space
    
    # 安装工具
    install_tools
    
    # 配置 git 镜像
    setup_git_mirrors
    
    # 配置 repo 工具
    setup_repo_tool
    
    # 选择下载模式
    select_download_mode
    
    # 创建目录
    setup_directory
    
    # 根据模式下载
    case $DOWNLOAD_MODE in
        "full")
            download_full_source
            ;;
        "minimal")
            download_minimal_source
            ;;
        "twrp-only")
            download_twrp_only
            ;;
    esac
    
    # 设置设备树
    setup_device_tree
    
    # 创建构建环境
    create_build_env
    
    # 创建构建脚本
    create_build_script
    
    echo "========================================"
    echo "     下载和设置完成!"
    echo "========================================"
    echo ""
    echo "源码目录: $SOURCE_DIR"
    echo "镜像源: $(echo $AOSP_MIRROR | cut -d/ -f3)"
    echo "下载模式: $DOWNLOAD_MODE"
    echo ""
    echo "下一步:"
    echo "  cd $SOURCE_DIR"
    echo "  source build/envsetup.sh"
    echo "  lunch twrp_dagu-eng"
    echo "  ./build_twrp.sh"
    echo ""
    echo "或直接运行:"
    echo "  cd $SOURCE_DIR && ./build_twrp.sh"
    echo ""
    echo "注意:"
    echo "  1. 首次构建可能需要较长时间"
    echo "  2. 确保有足够的磁盘空间"
    echo "  3. 构建过程中请保持网络连接"
    echo ""
    echo "构建成功概率:"
    echo "  - 完整源码: 95%"
    echo "  - 最小化源码: 80%"
    echo "  - 仅 TWRP 组件: 70%"
    echo ""
    echo "祝您构建成功! 🚀"
}

# 运行主函数
main "$@"