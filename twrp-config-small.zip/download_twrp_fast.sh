#!/bin/bash

# TWRP 源码快速下载脚本

set -e

echo "========================================"
echo "  TWRP 源码下载 - 优化版"
echo "========================================"
echo "注意: 下载约 20GB 数据，需要较长时间"
echo "建议使用稳定的网络连接"
echo "========================================"
echo ""

# 配置
SOURCE_DIR="$HOME/twrp-source"
MANIFEST_URL="https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git"
MANIFEST_BRANCH="twrp-12.1"
# 使用清华镜像加速（如果需要）
# REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo"
REPO_URL="https://gerrit-googlesource.proxy.ustclug.org/git-repo"

# 检查磁盘空间
echo "1. 检查磁盘空间..."
AVAILABLE_SPACE=$(df -h ~ | awk 'NR==2 {print $4}' | sed 's/G//')
echo "可用空间: ${AVAILABLE_SPACE}G"
if [ ${AVAILABLE_SPACE%.*} -lt 50 ]; then
    echo "警告: 可用空间不足 50GB，建议清理空间"
    read -p "继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi
echo ""

# 检查必要工具
echo "2. 检查必要工具..."
install_tools() {
    echo "安装构建工具..."
    sudo apt update
    sudo apt install -y \
        git curl unzip python3 openjdk-11-jdk \
        make gcc g++ flex bison build-essential zip \
        libncurses5 lib32ncurses5-dev x11proto-core-dev libx11-dev \
        lib32z1-dev libgl1-mesa-dev libxml2-utils xsltproc fontconfig
}

check_tool() {
    if ! command -v $1 &> /dev/null; then
        echo "  ✗ $1 未安装"
        return 1
    else
        echo "  ✓ $1 已安装"
        return 0
    fi
}

MISSING=()
check_tool git || MISSING+=("git")
check_tool curl || MISSING+=("curl")
check_tool python3 || MISSING+=("python3")
check_tool java || MISSING+=("openjdk-11-jdk")
check_tool make || MISSING+=("make")

if [ ${#MISSING[@]} -ne 0 ]; then
    echo ""
    echo "缺少工具: ${MISSING[@]}"
    read -p "自动安装? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        install_tools
    else
        echo "请手动安装缺少的工具后重试"
        exit 1
    fi
fi
echo ""

# 安装 repo 工具
echo "3. 安装/更新 repo 工具..."
if ! command -v repo &> /dev/null; then
    echo "下载 repo 工具..."
    mkdir -p ~/bin
    curl -s https://storage.googleapis.com/git-repo-downloads/repo > ~/bin/repo
    chmod a+x ~/bin/repo
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
    source ~/.bashrc
    echo "✓ repo 工具安装完成"
else
    echo "✓ repo 工具已安装"
    repo --version
fi
echo ""

# 设置 repo 镜像（可选，加速下载）
echo "4. 配置下载环境..."
if [ -n "$REPO_URL" ]; then
    echo "使用镜像: $REPO_URL"
    export REPO_URL="$REPO_URL"
fi

# 创建源码目录
echo "5. 创建源码目录..."
if [ -d "$SOURCE_DIR" ]; then
    echo "源码目录已存在: $SOURCE_DIR"
    read -p "如何处理? (1=继续使用, 2=删除重下, 3=退出): " -n 1 -r
    echo
    case $REPLY in
        2)
            echo "删除旧目录..."
            rm -rf "$SOURCE_DIR"
            mkdir -p "$SOURCE_DIR"
            ;;
        3)
            echo "退出"
            exit 0
            ;;
        *)
            echo "继续使用现有目录"
            ;;
    esac
else
    mkdir -p "$SOURCE_DIR"
fi

cd "$SOURCE_DIR"
echo "当前目录: $(pwd)"
echo ""

# 初始化 repo（使用浅克隆加速）
echo "6. 初始化 repo（使用浅克隆）..."
if [ ! -d ".repo" ]; then
    echo "初始化 TWRP manifest..."
    repo init -u "$MANIFEST_URL" -b "$MANIFEST_BRANCH" --depth=1
    if [ $? -eq 0 ]; then
        echo "✓ repo 初始化成功"
    else
        echo "✗ repo 初始化失败，尝试备用方法..."
        # 尝试不使用深度克隆
        repo init -u "$MANIFEST_URL" -b "$MANIFEST_BRANCH"
    fi
else
    echo "✓ repo 已初始化"
fi
echo ""

# 同步源码
echo "7. 开始同步源码..."
echo "========================================"
echo "重要: 这将下载约 20GB 数据"
echo "预计时间: 30分钟到2小时（取决于网速）"
echo "请保持网络连接稳定"
echo "========================================"
echo ""

# 设置并行下载
JOBS=$(nproc)
echo "使用 $JOBS 个并行任务下载"
echo ""

read -p "开始下载? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "取消下载"
    exit 0
fi

echo "开始时间: $(date)"
echo ""

# 同步源码，带进度显示
echo "同步进度:"
repo sync -c -j$JOBS --no-tags --no-clone-bundle --optimized-fetch --force-sync --progress
SYNC_RESULT=$?

echo ""
echo "结束时间: $(date)"
echo ""

if [ $SYNC_RESULT -eq 0 ]; then
    echo "✓ 源码同步完成"
    echo "下载大小: $(du -sh . | cut -f1)"
else
    echo "✗ 源码同步失败，错误码: $SYNC_RESULT"
    echo "可以稍后重试: cd $SOURCE_DIR && repo sync -c -j$JOBS"
    exit 1
fi

echo ""

# 复制设备树
echo "8. 复制设备树..."
DEVICE_TREE_SOURCE="/mnt/e/twrp/device/xiaomi/dagu"
DEVICE_TREE_DEST="$SOURCE_DIR/device/xiaomi/dagu"

if [ -d "$DEVICE_TREE_SOURCE" ]; then
    echo "找到设备树: $DEVICE_TREE_SOURCE"
    
    # 备份现有的设备树
    if [ -d "$DEVICE_TREE_DEST" ]; then
        BACKUP_DIR="$DEVICE_TREE_DEST.backup.$(date +%Y%m%d_%H%M%S)"
        echo "备份现有设备树到: $BACKUP_DIR"
        mv "$DEVICE_TREE_DEST" "$BACKUP_DIR"
    fi
    
    echo "复制设备树..."
    mkdir -p "$(dirname "$DEVICE_TREE_DEST")"
    cp -r "$DEVICE_TREE_SOURCE" "$DEVICE_TREE_DEST"
    
    # 验证复制
    if [ -d "$DEVICE_TREE_DEST" ]; then
        echo "✓ 设备树复制完成"
        echo "  文件数量: $(find "$DEVICE_TREE_DEST" -type f | wc -l)"
    else
        echo "✗ 设备树复制失败"
        exit 1
    fi
else
    echo "✗ 错误: 设备树源目录不存在"
    echo "请检查: $DEVICE_TREE_SOURCE"
    exit 1
fi

echo ""

# 验证关键文件
echo "9. 验证设备树文件..."
REQUIRED_FILES=(
    "AndroidProducts.mk"
    "BoardConfig.mk"
    "device.mk"
    "recovery.fstab"
    "twrp_dagu.mk"
    "vendorsetup.sh"
)

ALL_OK=true
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$DEVICE_TREE_DEST/$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ $file 未找到"
        ALL_OK=false
    fi
done

if [ "$ALL_OK" = true ]; then
    echo "✓ 设备树验证通过"
else
    echo "✗ 设备树验证失败，缺少必要文件"
    exit 1
fi

echo ""

# 验证内核文件
echo "10. 验证内核文件..."
KERNEL_FILE="$DEVICE_TREE_DEST/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$KERNEL_FILE")"
    
    # 检查是否为有效的 boot.img
    if file "$KERNEL_FILE" | grep -q "Android bootimg"; then
        echo "  ✓ 有效的 Android bootimg"
    else
        echo "  ⚠️ 警告: 可能不是有效的 boot.img"
    fi
else
    echo "✗ 错误: 内核文件不存在"
    exit 1
fi

echo ""

# 创建构建脚本
echo "11. 创建构建脚本..."
BUILD_SCRIPT="$SOURCE_DIR/build_dagu.sh"
cat > "$BUILD_SCRIPT" << 'EOF'
#!/bin/bash

# TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)

set -e

echo "========================================"
echo "  TWRP 构建脚本"
echo "  设备: dagu (小米平板5 Pro 12.4)"
echo "========================================"
echo ""

# 检查是否在源码目录
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 请在此目录运行: $SOURCE_DIR"
    echo "当前目录: $(pwd)"
    exit 1
fi

echo "1. 初始化环境..."
source build/envsetup.sh
echo "✓ 环境初始化完成"
echo ""

echo "2. 选择设备..."
if lunch twrp_dagu-eng; then
    echo "✓ 设备选择成功"
else
    echo "✗ 设备选择失败"
    echo "请检查设备树配置"
    exit 1
fi
echo ""

echo "3. 检查构建配置..."
echo "设备: $TARGET_PRODUCT"
echo "变体: $TARGET_BUILD_VARIANT"
echo "架构: $TARGET_ARCH"
echo ""

echo "4. 检查内核文件..."
KERNEL_FILE="device/xiaomi/dagu/prebuilt/kernel"
if [ -f "$KERNEL_FILE" ]; then
    echo "✓ 内核文件存在"
    echo "  路径: $KERNEL_FILE"
    echo "  大小: $(ls -lh "$KERNEL_FILE" | awk '{print $5}')"
else
    echo "✗ 错误: 内核文件不存在"
    exit 1
fi
echo ""

echo "5. 开始构建 recovery..."
echo "开始时间: $(date)"
echo "这可能需要 30分钟到2小时，请耐心等待..."
echo ""

# 设置并行构建
CPU_COUNT=$(nproc)
BUILD_JOBS=$((CPU_COUNT * 2))
echo "使用 $BUILD_JOBS 个并行任务构建"
echo ""

# 开始构建
mka recoveryimage -j$BUILD_JOBS

echo ""
echo "构建结束时间: $(date)"
echo ""

echo "6. 检查构建结果..."
OUTPUT_FILE="out/target/product/dagu/recovery.img"
if [ -f "$OUTPUT_FILE" ]; then
    echo "✅ TWRP 构建成功!"
    echo ""
    echo "恢复镜像信息:"
    echo "  位置: $OUTPUT_FILE"
    echo "  大小: $(ls -lh "$OUTPUT_FILE" | awk '{print $5}')"
    echo "  类型: $(file "$OUTPUT_FILE")"
    
    # 复制到 Windows 目录
    WINDOWS_DIR="/mnt/e/twrp/output"
    mkdir -p "$WINDOWS_DIR"
    cp "$OUTPUT_FILE" "$WINDOWS_DIR/"
    echo ""
    echo "已复制到 Windows:"
    echo "  $WINDOWS_DIR/recovery.img"
    
    # 创建时间戳
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    
    # 创建刷机包
    echo ""
    echo "7. 创建刷机包..."
    cd "$WINDOWS_DIR"
    PACKAGE_NAME="twrp-3.7.0-dagu-$TIMESTAMP.zip"
    
    # 创建 META-INF 目录结构
    mkdir -p META-INF/com/google/android
    
    # 创建 updater-script
    cat > META-INF/com/google/android/updater-script << SCRIPTEOF
ui_print("========================================");
ui_print(" TWRP Recovery for Xiaomi Pad 5 Pro 12.4");
ui_print(" Device: dagu");
ui_print(" Build: $TIMESTAMP");
ui_print("========================================");
ui_print("");
show_progress(0.500000, 0);
ui_print("Flashing recovery...");
package_extract_file("recovery.img", "/dev/block/bootdevice/by-name/recovery");
ui_print("Done!");
show_progress(0.100000, 0);
SCRIPTEOF
    
    # 创建 update-binary
    cat > META-INF/com/google/android/update-binary << 'BINARYEOF'
#!/sbin/sh
#
# TWRP Recovery Updater
#

OUTFD=$2
ZIP=$3

ui_print() {
    echo -e "ui_print $1\n" > /proc/self/fd/$OUTFD
}

ui_print "TWRP Recovery Installer"

# 检查设备
getprop("ro.product.device") == "dagu" || abort("This recovery is for dagu only.");

# 刷入恢复
package_extract_file("recovery.img", "/dev/block/bootdevice/by-name/recovery");

# 完成
ui_print("Installation complete!");
ui_print("");
ui_print("Reboot to recovery to use TWRP");
BINARYEOF

    chmod 755 META-INF/com/google/android/update-binary
    
    # 创建说明文件
    cat > README.txt << READMEEOF
TWRP Recovery for Xiaomi Pad 5 Pro 12.4 (dagu)

Device: Xiaomi Pad 5 Pro 12.4
CodeName: dagu
Model: 22071216C
Platform: Qualcomm SM8150 (Snapdragon 870)
Android: 13
TWRP Version: 3.7.0
Build Date: $(date)

Installation:
1. Copy this ZIP to device storage
2. Boot to existing recovery
3. Select "Install" -> "Install ZIP"
4. Select this file and flash
5. Reboot to recovery

Or via fastboot:
fastboot flash recovery recovery.img
fastboot reboot recovery

Notes:
- Unlocked bootloader required
- Backup important data
- Use at your own risk
READMEEOF

    # 打包
    zip -r "$PACKAGE_NAME" recovery.img META-INF/ README.txt > /dev/null
    
    # 清理临时文件
    rm -rf META-INF README.txt
    
    echo "刷机包: $PACKAGE_NAME"
    echo "大小: $(ls -lh "$PACKAGE_NAME" | awk '{print $5}')"
    
    echo ""
    echo "========================================"
    echo "  构建完成!"
    echo "========================================"
    echo ""
    echo "输出文件:"
    echo "  1. $OUTPUT_FILE (源码目录)"
    echo "  2. $WINDOWS_DIR/recovery.img (Windows)"
    echo "  3. $WINDOWS_DIR/$PACKAGE_NAME (刷机包)"
    echo ""
    echo "使用说明:"
    echo "  测试启动: fastboot boot $WINDOWS_DIR/recovery.img"
    echo "  永久刷入: fastboot flash recovery $WINDOWS_DIR/recovery.img"
    echo "  然后重启: fastboot reboot recovery"
    echo ""
    echo "刷机包使用:"
    echo "  复制到设备存储，在恢复模式中刷入"
    
else
    echo "❌ TWRP 构建失败"
    echo ""
    echo "可能的原因:"
    echo "  1. 内核文件不正确"
    echo "  2. 设备树配置错误"
    echo "  3. 依赖包缺失"
    echo "  4. 磁盘空间不足"
    echo ""
    echo "检查日志:"
    LOG_FILE="out/error.log"
    if [ -f "$LOG_FILE" ]; then
        tail -50 "$LOG_FILE"
    else
        echo "无错误日志，查看完整构建输出"
    fi
    exit 1
fi
EOF

chmod +x "$BUILD_SCRIPT"
echo "✓ 构建脚本已创建: $BUILD_SCRIPT"
echo ""

# 创建快速构建脚本
echo "12. 创建快速启动脚本..."
cat > "$SOURCE_DIR/quick_build.sh" << 'EOF'
#!/bin/bash

cd "$(dirname "$0")"
echo "TWRP 构建启动器"
echo "当前目录: $(pwd)"
echo ""

if [ -f "build_dagu.sh" ]; then
    echo "开始构建..."
    echo ""
    ./build_dagu.sh
else
    echo "错误: 构建脚本不存在"
    echo "请确保在 TWRP 源码目录"
    exit 1
fi
EOF

chmod +x "$SOURCE_DIR/quick_build.sh"

# 创建 Windows 启动脚本
WIN_SCRIPT="/mnt/e/twrp/start_twrp_build.bat"
cat > "$WIN_SCRIPT" << 'EOF'
@echo off
REM TWRP 构建启动脚本 - Windows
REM 在 WSL 中构建 TWRP

echo ========================================
echo   TWRP 构建脚本 - Windows 版本
echo ========================================
echo.

echo 1. 启动 WSL 构建环境...
wsl bash -c "cd ~/twrp-source && echo '当前目录: $(pwd)' && ls -la"

echo.
echo 2. 检查设备树...
wsl bash -c "cd ~/twrp-source && if [ -d 'device/xiaomi/dagu' ]; then echo '设备树存在'; else echo '错误: 设备树不存在'; exit 1; fi"

echo.
echo 3. 检查内核文件...
wsl bash -c "cd ~/twrp-source && if [ -f 'device/xiaomi/dagu/prebuilt/kernel' ]; then echo '内核文件存在'; file device/xiaomi/dagu/prebuilt/kernel; else echo '错误: 内核文件不存在'; exit 1; fi"

echo.
echo 4. 开始构建...
echo   注意: 这可能需要 30分钟到2小时
echo   请保持电脑连接电源，不要中断
echo.
pause

wsl bash -c "cd ~/twrp-source && ./build_dagu.sh"

echo.
echo ========================================
echo   构建完成!
echo ========================================
echo.
echo 输出文件在:
echo   e:\twrp\output\
echo.
pause
EOF

echo "✓ Windows 启动脚本已创建: $WIN_SCRIPT"
echo ""

# 完成
echo "========================================"
echo "  TWRP 源码下载和配置完成!"
echo "========================================"
echo ""
echo "源码位置: $SOURCE_DIR"
echo "大小: $(du -sh $SOURCE_DIR 2>/dev/null | cut -f1 || echo '计算中...')"
echo ""
echo "构建步骤:"
echo "1. 进入源码目录:"
echo "   cd $SOURCE_DIR"
echo ""
echo "2. 开始构建:"
echo "   ./build_dagu.sh"
echo ""
echo "或从 Windows 启动:"
echo "   双击 e:\\twrp\\start_twrp_build.bat"
echo ""
echo "注意事项:"
echo "- 首次构建需要较长时间（1-2小时）"
echo "- 确保至少有 100GB 可用磁盘空间"
echo "- 构建过程中不要中断"
echo "- 保持网络连接（需要下载依赖）"
echo ""
echo "构建成功后，文件将保存到:"
echo "  e:\\twrp\\output\\"
echo ""