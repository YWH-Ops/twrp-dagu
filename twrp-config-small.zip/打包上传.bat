@echo off
chcp 65001 >nul
echo ==========================================
echo TWRP项目打包工具
echo ==========================================
echo.

set "ZIP_NAME=twrp-dagu-github.zip"
set "DESKTOP=%USERPROFILE%\Desktop"

echo 正在打包必要的文件...
echo.

if exist "%DESKTOP%\%ZIP_NAME%" del "%DESKTOP%\%ZIP_NAME%"

:: 创建临时目录
set "TEMP_DIR=%TEMP%\twrp_pack"
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"
mkdir "%TEMP_DIR%\.github\workflows"
mkdir "%TEMP_DIR%\device\xiaomi\dagu"

:: 复制文件
copy /y ".github\workflows\*.yml" "%TEMP_DIR%\.github\workflows\" >nul 2>&1
copy /y "device\xiaomi\dagu\*" "%TEMP_DIR%\device\xiaomi\dagu\" >nul 2>&1
copy /y "README.md" "%TEMP_DIR%\" >nul 2>&1
copy /y "GITHUB_ACTIONS_GUIDE.md" "%TEMP_DIR%\" >nul 2>&1
copy /y "build_twrp_final.sh" "%TEMP_DIR%\" >nul 2>&1
copy /y "simple_twrp_build.sh" "%TEMP_DIR%\" >nul 2>&1

:: 打包
cd /d "%TEMP_DIR%"
powershell -Command "Compress-Archive -Path * -DestinationPath '%DESKTOP%\%ZIP_NAME%' -Force"

cd /d "%~dp0"

if exist "%DESKTOP%\%ZIP_NAME%" (
    echo [OK] 打包完成！
    echo 文件位置: %DESKTOP%\%ZIP_NAME%
    echo.
    echo 下一步操作：
    echo 1. 访问 https://github.com/1397465756/twrp-dagu
    echo 2. 点击 "Add file" -^> "Upload files"
    echo 3. 选择 %ZIP_NAME% 上传
    echo 4. 点击 "Commit changes"
    echo.
    echo 按任意键打开GitHub...
    pause >nul
    start https://github.com/1397465756/twrp-dagu
) else (
    echo [X] 打包失败
    pause
)

rmdir /s /q "%TEMP_DIR%"
