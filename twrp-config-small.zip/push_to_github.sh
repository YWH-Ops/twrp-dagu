#!/bin/bash

# TWRP 云构建 - 推送到 GitHub 脚本
# 请先修改下面的 GitHub 用户名

set -e

echo "========================================"
echo "TWRP 云构建 - GitHub 推送助手"
echo "========================================"
echo ""

# 颜色输出
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 配置变量
GITHUB_USERNAME="YOUR_GITHUB_USERNAME"  # 请修改为您的 GitHub 用户名
REPO_NAME="twrp-dagu"                    # 仓库名称
BRANCH="main"                           # 分支名称

# 检查 GitHub 用户名
if [ "$GITHUB_USERNAME" = "YOUR_GITHUB_USERNAME" ]; then
    print_error "请先修改脚本中的 GitHub 用户名！"
    echo ""
    echo "编辑脚本文件:"
    echo "  nano push_to_github.sh"
    echo ""
    echo "找到并修改这一行:"
    echo "  GITHUB_USERNAME=\"YOUR_GITHUB_USERNAME\""
    echo "改为:"
    echo "  GITHUB_USERNAME=\"您的GitHub用户名\""
    echo ""
    exit 1
fi

print_info "GitHub 配置:"
echo "  用户名: $GITHUB_USERNAME"
echo "  仓库名: $REPO_NAME"
echo "  分支: $BRANCH"
echo ""

# 步骤1: 检查 Git 配置
print_info "步骤1: 检查 Git 配置..."
if ! git config --global user.name > /dev/null 2>&1; then
    print_warning "Git 用户名未设置，正在配置..."
    git config --global user.name "$GITHUB_USERNAME"
    git config --global user.email "$GITHUB_USERNAME@users.noreply.github.com"
    print_success "Git 配置完成"
else
    print_success "Git 已配置: $(git config --global user.name)"
fi

# 步骤2: 检查当前 Git 状态
print_info "步骤2: 检查当前 Git 状态..."
if [ ! -d ".git" ]; then
    print_info "初始化 Git 仓库..."
    git init
    print_success "Git 仓库初始化完成"
else
    print_success "Git 仓库已存在"
fi

# 步骤3: 添加所有文件
print_info "步骤3: 添加文件到 Git..."
git add .
if [ $? -eq 0 ]; then
    print_success "文件添加完成"
else
    print_error "文件添加失败"
    exit 1
fi

# 步骤4: 提交更改
print_info "步骤4: 提交更改..."
COMMIT_MESSAGE="添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南"

git commit -m "$COMMIT_MESSAGE"
if [ $? -eq 0 ]; then
    print_success "提交完成"
    echo ""
    echo "提交信息:"
    echo "$COMMIT_MESSAGE" | head -5
    echo "..."
else
    print_error "提交失败"
    exit 1
fi

# 步骤5: 添加远程仓库
print_info "步骤5: 配置远程仓库..."
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

# 检查是否已存在远程仓库
if git remote | grep -q origin; then
    print_warning "远程仓库 origin 已存在，更新 URL..."
    git remote set-url origin "$REMOTE_URL"
else
    git remote add origin "$REMOTE_URL"
fi

print_success "远程仓库配置完成: $REMOTE_URL"

# 步骤6: 检查 GitHub 仓库是否存在
print_info "步骤6: 检查 GitHub 仓库..."
if curl -s "https://api.github.com/repos/$GITHUB_USERNAME/$REPO_NAME" | grep -q "Not Found"; then
    print_warning "GitHub 仓库不存在，请先创建仓库:"
    echo ""
    echo "请访问: https://github.com/new"
    echo ""
    echo "填写以下信息:"
    echo "  Repository name: $REPO_NAME"
    echo "  Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
    echo "  Visibility: Public"
    echo "  不要勾选: Initialize this repository with a README"
    echo ""
    read -p "创建完成后按 Enter 继续..."
else
    print_success "GitHub 仓库已存在"
fi

# 步骤7: 推送代码
print_info "步骤7: 推送代码到 GitHub..."
echo ""
echo "正在推送到: https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
echo "分支: $BRANCH"
echo ""

# 重命名分支（如果需要）
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "$BRANCH" ]; then
    print_info "重命名分支: $CURRENT_BRANCH -> $BRANCH"
    git branch -M "$BRANCH"
fi

# 推送代码
print_info "开始推送，这可能需要一些时间..."
git push -u origin "$BRANCH"

if [ $? -eq 0 ]; then
    print_success "✅ 代码推送成功！"
else
    print_error "❌ 推送失败"
    echo ""
    echo "可能的原因:"
    echo "1. GitHub 仓库不存在 - 请先创建仓库"
    echo "2. 网络问题 - 请检查网络连接"
    echo "3. 权限问题 - 请确认有推送权限"
    echo ""
    echo "手动创建仓库命令:"
    echo "  gh repo create $REPO_NAME --public --description \"TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)\""
    echo ""
    exit 1
fi

# 步骤8: 显示下一步操作
print_info "步骤8: 下一步操作..."
echo ""
echo "========================================"
print_success "🎉 代码推送完成！"
echo "========================================"
echo ""
echo "接下来请执行以下步骤:"
echo ""
echo "1. 打开浏览器访问:"
echo "   https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "2. 点击顶部 'Actions' 标签"
echo ""
echo "3. 点击 'I understand my workflows, go ahead and enable them'"
echo ""
echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
echo ""
echo "5. 点击 'Run workflow'"
echo ""
echo "6. 配置构建参数:"
echo "   - use_china_mirror: true (推荐)"
echo "   - build_type: minimal (首次测试)"
echo "   - upload_artifact: true"
echo ""
echo "7. 点击 'Run workflow' 开始构建"
echo ""
echo "8. 等待构建完成 (约1-2小时)"
echo ""
echo "9. 下载 recovery.img 并测试"
echo ""
echo "========================================"
echo "重要链接:"
echo "========================================"
echo "仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "文档: https://github.com/$GITHUB_USERNAME/$REPO_NAME#readme"
echo ""
echo "========================================"
echo "构建状态监控:"
echo "========================================"
echo "构建过程中可以:"
echo "1. 查看实时日志"
echo "2. 监控各个步骤"
echo "3. 下载构建产物"
echo "4. 查看错误信息"
echo ""
echo "========================================"
echo "需要帮助?"
echo "========================================"
echo "1. 查看文档: 云构建指南.md"
echo "2. 运行验证: ./verify_github_actions.sh"
echo "3. 本地测试: ./test_cloud_build.sh"
echo "4. 提交 Issue: 在仓库中报告问题"
echo ""
print_success "祝您构建成功！🚀"

# 保存配置
cat > github_config.txt << EOF
GitHub 用户名: $GITHUB_USERNAME
仓库名称: $REPO_NAME
仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME
Actions 地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions
推送时间: $(date)
EOF

print_info "配置已保存到: github_config.txt"