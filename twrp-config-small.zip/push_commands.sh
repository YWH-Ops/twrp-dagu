#!/bin/bash

echo "========================================"
echo "TWRP 云构建 - 推送命令生成器"
echo "========================================"
echo ""

read -p "请输入您的 GitHub 用户名: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "错误：GitHub 用户名不能为空"
    exit 1
fi

REPO_NAME="twrp-dagu"
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"

echo ""
echo "========================================"
echo "GitHub 配置信息"
echo "========================================"
echo "用户名: $GITHUB_USERNAME"
echo "仓库名: $REPO_NAME"
echo "远程地址: $REMOTE_URL"
echo ""

echo "========================================"
echo "完整的推送命令"
echo "========================================"
echo ""
echo "1. 切换到项目目录:"
echo "   cd /mnt/e/twrp"
echo ""
echo "2. 设置 Git 配置（如果需要）:"
echo "   git config --global user.name \"TWRP Builder\""
echo "   git config --global user.email \"builder@example.com\""
echo ""
echo "3. 添加所有文件:"
echo "   git add -f ."
echo ""
echo "4. 提交更改:"
echo "   git commit -m \"TWRP 云构建配置\""
echo ""
echo "5. 添加远程仓库:"
echo "   git remote add origin $REMOTE_URL"
echo ""
echo "6. 重命名分支并推送:"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "========================================"
echo "一键推送命令"
echo "========================================"
echo ""
echo "复制并执行以下命令:"
echo ""
echo "cd /mnt/e/twrp && git add -f . && git commit -m \"TWRP 云构建配置\" && git remote add origin $REMOTE_URL && git branch -M main && git push -u origin main"
echo ""
echo "========================================"
echo "GitHub 仓库创建链接"
echo "========================================"
echo ""
echo "创建仓库: https://github.com/new"
echo ""
echo "填写信息:"
echo "  Repository name: $REPO_NAME"
echo "  Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)"
echo "  Visibility: Public"
echo "  不要勾选: Initialize this repository with a README"
echo ""
echo "========================================"
echo "启用 GitHub Actions"
echo "========================================"
echo ""
echo "仓库创建后:"
echo "1. 访问: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "2. 点击顶部 'Actions' 标签"
echo "3. 点击 'I understand my workflows, go ahead and enable them'"
echo "4. 选择 'Cloud TWRP Builder with China Mirror'"
echo "5. 点击 'Run workflow'"
echo "6. 配置参数并开始构建"
echo ""
echo "========================================"
echo "保存配置"
echo "========================================"
echo ""
cat > github_push_commands.txt << EOF
GitHub 用户名: $GITHUB_USERNAME
仓库名称: $REPO_NAME
远程地址: $REMOTE_URL

推送命令:
cd /mnt/e/twrp
git add -f .
git commit -m "TWRP 云构建配置"
git remote add origin $REMOTE_URL
git branch -M main
git push -u origin main

GitHub 链接:
创建仓库: https://github.com/new
仓库地址: https://github.com/$GITHUB_USERNAME/$REPO_NAME
Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions

构建参数:
- use_china_mirror: true
- build_type: minimal
- upload_artifact: true
EOF

echo "配置已保存到: github_push_commands.txt"
echo ""
echo "查看配置: cat github_push_commands.txt"