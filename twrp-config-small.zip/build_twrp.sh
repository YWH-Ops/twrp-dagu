#!/bin/bash

# TWRP 构建脚本
# 用于构建小米平板5 Pro 12.4 (dagu) 的 TWRP

set -e

echo "================================================"
echo "     TWRP 构建脚本 - 小米平板5 Pro 12.4 (dagu)"
echo "================================================"
echo ""

# 检查环境
echo "1. 检查环境..."
echo ""

# 检查是否在 TWRP 源码目录
if [ ! -f "build/envsetup.sh" ]; then
    echo "错误: 请在 TWRP 源码根目录运行此脚本"
    echo "当前目录: $(pwd)"
    exit 1
fi

echo "✓ 在 TWRP 源码目录"
echo ""

# 检查设备树
DEVICE_DIR="device/xiaomi/dagu"
if [ ! -d "$DEVICE_DIR" ]; then
    echo "错误: 设备树目录不存在: $DEVICE_DIR"
    exit 1
fi

echo "✓ 设备树目录存在: $DEVICE_DIR"
echo ""

# 检查内核文件
KERNEL_FILE="$DEVICE_DIR/prebuilt/kernel"
if [ ! -f "$KERNEL_FILE" ]; then
    echo "错误: 内核文件不存在: $KERNEL_FILE"
    exit 1
fi

echo "✓ 内核文件存在: $KERNEL_FILE"
echo "内核文件信息:"
ls -lh "$KERNEL_FILE"
file "$KERNEL_FILE"
echo ""

# 初始化构建环境
echo "2. 初始化构建环境..."
source build/envsetup.sh
echo "✓ 环境已初始化"
echo ""

# 选择设备
echo "3. 选择构建目标..."
lunch twrp_dagu-eng
echo "✓ 构建目标已选择: twrp_dagu-eng"
echo ""

# 验证环境变量
echo "4. 验证环境变量..."
echo "TARGET_PREBUILT_KERNEL: $TARGET_PREBUILT_KERNEL"
echo "TARGET_ARCH: $TARGET_ARCH"
echo "TARGET_BOARD_PLATFORM: $TARGET_BOARD_PLATFORM"
echo ""

# 检查内核路径是否正确
if [ ! -f "$TARGET_PREBUILT_KERNEL" ]; then
    echo "警告: TARGET_PREBUILT_KERNEL 指向的文件不存在"
    echo "当前路径: $TARGET_PREBUILT_KERNEL"
    echo "尝试使用绝对路径..."
    
    # 尝试从设备树路径解析
    if [[ "$TARGET_PREBUILT_KERNEL" == *"\$(DEVICE_PATH)"* ]]; then
        DEVICE_PATH=$(dirname "$DEVICE_DIR")
        KERNEL_RELATIVE=${TARGET_PREBUILT_KERNEL#*)/}
        RESOLVED_PATH="$DEVICE_PATH/$KERNEL_RELATIVE"
        echo "解析路径: $RESOLVED_PATH"
        
        if [ -f "$RESOLVED_PATH" ]; then
            echo "✓ 找到内核文件: $RESOLVED_PATH"
        else
            echo "✗ 内核文件不存在: $RESOLVED_PATH"
            exit 1
        fi
    else
        echo "✗ 无法解析内核路径"
        exit 1
    fi
else
    echo "✓ 内核文件存在: $TARGET_PREBUILT_KERNEL"
fi
echo ""

# 构建配置
echo "5. 构建配置检查..."
echo "BOARD_KERNEL_BASE: $BOARD_KERNEL_BASE"
echo "BOARD_KERNEL_PAGESIZE: $BOARD_KERNEL_PAGESIZE"
echo "BOARD_RAMDISK_OFFSET: $BOARD_RAMDISK_OFFSET"
echo "BOARD_DTB_OFFSET: $BOARD_DTB_OFFSET"
echo "BOARD_KERNEL_IMAGE_NAME: $BOARD_KERNEL_IMAGE_NAME"
echo ""

# 开始构建
echo "6. 开始构建 TWRP..."
echo "使用命令: mka recoveryimage"
echo "这可能需要一些时间..."
echo ""

# 实际构建命令（取消注释以开始构建）
# mka recoveryimage

echo "7. 构建完成后的检查..."
echo ""

# 检查输出文件
OUTPUT_DIR="out/target/product/dagu"
RECOVERY_IMG="$OUTPUT_DIR/recovery.img"

if [ -f "$RECOVERY_IMG" ]; then
    echo "✓ TWRP 构建成功!"
    echo "恢复镜像位置: $RECOVERY_IMG"
    ls -lh "$RECOVERY_IMG"
    echo ""
    
    # 检查镜像类型
    echo "恢复镜像信息:"
    file "$RECOVERY_IMG"
    echo ""
    
    # 检查镜像大小
    echo "分区大小检查:"
    echo "BOARD_RECOVERYIMAGE_PARTITION_SIZE: $BOARD_RECOVERYIMAGE_PARTITION_SIZE"
    IMAGE_SIZE=$(stat -c%s "$RECOVERY_IMG" 2>/dev/null || stat -f%z "$RECOVERY_IMG")
    echo "恢复镜像大小: $IMAGE_SIZE 字节"
    echo ""
    
    if [ $IMAGE_SIZE -le $BOARD_RECOVERYIMAGE_PARTITION_SIZE ]; then
        echo "✓ 镜像大小在分区限制内"
    else
        echo "⚠️ 警告: 镜像大小超过分区限制"
        echo "可能需要调整 BOARD_RECOVERYIMAGE_PARTITION_SIZE"
    fi
    
else
    echo "✗ TWRP 构建失败"
    echo "检查构建日志:"
    echo "  tail -f $OUTPUT_DIR/build.log"
    exit 1
fi

echo "8. 测试建议..."
echo ""
cat << EOF
测试步骤:
1. 进入 fastboot 模式:
   adb reboot bootloader

2. 刷入 TWRP:
   fastboot flash recovery $RECOVERY_IMG

3. 启动到 TWRP:
   fastboot boot $RECOVERY_IMG

4. 测试功能:
   - 触控屏
   - 存储挂载
   - 备份/恢复
   - ADB 连接
   - MTP 连接

注意:
- 首次启动可能需要较长时间
- 确保电池电量充足
- 备份重要数据
EOF

echo ""
echo "9. 清理建议..."
echo ""
echo "如果需要重新构建，可以清理构建缓存:"
echo "  make clean"
echo "或"
echo "  rm -rf out/target/product/dagu"

echo ""
echo "================================================"
echo "     构建脚本完成!"
echo "================================================"
echo ""
echo "下一步操作:"
echo "1. 取消注释第 56 行的 'mka recoveryimage' 开始构建"
echo "2. 或者手动运行: mka recoveryimage"
echo "3. 构建完成后检查 out/target/product/dagu/recovery.img"
echo ""
echo "重要提示:"
echo "- 构建需要大量内存和磁盘空间"
echo "- 首次构建可能需要较长时间"
echo "- 确保网络连接稳定"
echo "- 如果构建失败，检查内核文件是否正确"