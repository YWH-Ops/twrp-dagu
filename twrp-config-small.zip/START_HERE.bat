@echo off
chcp 65001 >nul
echo.
echo ========================================
echo  🚀 TWRP 云构建 - 一键启动脚本
echo ========================================
echo.
echo 这个脚本将帮助您设置并启动 TWRP 云构建。
echo 请按照以下步骤操作：
echo.

:menu
echo ========================================
echo  请选择操作：
echo ========================================
echo  1. 验证配置文件（推荐第一步）
echo  2. 设置 GitHub 仓库并推送代码
echo  3. 查看详细文档
echo  4. 运行本地测试
echo  5. 查看快速开始指南
echo  6. 退出
echo ========================================
echo.
set /p choice="请输入选项 (1-6): "

if "%choice%"=="1" goto verify
if "%choice%"=="2" goto setup
if "%choice%"=="3" goto docs
if "%choice%"=="4" goto test
if "%choice%"=="5" goto quickstart
if "%choice%"=="6" goto exit
echo 无效选项，请重新输入
echo.
goto menu

:verify
echo.
echo ========================================
echo  验证配置文件...
echo ========================================
echo.
wsl bash -c "cd /mnt/e/twrp && ./verify_github_actions.sh"
echo.
echo 按任意键返回菜单...
pause >nul
goto menu

:setup
echo.
echo ========================================
echo  设置 GitHub 仓库
echo ========================================
echo.
echo 步骤 1/3: 检查 Git 配置
echo.
wsl bash -c "cd /mnt/e/twrp && git config --global user.name || echo 'Git 用户名未设置'"
wsl bash -c "cd /mnt/e/twrp && git config --global user.email || echo 'Git 邮箱未设置'"
echo.
echo 请先设置 Git 配置（如果需要）：
echo git config --global user.name "您的名字"
echo git config --global user.email "您的邮箱"
echo.
echo 步骤 2/3: 输入 GitHub 用户名
echo.
set /p GITHUB_USERNAME=请输入您的 GitHub 用户名: 
if "%GITHUB_USERNAME%"=="" (
    echo 错误：GitHub 用户名不能为空
    pause
    goto menu
)
echo.
echo 步骤 3/3: 开始设置
echo.
echo 这将执行以下操作：
echo 1. 初始化 Git 仓库（如果未初始化）
echo 2. 添加所有文件
echo 3. 提交更改
echo 4. 推送到 GitHub
echo.
set /p confirm=确定要继续吗？(y/n): 
if /i not "%confirm%"=="y" goto menu

echo.
echo 正在设置，请稍候...
echo.

rem 设置 Git 配置
wsl bash -c "cd /mnt/e/twrp && git config --global user.name '%GITHUB_USERNAME%'"
wsl bash -c "cd /mnt/e/twrp && git config --global user.email '%GITHUB_USERNAME%@users.noreply.github.com'"

rem 初始化仓库
wsl bash -c "cd /mnt/e/twrp && if [ ! -d .git ]; then git init; fi"

rem 添加文件
echo 添加文件到 Git...
wsl bash -c "cd /mnt/e/twrp && git add ."

rem 提交更改
echo 提交更改...
wsl bash -c "cd /mnt/e/twrp && git commit -m '添加 TWRP 云构建配置

- GitHub Actions 工作流文件
- 完整的设备树 (dagu)
- TWRP 恢复源码
- 云构建文档和脚本
- 验证和测试工具

设备: 小米平板5 Pro 12.4 (dagu)
构建: 支持最小化和完整构建
镜像: 支持国内镜像加速
文档: 完整的使用指南' || echo '提交可能失败，继续...'"

echo.
echo ========================================
echo  🎯 重要：请先创建 GitHub 仓库！
echo ========================================
echo.
echo 请在浏览器中访问：
echo https://github.com/new
echo.
echo 创建仓库：
echo - Repository name: twrp-dagu
echo - Description: TWRP for Xiaomi Pad 5 Pro 12.4 (dagu)
echo - 选择 Public (公开)
echo - 不要勾选 "Initialize this repository with a README"
echo - 不要添加 .gitignore 或 license
echo.
echo 创建完成后按任意键继续...
pause >nul

echo.
echo 正在推送到 GitHub...
echo 仓库地址：https://github.com/%GITHUB_USERNAME%/twrp-dagu.git
echo.

rem 添加远程仓库
wsl bash -c "cd /mnt/e/twrp && git remote remove origin 2>/dev/null || true"
wsl bash -c "cd /mnt/e/twrp && git remote add origin https://github.com/%GITHUB_USERNAME%/twrp-dagu.git"

rem 推送代码
wsl bash -c "cd /mnt/e/twrp && git branch -M main && git push -u origin main"

if errorlevel 0 (
    echo.
    echo ✅ 代码推送成功！
    echo.
    echo ========================================
    echo  下一步操作：
    echo ========================================
    echo 1. 访问您的仓库：
    echo    https://github.com/%GITHUB_USERNAME%/twrp-dagu
    echo.
    echo 2. 点击顶部 "Actions" 标签
    echo.
    echo 3. 点击 "I understand my workflows, go ahead and enable them"
    echo.
    echo 4. 选择 "Cloud TWRP Builder with China Mirror"
    echo.
    echo 5. 点击 "Run workflow"
    echo.
    echo 6. 配置参数：
    echo    - use_china_mirror: true
    echo    - build_type: minimal
    echo    - upload_artifact: true
    echo.
    echo 7. 点击 "Run workflow" 开始构建
    echo.
    echo 8. 等待构建完成（约1-2小时）
    echo.
    echo 9. 下载 recovery.img 并测试
    echo.
    
    rem 保存配置信息
    echo GitHub 用户名: %GITHUB_USERNAME% > github_info.txt
    echo 仓库名称: twrp-dagu >> github_info.txt
    echo 仓库地址: https://github.com/%GITHUB_USERNAME%/twrp-dagu >> github_info.txt
    echo Actions: https://github.com/%GITHUB_USERNAME%/twrp-dagu/actions >> github_info.txt
    echo 设置时间: %date% %time% >> github_info.txt
    echo.
    echo 配置信息已保存到：github_info.txt
) else (
    echo.
    echo ❌ 推送失败！
    echo.
    echo 可能的原因：
    echo 1. GitHub 仓库未创建
    echo 2. 网络连接问题
    echo 3. 权限问题
    echo.
    echo 请确保：
    echo 1. 已创建仓库：https://github.com/new
    echo 2. 仓库名称为：twrp-dagu
    echo 3. 仓库是 Public（公开）
    echo.
    echo 或者手动运行：
    echo wsl bash -c "cd /mnt/e/twrp && ./setup_github_repo.sh"
)

echo.
pause
goto menu

:docs
echo.
echo ========================================
echo  文档列表
echo ========================================
echo.
echo 可用文档：
echo 1. 云构建指南.md - 完整使用说明
echo 2. GITHUB_ACTIONS_GUIDE.md - 技术文档
echo 3. 云构建快速开始.md - 5步快速开始
echo 4. 云构建方案总结.md - 方案总结
echo 5. 立即开始云构建.txt - 启动指南
echo.
echo 要查看文档，请在 WSL 中运行：
echo cat 文档名称.md
echo.
echo 例如：
echo wsl bash -c "cd /mnt/e/twrp && cat 云构建指南.md | head -50"
echo.
pause
goto menu

:test
echo.
echo ========================================
echo  运行本地测试
echo ========================================
echo.
echo 这将测试您的构建环境配置。
echo.
set /p confirm=确定要运行本地测试吗？(y/n): 
if /i not "%confirm%"=="y" goto menu

echo.
echo 正在运行本地测试...
echo.
wsl bash -c "cd /mnt/e/twrp && ./test_cloud_build.sh || echo '测试完成（可能有警告）'"
echo.
pause
goto menu

:quickstart
echo.
echo ========================================
echo  快速开始指南
echo ========================================
echo.
type "立即开始云构建.txt" | more
echo.
pause
goto menu

:exit
echo.
echo ========================================
echo  感谢使用 TWRP 云构建！
echo ========================================
echo.
echo 如果需要帮助，请查看文档或运行验证脚本。
echo.
echo 再见！
echo.
pause
exit /b 0