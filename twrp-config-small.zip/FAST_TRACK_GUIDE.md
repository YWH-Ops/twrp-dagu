# ⚡ GitHub Actions 云构建 TWRP - 3 分钟快速开始
## 小米平板 5 Pro 12.4 (dagu) - 最简指南

---

## 🎯 超简单三步（真的只要 3 分钟）

### 第 1 步：Fork（30 秒）
```
访问 https://github.com → 登录 → 找到仓库 → 点击 Fork
```

### 第 2 步：Actions（1 分钟）
```
在你的 Fork 仓库 → 点击 Actions 标签 → 
选择 "Cloud TWRP Builder with China Mirror"
```

### 第 3 步：Run workflow（1 分钟）
```
点击 "Run workflow" → 保持默认设置 → 
点击绿色按钮 → 完成！
```

**然后**: 等待 30-60 分钟，收到邮件后下载即可 ✅

---

## 📱 完整流程图解

```
┌─────────────┐
│   GitHub    │
│   账号      │
└──────┬──────┘
       ↓
┌─────────────┐
│  Fork 仓库   │ ← 30 秒
└──────┬──────┘
       ↓
┌─────────────┐
│  Actions    │ ← 1 分钟
└──────┬──────┘
       ↓
┌─────────────┐
│ Run Workflow│ ← 1 分钟
└──────┬──────┘
       ↓
┌─────────────┐
│ 等待构建     │ ← 30-60 分钟（可以离开做别的事）
└──────┬──────┘
       ↓
┌─────────────┐
│ 下载产物     │ ← 2 分钟
└──────┬──────┘
       ↓
┌─────────────┐
│   成功！    │
└─────────────┘
```

---

## 🎨 配置选项（使用默认值即可）

```yaml
Branch: main                    # 保持不变
Use China Mirror: true          # ✅ 重要！速度快 10-20 倍
Build Type: minimal             # ✅ 推荐！只需 30-60 分钟
Upload Artifacts: true          # ✅ 必须！否则无法下载
```

**记住**: 全部保持默认，直接点绿色的 "Run workflow"！

---

## ⏱️ 时间线

| 时间点 | 事件 | 你需要做什么 |
|--------|------|-------------|
| 0 分钟 | 点击 Run workflow | 点击按钮 |
| 5 分钟 | 环境搭建完成 | 可以继续工作 |
| 25 分钟 | 源码下载完成 | 可以离开一下 |
| 50 分钟 | 构建完成 | 准备接收邮件 |
| 55 分钟 | 上传完成 | 打开邮箱 |
| 60 分钟 | 收到通知 | 下载产物 |

---

## 📥 下载产物（构建成功后）

### 步骤（2 分钟）

1. **打开 Actions 页面**
   ```
   你的仓库 → Actions → 最近的运行记录（绿色✓）
   ```

2. **找到 Artifacts**
   ```
   滚动到页面底部 → 看到 "Artifacts" 区域
   ```

3. **下载文件**
   ```
   点击 "twrp-dagu-{数字}" → 自动下载 ZIP 文件
   ```

4. **解压获取**
   ```
   解压 ZIP → 得到 recovery.img → 完成！
   ```

---

## 🔍 实时监控（可选）

如果想看构建过程：

```
Actions → 点击正在运行的记录 → 查看实时日志
```

**关键节点**:
- ✅ Setup Build Environment (5 min)
- ✅ Download Android Source (20 min)
- ✅ Setup Device Tree (2 min)
- 🔄 Build TWRP Recovery (40 min) ← 这里最久
- ⏳ Upload Build Artifacts (5 min)

---

## ⚠️ 重要提示（必读）

### ✅ 必须做的

1. **启用 Actions**
   ```
   Settings → Actions → General
   → 选择 "Allow all actions and reusable workflows"
   ```

2. **使用中国镜像**
   ```
   Use China Mirror: true  ← 一定要选这个！
   ```

3. **选择 Minimal Build**
   ```
   Build Type: minimal  ← 最快最稳定
   ```

### ❌ 不要做的

1. ❌ 不要选择 Full Build（除非你很有耐心）
2. ❌ 不要关闭浏览器（会错过重要信息）
3. ❌ 不要在高峰时段构建（晚上 8-10 点）
4. ❌ 不要忘记下载（7 天后自动删除）

---

## 💡 加速技巧

### 速度提升 10 倍的秘诀

```yaml
# 黄金组合
use_china_mirror: 'true'     # 清华镜像 = 快 10-20 倍
build_type: 'minimal'        # 最小化 = 省时 50%
off_peak_time: true          # 非高峰 = 更稳定
```

### 最佳构建时间（UTC+8）

✅ **推荐**:
- 🌙 0:00 - 6:00（凌晨）
- 🌅 6:00 - 9:00（清晨）
- 🌞 9:00 - 11:00（上午）

❌ **避免**:
- 🌆 19:00 - 23:00（晚上高峰）

---

## 🛠️ 故障排除（30 秒速查）

### 常见问题

**Q: 找不到 Actions 标签？**
```
解决：Settings → Actions → 启用
```

**Q: Workflow 无法运行？**
```
解决：Settings → Actions → Workflow permissions
     → Read and write permissions
```

**Q: 构建失败？**
```
解决：90% 是网络问题，重新运行即可
```

**Q: 太慢了怎么办？**
```
解决：确保使用了中国镜像 + Minimal Build
```

---

## 📊 成功指标

### 如何判断构建成功？

✅ **成功的标志**:
- Actions 显示绿色 ✓
- 收到 GitHub 邮件通知
- Artifacts 区域有文件可下载
- recovery.img 大小在 64-128MB

❌ **失败的标志**:
- Actions 显示红色 ✗
- 错误信息包含 "error:" 或 "failed"
- Artifacts 为空或不存在

---

## 🎯 下一步（下载后）

### 验证文件

```bash
# 检查大小
ls -lh recovery.img
# 应该显示 ~128 MB

# 检查类型
file recovery.img
# 应该显示 "Android bootimg"
```

### 测试刷入

```bash
# 进入 fastboot
adb reboot bootloader

# 临时启动（安全测试）
fastboot boot recovery.img
```

### 永久刷入

```bash
# 刷入 recovery
fastboot flash recovery recovery.img

# 重启到 TWRP
fastboot reboot recovery
```

---

## 📞 需要更多帮助？

### 详细文档

- 📘 `QUICK_START_GITHUB_ACTIONS.md` - 完整快速指南
- 📗 `GITHUB_ACTIONS_BUILD_GUIDE.md` - 详细教程
- 📙 `GITHUB_CLOUD_BUILD_SUMMARY.md` - 完整总结
- 📕 `README_BUILD.md` - 构建说明

### 视频教学（推荐）

如果有视频教程链接，可以在这里添加

### 社区支持

- XDA 论坛：Xiaomi Mi Pad 5 版块
- Telegram: "dagu TWRP" 群组
- GitHub Issues: 在你 Fork 的仓库提交

---

## ✅ 最终检查清单

开始前确认：

- [ ] 有 GitHub 账号
- [ ] 邮箱已验证
- [ ] 知道怎么 Fork
- [ ] 知道 Actions 在哪
- [ ] 准备好 USB 线
- [ ] 设备电量 > 50%
- [ ] 已解锁 Bootloader

---

## 🎉 准备好了吗？

### 立即行动！

1. **打开浏览器**
2. **访问** https://github.com
3. **找到你的 TWRP 仓库**
4. **点击 Actions**
5. **Run workflow**
6. **等待好消息！**

---

## 🏆 成功公式

```
成功 = 正确的配置 + 合适的时机 + 一点耐心

正确的配置 = Minimal + 中国镜像
合适的时机 = 非高峰时段
一点耐心 = 30-60 分钟等待
```

---

**记住**: 这真的很简单，就像点外卖一样简单！

**Fork → Actions → Run → 等待 → 下载 → 完成！** 🎉

---

*3 分钟就能开始的旅程，现在就出发吧！* 🚀

*最后更新：2026 年 4 月 1 日*
